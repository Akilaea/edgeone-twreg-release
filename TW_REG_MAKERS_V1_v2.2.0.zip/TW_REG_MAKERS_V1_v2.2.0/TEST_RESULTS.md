# EdgeOne Makers 实测记录（2026-11-21）

## v2.2.0 — 自动换核 / 1 线程 Tanuki 复测（2026-11-24）

项目 `tw-tanuki-1t`（overseas / SG，直连 `43.163.113.234`，上传开）。

| 测试 | 配置 | 结果 |
|---|---|---|
| Tanuki 单线程 | 1 worker × 1 account × 1 round，`mode=multi` | **0/1，1 次 5025，13.1s** |
| ruyi 对照组 | 同 IP、同沙箱、1 worker × 1 account | **1/1，上传 1/1，0 个 5025，13.5s** |
| auto `/batch` | 1×1×1，`engine=auto`，ruyi 优先 | **1/1，上传 1/1，0 个 5025，20.6s** |

Tanuki 输出为 `TANUKI_RESULT 400 ... "error_code":5025`，不是线程、IP 或邮箱问题；
同 IP 的 ruyi TLS159 1/1，说明是 **Tanuki 0.2.0 CEF 146 路径自身被 patch**。
v2.2.0 的 auto 模式会在 ruyi 连续 5025 后自动尝试 Tanuki，再切回。

## v2.1.2 — 默认无限轮（未新增实测）

- `POST /batch` / `ruyi_batch.py`：`rounds=0` 为默认，一轮接一轮直到
  `seconds=3400` 或 `action=stop`；`rounds=20/28` 仍是固定模式。
- `scripts/run_multi.py`：默认 2 个独立项目，`--rounds 0`；每个项目只调用
  一次 `/batch`，之后轮询状态；两个项目必须分别传 signed URL/token。
- 无限模式状态：`rounds_mode="unlimited"`、`rounds_target=0`，
  `rounds_done` 随每轮递增。
- 历史 28 轮结果保留在下方：1,260/1,260，0 个 2014。

## v2.1.1 — 默认批次调整（未新增实测）

根据 v2.1.0 的 20+8 轮结果，把默认生产批次改为：

- **2 个独立项目 / 容器 × 5 线程 × 9 账号 × 20 轮 = 1,800 个/批**
- `scripts/run_multi.py` 一次启动两个项目；每个项目一次 `POST /batch` 跑 20 轮，
  客户端只轮询状态；不再每轮请求。
- 两个容器必须两个项目：`--signed-url-b` / `--token-b`；缺失直接报错。
- `/batch` 与 `ruyi_batch.py` 的默认 `rounds` 从 28 改为 20。
- 20 轮按 ruyi 实测约 2,050s，给 1 小时沙箱留约 1,500s 余量。

历史 28 轮完整结果保留在下方（1,260/1,260，0 个 2014）。

## v2.1.0 — Tanuki CEF 实测（2026-11-24）

> 07:40 UTC 结论更新：Tanuki 0.2.0 在 p.js 更新后全部 5025；同一 IP ruyi
> TLS159 仍成功。完整 5×9×28 改用 ruyi `/batch`，Tanuki 仅保留实验。

项目：`tw-tanuki-test`（overseas / SG，直连 `43.159.46.37`，上传开，单线程）。
内核：Tanuki v0.2.0，内嵌 Chromium 146.0.12 / CEF `libcef.so` 239MB；
Release `tanuki-linux-x64.tar.xz` 75MB，解压后 256MB。

| 步骤 | 结果 |
|---|---|
| 首次安装 | 10.5s：75MB 下载（11.5MB/s）+ SHA256 校验 + 解压；`ldd` 无缺失，无需 apt |
| 1 账号 | **1/1**，`TANUKI_RESULT 422 error_code:2026` → Step2 200，上传 1/1，18.2s，0 个 5025 |
| 5 账号 | **5/5**，上传 5/5，0 失败，0 个 5025，0 个 2014，98.0s（约 19.6s/账号） |
| 5×9×1 轮 | 42/45，上传 42，3 失败（1 次 mail API、1 次 CEF rc=1、1 次 5025），194.4s |
| p.js 07:40 后 | 7 个不同 EdgeOne IP 各 1 账号：**全部 5025**；同 IP ruyi TLS159 1/1，45/45 |

ruyi `/batch` 5×9×1 单轮（p.js 07:40 后，IP `43.134.62.198`）：
**45/45，上传 45/45，0 失败，1 次会话级 5025，103.9s**。

### 完整 5×9×28（ruyi `/batch`）

第一个沙箱已有 14 分钟历史，1 小时生命周期在第 20 轮到期，因此分两个沙箱完成
28 轮；`startRound` 从 21 续跑。

| 沙箱 | 轮次 | 注册 | 上传 | 失败尝试 | 5025 | 2014 | 用时 |
|---|---|---|---|---|---|---|---|
| A `43.134.62.198` | 1–20 | **900/900** | 900 | 11 | 6 | 0 | 2,372.2s |
| B `43.128.110.187` | 21–28 | **360/360** | 360 | 1 | 1 | 0 | 782.3s |
| **合计** | **28** | **1,260/1,260** | **1,260** | **12** | **7** | **0** | **3,154.5s** |

- 注册率 **100%**，上传率 **100%**，0 个 2014。
- 12 次失败尝试都被 `run.py` 重试后成功，不减少最终账号数。
- 5025 都是会话级（约 14–15 个/会话）；每轮新建 5 个 Context，自动重建。
- 如果使用全新沙箱从第 1 轮起跑，28 轮约 3,150s，在 3,400s 预算内。

关键结论：

- Tanuki 在 EdgeOne SG 沙箱可直接跑，**不需要额外系统库**；`ldd` 对
  `tanuki-cef` 与 `libcef.so` 均无 `not found`。
- `run_cef.sh` 的 `TANUKI_CEF_SINGLE=1` 路径会卡到 150s 超时（只有 DBus/ALSA/
  `resources.pak` 警告，没有 `EMAIL`/`STEP1`）；改为直接运行 `tanuki-cef`
  **多进程**（`mode=multi`）后稳定。
- 5 个账号全部一次通过（07:40 前），没有 ruyijs 的会话级 5025；每个 Tanuki 进程一个账号。
- 07:40 p.js 更新后，Tanuki 0.2.0（CEF 146）在 7 个 EdgeOne IP 上全部 5025；
  同一 IP 的 ruyi TLS159 仍 1/1、45/45。被 patch 的是 CEF 146 路径。
- 上传复用现有 TwitchCDK 上传器，Cookie 为 Tanuki 输出的 8 个 `.twitch.tv` Cookie。
- 计时：1 账号 18.2s、5 账号 98.0s；Tanuki README 的 Linux 参考值 16.8s/账号。

## v2.0.1 — 5025 复测（2026-11-22）

Twitch 在 2026-11-22 07:00 UTC 更新 p.js 后，EdgeOne SG 沙箱的 ruyijs 注册
从 step1 起全部 5025（单线程 5 账号：0 成功，20 个会话，20 次 5025）。
WARP、直连、Windows/Linux 指纹、geo cookie 均无法恢复；同一代码在本机
Windows ruyijs + HK 住宅代理可 1/1 成功，说明 EdgeOne IP 不是唯一变量。

最终修复：ruyijs `Context(tls="159")` + Firefox 159 UA，保留 ruyijs 0.4.3。
复测项目：`tw-5025-single`（overseas / SG，直连，上传开，单线程）。

| 轮次 | 账号 | 成功 | 上传 | 失败 | 5025 | 2014 | 耗时 |
|---|---|---|---|---|---|---|---|
| 1 | 1 | 1/1 | 1/1 | 0 | 0 | 0 | 18.1s |
| 2 | 30 | **30/30** | **30/30** | 0 | 2（会话级） | 0 | 272.4s |

结论：

- 5025 不再是开局全拒；回到约 14–15 个/会话的会话级边界，自动重建后继续。
- `tls="159"` 与 UA/`oscpu`/`platform` 必须一起改；只改 UA 或只改 TLS 仍 5025。
- `ruyijs` 依赖标记必须绑定 bundle 版本，否则旧沙箱会继续用 0.4.1。
- 30 个账号消耗约 272s，单线程约 6.6s/账号；2 容器 5 线程参数不变。

## 部署对象

| 项目 | 区域 | 用途 | 结果 |
|---|---|---|---|
| `tw-reg-mk1` | global / 大陆沙箱 | 首轮验证 | 沙箱出口 `49.233.174.162`（CN），CloakBrowser 下载源被墙，放弃 |
| `tw-reg-mk2` | overseas / SG 沙箱 | 主测试 | 依赖、CloakBrowser、字体、probe 全通；注册 5025 |
| `tw-relay-mk1` | overseas / Edge Functions | 边缘 relay | `/relay` 正常执行，边缘出口 `43.152.24.203`（HKG） |

## 结果矩阵

| # | 页面加载出口 | 注册 POST 出口 | 浏览器/环境 | 结果 |
|---|---|---|---|---|
| 1 | 本机 7897（HK 住宅） | 本机 7897（HK 住宅） | Windows CloakBrowser 146 | **成功 1/1**（36.2s） |
| 2 | SG 沙箱 `43.163.122.167` | SG 沙箱 | Linux CloakBrowser 146 + Windows 指纹 + 7/8 字体 | 5025 |
| 3 | SG 沙箱 | Edge relay `43.152.24.203`（HKG） | 同上 | 5025（`relay POST -> 400`） |
| 4 | Edge relay（全页 HTML/p.js/gql） | Edge relay | **本机 Windows CloakBrowser 146** | 5025 |
| 5 | SG 沙箱 | WARP SIN `104.28.222.46` | **ruyijs（Linux Firefox 引擎）** | **成功 1/1（12.1s）、2/2（22.2s）、1/1（27.5s）** |
| 6 | SG 沙箱 | **沙箱本机 IP（直连，无 WARP）** | **ruyijs** | **成功 1/1（16.9s）、2/2（24.4s）** |
| 7 | SG 沙箱 | **沙箱本机 IP（直连）** | **ruyijs，3 workers × 15** | **45/45 成功，上传 45/45，203.3s** |
| 8 | SG 沙箱 | **沙箱本机 IP（直连）** | **ruyijs，5 workers × 9（优化）** | **45/45 成功，0 失败，上传 45/45，runner 111.1s** |

### 效率优化对比

| 配置 | 成功 | 失败尝试 | 会话 | runner 耗时 | 总耗时 | 上传 |
|---|---|---|---|---|---|---|
| 3×15（基准） | 45/45 | 2 | 6 | 203.3s | 206.4s | 45/45 |
| **5×9（优化）** | **45/45** | **0** | 6 | **111.1s** | **125.9s** | **45/45** |
| 提升 | — | — | — | **-45.3%** | **-39%** | — |

优化项：

1. `workers` 上限 3 → 6；`maxConcurrentCtx` 默认等于 `workers`（5），
   沙箱内同时跑 5 个 ruyijs Context。
2. 保留 `START_STAGGER_SEC=3`，避免 5 个 Context 同时打 `/tl` 触发开局 5025；
   本次 5×9 失败尝试为 0。
3. `syncProject` 增加 bundle 版本标记：版本未变时跳过 16 个文件写入
   （本次批次的 `files=0`），只做读状态。
4. 默认 `engine=ruyi`，不下载 206MB CloakBrowser，沙箱磁盘和冷启动都更轻。
5. 上传随 worker 并发，45 个账号仍 `uploaded=45, upload_failed=0`。

5×9 总耗时 125.9s，与 GA Windows XEHN 3×15 的 125.9s 持平；账号量和上传量一致。

### 3×15 对标 GA（2026-11-21）

配置：`workers=3, accounts=15, engine=ruyi, proxy=direct, upload=true,
startStagger=3, maxFails=12, timeout=540`。

```text
success=45  requested=45  failed=2  sessions=6
elapsed=203.3s
uploaded=45  upload_failed=0
proxy=direct（沙箱本机 IP，无 WARP）
```

对标 GA Windows XEHN `3×15`（README：45/45，2 failed，125.9s，上传 45/45）：

| 指标 | GA Windows + XEHN WARP | EdgeOne Sandbox + ruyijs |
|---|---|---|
| 注册 | 45/45 | **45/45** |
| 失败尝试 | 2 | 2 |
| 会话 | 3 线程 | 6（2014/5025 轮换） |
| 耗时 | 125.9s | 203.3s |
| 上传 | 45/45 | **45/45** |
| 出口 | 每 runner 一条 WARP | 沙箱本机 IP（直连） |

成功率 100%，上传率 100%；EdgeOne 慢约 77s（ruyijs 原生 Firefox 进程 + SG 沙箱）。

第 5 组是最终答案：同一台 SG 沙箱、同一条 WARP SIN 出口，换成 **ruyijs** 后连续
注册成功。第 2/3/4 组的 5025 是 **CloakBrowser 的 Linux/Windows 伪装**造成的，
不是 WARP/EdgeOne 出口 IP。

### 直连（无 WARP）成功日志

```text
06:48:15 | INFO | probe: engine=ruyi proxy=直连
06:48:16 | INFO | p.js 已下载并缓存: 159570B → pjs_1795243696.js
             ready: true
06:48:43 | INFO | [1] tw481f20cbd0 注册成功 (uid=1612386014 ...)
06:48:43 | INFO | 合计: 成功=1/1 失败=0 会话总数=1 总耗时=16.9s 每账号=16.95s
```

第二组：`success=2 failed=0 elapsed=24.4s`，`proxy=direct`。

### ruyijs + WARP 成功日志

```text
06:32:15 | INFO | ruyi 版开始: 线程=1 每线程=1 合计=1 上传=关
06:32:15 | INFO | 出口: http://127.0.0.1:25345 模式=cloak cdp=no
06:32:21 | INFO | [1] tw60ced50778 验证码已发送
06:32:26 | INFO | [1] tw60ced50778 收到验证码
06:32:27 | INFO | [1] tw60ced50778 注册成功 (uid=1612380437 ...)
06:32:27 | INFO | [R0] OK #1/1 tw60ced50778 已落盘 (7.4s, 会话累计=1)
06:32:27 | INFO | 合计: 成功=1/1 失败=0 会话总数=1 总耗时=12.1s 每账号=12.13s
```

第二组 2 账号：`success=2 failed=0 elapsed=22.2s`；默认引擎（不传 `engine`）：
`success=1 failed=0 elapsed=27.5s`（首次 Context 因沙箱磁盘被失败 CloakBrowser
下载占满而 AbortError，重试一次成功）。

## WARP 实测（usque / MASQUE）

- 客户端：usque `4.2.1`，Linux x64，用户态，无 TUN/root
- 传输：HTTP/2（TCP/443）可用；QUIC 全部端点超时（沙箱封 UDP）
- 端点：`162.159.198.2`，出口 `104.28.222.43 / colo=SIN / loc=SG / warp=on`
- Twitch 探测：`200`
- 轮换 12 次身份：出口只出现两个 /24
  - `104.28.222.43`、`104.28.222.47`
  - `104.28.254.46`、`104.28.254.47`
- 在这两个 /24 上跑 **CloakBrowser** 注册：全部 5025
- 同一条 WARP 出口换 **ruyijs**：1/1、2/2、1/1 全部成功
- 本机 XEHN（原项目 Windows 客户端）在本地网络扫不到可用 WARP 端点；
  usque 本地也连不上 `162.159.198.2:443`。本地网络本身封 WARP，无法做本机 WARP 对照

结论：WARP 在 EdgeOne 沙箱内**隧道层和出口都可用**；SIN WARP 池**不是** 5025 的原因。
之前把 5025 归因于 WARP IP 是错的——真正的变量是浏览器引擎：CloakBrowser 的
Linux/Windows 伪装被 Kasada 拒，ruyijs（真实 Firefox SpiderMonkey + Necko）通过。

## 单 worker 上限测试（2026-11-21）

配置：`workers=1, maxConcurrentCtx=1, startStagger=0, cooldown=0,
upload=false, engine=ruyi, proxy=direct`。

| 轮次 | 成功 | 失败 | 会话 | 5025 | 2014 | 耗时 | 5025 位置 |
|---|---|---|---|---|---|---|---|
| 1×30（新沙箱） | 30/30 | 0 | 3 | 2 | 0 | 287.7s | #14 step2、#28 step2 |
| 1×45（新沙箱） | 45/45 | 0 | 4 | 3 | 0 | 407.9s | #16 step2、#28 step2、#43 step1 |
| 同沙箱 +15（累计 60） | 15/15 | 0 | 2 | 1 | 0 | 151.4s | #15 step2 |
| **累计 60** | **60/60** | **0** | **6** | **4** | **0** | **559.3s** | 每会话约 14–15 个 |

结论：

- **5025 是会话级边界，不是累计 IP 耗尽。** 每个 ruyijs 会话注册约 14–15 个后，
  下一次 step1/step2 会 5025；重建 Context 后继续，下一次又约 14–15 个。
- 60 个账号只出现 4 次 5025（约 6.3% 尝试），0 个 2014，0 失败；
  `MAX_CONSECUTIVE_5025=5` 没有触发。
- 单 worker 的实际上限：
  - **零 5025 目标：14 个/worker**（留余量用 9 个/worker，5×9 即 0 失败）。
  - **允许自动重建：45 个/worker**（45/45，3 次 5025，407.9s）；
    60 个/worker 也可（累计 60/60，4 次 5025，559.3s），但单请求会超过
    540s 超时，建议拆成 45 + 15。
  - **批量效率：5×9（45）111.1s**，明显优于 1×45 的 407.9s 和 3×15 的 203.3s。
- 2014 在 60 个内没有出现；原 README 的“单 IP ≤15”应理解为**单会话 ≤15**，
  不是单 IP 总量。

## EdgeOne 沙箱配额上限（2026-11-21）

继续加轮时命中：

```text
SANDBOX_LIMIT_EXCEEDED: pages-sandbox-cpu-duration
(code=SANDBOX_LIMIT_EXCEEDED, operation=acquire, businessCode=LimitExceeded)
```

- 第 1 轮（上传默认开启）：45/45，上传 45/45，4 会话，3 次 5025（#13/#27 step1、#39 step2），
  0 个 2014，430.5s。
- 第 2 轮立即失败：沙箱无法 acquire，`pages-sandbox-cpu-duration` 配额耗尽；
  这不是 Twitch 的 5025/2014，也不是 worker 的 5025 上限。
- 结论：**当前 plan 的硬上限是 EdgeOne Sandbox CPU 时长配额**。
  在配额内，单 worker 45 个稳定（45/45，0 失败，上传 45/45）；
  要继续测 90/135/180 累计，必须升级 plan 或等配额重置。
- 5025 的会话级规律不受影响：约每 14–15 个出现一次，重建后继续；
  60 个内 2014 仍为 0。

## 新工作区复测（累计 180，2026-11-21）

新 token / 工作区 `zone-3xorszfengaj`，`engine=ruyi`，直连，上传默认开启。
**所有轮次均为 `workers=1`、`maxConcurrentCtx=1`（单线程串行）**，不是 3×15/5×9 的多线程模式：

| 轮次 | 数量 | 成功 | 失败 | 会话 | 5025 | 2014 | 耗时 | 上传 |
|---|---|---|---|---|---|---|---|---|
| 1 | 45 | 45 | 0 | 4 | 3 | 0 | 422.5s | 45/45 |
| 2 | 30 | 30 | 0 | 2 | 1 | 0 | 242.6s | 30/30 |
| 3 | 30 | 30 | 0 | 3 | 2 | 0 | 262.7s | 30/30 |
| 4 | 30 | 30 | 0 | 3 | 2 | 0 | 275.5s | 30/30 |
| 5 | 30 | 8（超时） | — | — | — | — | 540s 超时 | 部分 |
| 6 | 15 | 15 | 0 | 2 | 1 | 0 | 174.9s | 15/15 |
| 7 | 30 | 0（沙箱过期） | — | — | — | — | 230.7s 终止 | — |
| 8 | 30 | 30 | 0 | 4 | 3 | 0 | 470.6s | 30/30 |

- 完成累计：**180/180，上传 180/180，0 失败，0 个 2014**。
- 5025 仍是会话级：每会话约 14–15 个出现一次；完成轮次共 12 次，重建后继续。
- 第 5 轮是 `run.py` 被 540s 命令超时杀掉（完成 8 个），不是 Twitch 上限；
  rotate 新沙箱后继续。
- 第 7 轮命中 **单沙箱 1 小时生命周期**：
  `expiresAt=2026-11-21T19:13:08+08:00`，命令 `terminated`；
  rotate 新沙箱后第 8 轮继续成功。
- 新工作区未再出现 `pages-sandbox-cpu-duration` 配额错误；
  但 Free 版总配额仍是 18,000 vCPU-s，长时间多轮要留意控制台用量。

### 容器规格实测（cgroup）

在沙箱内读取（`/diag` 的 `hardware`）：

```text
nproc=3
processors=3
cgroup_v1_quota=200000
cgroup_v1_period=100000
mem_total_kb=4264576
cgroup_v1_mem_limit=4294967296
cpus_allowed=Cpus_allowed_list: 0-2
```

- **CPU：2 vCPU**（cgroup v1 `200000/100000 = 2`）；`nproc=3` 是 cpuset 可见 3 核，
  计费按 cgroup 的 2 vCPU。
- **内存：4 GiB**（cgroup `4294967296`；`MemTotal` 4,264,576 KB ≈ 4.07 GiB）。
- 因此当前配置是 **2 vCPU / 4 GiB**。

按 Free 版配额：

| 配额 | 计算 | 可跑满 1 小时的容器 |
|---|---|---|
| Sandbox CPU time 18,000 vCPU-s | `18,000 ÷ (2 × 3,600)` | **2.5 容器小时 → 2 个满 1 小时 + 0.5 小时余量** |
| Sandbox memory 100,000 GB-s | `100,000 ÷ (4 × 3,600)` | 6.9 → 6 个（不是瓶颈） |
| 最大并发实例 20 | — | 20 并发，但受上面 CPU 配额约束 |

- 实际是 **2 个容器跑满 1 小时**，第 3 个最多再跑 0.5 小时（1,800 vCPU-s）。
- 新工作区 180 个账号约消耗：第一个 1 小时容器 7,200 vCPU-s + 第 8 轮 470s 沙箱
  约 940 vCPU-s ≈ **8,140 vCPU-s**，约为 18,000 的 45%；剩余约 9,860 vCPU-s，
  还能再跑一个满 1 小时容器 + 剩余。
- 旧工作区耗尽 18,000 vCPU-s 与 2 vCPU × 多轮沙箱时长一致。

### 观测到的三个上限

1. **单会话**：约 14–15 个账号后 step1/step2 5025；重建 Context 后继续。
2. **单沙箱**：最长 3,600s（Free）；到点命令被 terminated，需要 `/rotate` 新实例。
3. **工作区套餐**：Free 版 Sandbox CPU time 18,000 vCPU-s；
   旧工作区已实测耗尽 `pages-sandbox-cpu-duration`，新工作区尚未耗尽。

## 2 容器 × 5 线程 × 1 小时（2026-11-21）

架构：**两个独立 Makers 项目**（`tw-multi` / `tw-multi-b`），每个项目一个容器。
同项目两个 `Makers-Conversation-Id` 并发 warm 会 `RemoteDisconnected`，所以走两个项目。

配置：`workers=5, accounts=9`（5×9=45/轮），`upload=true`，`startStagger=3`，
`maxConcurrentCtx=5`，`cooldown=0`，脚本在 3,400s 前收尾。

| 容器 | 轮次 | 注册 | 上传 | 失败尝试 | 5025 | 2014 | 用时 |
|---|---|---|---|---|---|---|---|
| A（tw-multi） | 29 | 1,305 | 1,305/1,305 | 6 | 2 | 0 | 3,268s |
| B（tw-multi-b） | 29 | 1,305 | 1,305/1,305 | 5 | 3 | 0 | 3,255s |
| **合计** | **58** | **2,610** | **2,610/2,610** | **11** | **5** | **0** | **~54.5 分钟** |

- 每个容器 5 线程，每轮 5×9=45 个；每 worker 9 个，避开 14–15 的会话边界。
- **推荐参数：2 worker（两个独立项目/进程）× 5 线程 × 28 轮/容器 = 2,520 个/批**；
  本次跑了 29 轮/容器（2,610），28 轮给 1 小时到期留约 500s 余量。
- 0 上传失败，0 个 2014；5 次 5025 都自动重建后继续。
- 18,000 vCPU-s 配额：`2 容器 × 2 vCPU × 3,400s = 13,600 vCPU-s`，在配额内，
  还剩约 0.5 小时（1,800 vCPU-s）。
- 单沙箱 1 小时生命周期未撞到：A 最后一次 3,268s、B 3,255s，脚本按 3,400s 停止。
- 约 **48 个/分钟** 总产出；单容器约 **24 个/分钟**。
- 注意：`run_multi.py --containers 2` 在**同一项目**里并发 warm 会被断；
  2 容器要用**两个项目**、两个 `run_multi.py --containers 1` 进程，或两个 signed URL。

## 5025 响应体

```json
{"request_id":"01M7Y...","has_existing_account":false,"error_code":5025}
```

无额外原因字段。边缘 relay 的 `relay POST -> 400 (90B)` 就是这个响应。

## 已排除的因素

- TLS/UA：Windows 指纹已生效（`Mozilla/5.0 (Windows NT 10.0; Win64; x64) ... Chrome/146`）
- 字体：已灌入 Segoe UI / Segoe UI Light / Calibri / Marlett / Franklin Gothic /
  Consolas / Courier New，诊断 `Win fonts: partial (7/8)`，只缺 MS UI Gothic
- 浏览器进程重建：每次 5025 都换新进程，仍拒绝
- p.js / KPSDK：`probe` 返回 `ready: true`
- 页面与 POST 的 IP 一致性：全页 relay 后仍 5025
- 邮箱 API：SG 沙箱可达（`status=200 time=4.6s`）
- Twitch 可达：SG 沙箱 `www.twitch.tv/signup` 200

## 已验证可用的部分

- Makers Agent + Sandbox 冷启动、pip install、CloakBrowser 206MB 下载（SG 约 1–2 分钟）
- `--probe`：KPSDK ready
- Windows 字体上传与 `fc-cache`
- Edge Function 独立项目 relay（set-cookie、gql、passport 转发）
- WARP：usque 下载/注册/HTTP2 隧道/代理探针/身份轮换（`warp=on`，Twitch 200）
- **ruyijs（Linux Firefox）**：probe + 注册；直连 **3/3**、WARP **4/4**；
  3×15 直连 **45/45，上传 45/45**
- `POST /rotate` kill 沙箱

## 结论

**“只用 EdgeOne 自带 IP”已经跑通：EdgeOne Sandbox + ruyijs，直连默认，WARP 可选。**

最终可用的组合：

1. 沙箱：EdgeOne Makers Agent + Sandbox（Linux，SG）
2. 引擎：`engine=ruyi`（Linux ruyijs / Firefox SpiderMonkey + Necko，无窗口）
3. 字体：`fonts/fontconfig.conf` 指向 DejaVu（系统字体 + 上传的 Windows 字体）
4. 出口：**默认 `direct`（沙箱本机 IP）**；需要换 IP 时可选
   沙箱内 usque WARP（`127.0.0.1:25345`）
5. 结果：
   - **直连（无 WARP）：`1/1`（16.9s）、`2/2`（24.4s）**
   - **3×15 直连：45/45，上传 45/45，203.3s**
   - WARP：`1/1`（12.1s）、`2/2`（22.2s）、默认引擎 `1/1`（27.5s）

之前的 5025 不是 EdgeOne/WARP IP 的问题，而是 **CloakBrowser 的 Linux/Windows
伪装**被 Kasada 拒：

| 引擎 | 沙箱 | 出口 | 结果 |
|---|---|---|---|
| CloakBrowser（Linux 二进制 + Windows 指纹） | SG | 直连 / Edge relay / WARP SIN | 5025 |
| ruyijs（Linux Firefox） | SG | 直连 / WARP SIN | **成功（3×15 45/45）** |

`cloady-direct` 分支的关键修复：DejaVu fontconfig、`/mfc` CORS 桩、
ruyijs Context（真实 Firefox 引擎）、usque HTTP/2 WARP。Makers 版已按这些移植。

如果后续要跑更大批量：单 WARP IP 建议 ≤15 个/窗口（原项目实测），
用 `/warp rotate` 换身份/出口，或每轮重建沙箱换 IP。

## 资源清理

- `tw-reg-mk1` 沙箱：已 `/rotate` kill
- `tw-reg-mk2` 沙箱（CloakBrowser/WARP 测试会话）：已 `/rotate` kill
- `tw-reg-mk2` 沙箱（ruyijs 测试会话 `twreg-ruyi-001`）：已 `/rotate` kill
- `tw-reg-mk2` 沙箱（直连测试会话 `twreg-direct-001`）：已 `/rotate` kill
- `tw-reg-bench` 沙箱（3×15 会话 `twreg-bench-001`）：已 `/rotate` kill
- `tw-reg-opt` 沙箱（5×9 会话 `twreg-opt-001`）：已 `/rotate` kill
- `tw-reg-limit` 沙箱（1×30 / 1×45 / +15 会话 `twreg-limit-001`）：已 `/rotate` kill
- `tw-reg-next` 沙箱（新工作区第 1 轮 `twreg-next-001`）：已 `/rotate` kill
- `tw-reg-final` 沙箱（新工作区累计 180，会话 `twreg-final-001`）：已 `/rotate` kill
- **七个 Makers 项目已全部删除**：`tw-reg-mk1`、`tw-reg-mk2`、`tw-relay-mk1`、
  `tw-reg-bench`、`tw-reg-opt`、`tw-reg-limit`、`tw-reg-final`；
  两个工作区都没有运行中的 Agent/函数项目
- 3×15 的 45 个账号已上传（`reg_edgeone_bench`，45/45）
- 5×9 的 45 个账号已上传（`reg_edgeone_opt`，45/45）
- 新工作区累计 180 个账号已上传（`reg_edgeone_final`，180/180）；
  第 5/7 轮的部分账号也是逐号上传，文件随沙箱过期丢失
- 旧工作区上限测试的 90 个账号（30+45+15）未上传（`upload=false`），沙箱已删除
- 测试用 `REG_API_TOKEN` 随项目删除；signed URL/cookie 与本地 token 文件已删除
- `node_modules` / `.edgeone` / 测试日志已清理，仓库只保留源码与文档
