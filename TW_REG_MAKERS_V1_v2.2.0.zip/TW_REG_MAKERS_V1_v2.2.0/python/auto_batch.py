"""Continuous 5-thread batch with automatic ruyi <-> Tanuki fallback.

Default: 5 workers x 9 accounts per worker per round, unlimited rounds, until
the container dies or `seconds` budget is reached. ruyi is used first. If
ruyijs has consecutive zero-success rounds with Kasada 5025, switch to Tanuki
for the next round; if Tanuki also keeps failing, switch back. The loop
continues until the container ends.

Tanuki is installed on first use from the private release asset if a token file
is present; otherwise the runner stays on ruyi and logs the missing runtime.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tarfile
import time
from pathlib import Path

from loguru import logger

MARKER = "TWREG_RESULT "
TANUKI_ASSET = "https://api.github.com/repos/xbox-cn/tanuki/releases/assets/785826846"
TANUKI_SHA = "241b1cf3b5c691efc6276ec701669f92ea2ea72b98181dc470f32e36af2689f2"


def write_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def parse_result(stdout: str) -> dict | None:
    for line in reversed(stdout.splitlines()):
        if line.startswith(MARKER):
            try:
                return json.loads(line[len(MARKER):])
            except json.JSONDecodeError:
                return None
    return None


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ensure_tanuki(args: argparse.Namespace) -> bool:
    root = Path(args.tanuki_dir)
    if (root / "tanuki-cef").is_file() and (root / "cef" / "libcef.so").is_file():
        return True
    token_file = Path(args.tanuki_token_file)
    if not token_file.is_file():
        logger.warning("Tanuki 未安装且没有 token 文件，跳过 Tanuki")
        return False

    archive = root.parent / "tanuki.tar.xz"
    try:
        proc = subprocess.run(
            ["curl", "-fL", "--retry", "3", "-H", f"@{token_file}",
             "-H", "Accept: application/octet-stream", "-o", str(archive),
             TANUKI_ASSET],
            text=True, capture_output=True, timeout=360,
        )
        if proc.returncode != 0:
            logger.warning(f"Tanuki 下载失败: {proc.stderr[-500:]}")
            return False
        if sha256(archive) != TANUKI_SHA:
            logger.warning("Tanuki SHA256 不匹配")
            return False
        extract_root = root.parent
        with tarfile.open(archive) as tar:
            tar.extractall(extract_root)
        extracted = extract_root / "tanuki-linux"
        if not extracted.is_dir():
            logger.warning("Tanuki 解压目录不存在")
            return False
        if root.exists():
            import shutil

            shutil.rmtree(root)
        extracted.rename(root)
        (root / "tanuki-cef").chmod(0o755)
        (root / "run_cef.sh").chmod(0o755)
        logger.info("Tanuki 安装完成")
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"Tanuki 安装异常: {type(exc).__name__}: {exc}")
        return False
    finally:
        archive.unlink(missing_ok=True)
        token_file.unlink(missing_ok=True)


def run_ruyi_round(args: argparse.Namespace, rnd: int, workers: int,
                   accounts: int, accounts_dir: Path, logs_dir: Path) -> tuple[dict | None, int, str, float]:
    cmd = [
        sys.executable, "run.py",
        "--workers", str(workers),
        "--accounts", str(accounts),
        "--engine", "ruyi",
        "--proxy", "direct",
        "--upload" if args.upload else "--no-upload",
        "--start-stagger", "3",
        "--cooldown-sec", "0",
        "--max-fails", str(args.max_fails),
        "--log-dir", str(logs_dir),
        "--accounts-dir", str(accounts_dir),
    ]
    env = dict(os.environ)
    env["MAX_CONCURRENT_CTX"] = str(workers)
    env["WORKER_NAME"] = f"{args.worker_name}-ruyi-r{rnd}"
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd, cwd=Path.cwd(), env=env, text=True,
            capture_output=True, timeout=args.timeout * 2 + 60,
        )
        output = (proc.stdout or "") + (proc.stderr or "")
        rc = proc.returncode
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") + (exc.stderr or "")
        rc = -9
    return parse_result(output), rc, output, time.time() - t0


def run_tanuki_round(args: argparse.Namespace, rnd: int, workers: int,
                     accounts: int, accounts_dir: Path, logs_dir: Path) -> tuple[dict | None, int, str, float]:
    if not ensure_tanuki(args):
        return None, -2, "tanuki unavailable", 0.0
    cmd = [
        sys.executable, "tanuki_runner.py",
        "--tanuki-dir", str(Path(args.tanuki_dir).resolve()),
        "--mode", "multi",
        "--workers", str(workers),
        "--rounds", "1",
        "--start-round", "1",
        "--accounts", str(accounts),
        "--accounts-dir", str(accounts_dir),
        "--logs-dir", str(logs_dir),
        "--proxy", "none",
        "--country", "auto",
        "--timezone", "Asia/Singapore",
        "--timeout", "120",
        "--code-timeout", "60",
        "--max-fails", str(args.max_fails),
        "--worker-name", f"{args.worker_name}-tanuki-r{rnd}",
    ]
    cmd.append("--upload" if args.upload else "--no-upload")
    env = dict(os.environ)
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd, cwd=Path.cwd(), env=env, text=True,
            capture_output=True, timeout=args.timeout * 3 + 60,
        )
        output = (proc.stdout or "") + (proc.stderr or "")
        rc = proc.returncode
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") + (exc.stderr or "")
        rc = -9
    return parse_result(output), rc, output, time.time() - t0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--accounts", type=int, default=9,
                        help="accounts per worker per round")
    parser.add_argument("--rounds", type=int, default=0,
                        help="0 = unlimited until seconds/stop")
    parser.add_argument("--start-round", type=int, default=1)
    parser.add_argument("--seconds", type=int, default=0,
                        help="0 = run until the container dies")
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--max-fails", type=int, default=12)
    parser.add_argument("--engine", choices=["auto", "ruyi", "tanuki"], default="auto")
    parser.add_argument("--switch-after", type=int, default=2,
                        help="consecutive zero-success 5025 rounds before switching")
    parser.add_argument("--tanuki-dir", default="tanuki")
    parser.add_argument("--tanuki-token-file", default=".tanuki_gh")
    parser.add_argument("--accounts-dir", default="accounts")
    parser.add_argument("--logs-dir", default="logs")
    parser.add_argument("--state-file", default="logs/ruyi_batch_state.json")
    parser.add_argument("--progress-file", default="logs/ruyi_batch_progress.jsonl")
    parser.add_argument("--stop-file", default="logs/ruyi_batch.stop")
    parser.add_argument("--worker-name", default="reg_auto_batch")
    parser.add_argument("--upload", dest="upload", action="store_true", default=True)
    parser.add_argument("--no-upload", dest="upload", action="store_false")
    args = parser.parse_args()

    workers = max(1, args.workers)
    accounts = max(1, args.accounts)
    rounds = max(0, args.rounds)
    accounts_dir = Path(args.accounts_dir)
    logs_dir = Path(args.logs_dir)
    accounts_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    state_path = Path(args.state_file)
    progress_path = Path(args.progress_file)
    stop_path = Path(args.stop_file)
    stop_path.unlink(missing_ok=True)

    started = time.time()
    deadline = started + args.seconds if args.seconds > 0 else float("inf")
    totals = {"success": 0, "failed": 0, "uploaded": 0, "upload_failed": 0,
              "kpsdk_rejects": 0, "device_limiteds": 0, "sessions": 0}
    accounts_out: list[dict] = []
    engine = "ruyi" if args.engine == "auto" else args.engine
    consecutive_bad = 0
    switches = 0
    history: list[dict] = []

    def state(extra: dict | None = None) -> dict:
        payload = {
            "ok": True,
            "engine": engine,
            "engine_mode": args.engine,
            "engine_history": history[-20:],
            "switches": switches,
            "consecutive_bad": consecutive_bad,
            "version": "2.2.0",
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(started)),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "elapsed": round(time.time() - started, 1),
            "workers": workers,
            "accounts_per_worker": accounts,
            "rounds_target": rounds,
            "rounds_mode": "unlimited" if rounds == 0 else "fixed",
            "start_round": args.start_round,
            "rounds_done": 0,
            "total_target": workers * accounts * rounds if rounds else 0,
            **totals,
            "running": True,
        }
        if extra:
            payload.update(extra)
        write_json(state_path, payload)
        return payload

    logger.info(
        f"auto 批量开始: engine_mode={args.engine} engine={engine} "
        f"workers={workers} accounts={accounts} rounds={'∞' if rounds == 0 else rounds} "
        f"seconds={args.seconds or '∞'} switch_after={args.switch_after}"
    )
    state()

    done = 0
    stopped = "done"
    rnd = args.start_round
    while True:
        if rounds and done >= rounds:
            stopped = "done"
            break
        if stop_path.exists():
            stopped = "stop"
            break
        if time.time() >= deadline:
            stopped = "budget"
            break

        result: dict | None = None
        rc = -1
        output = ""
        elapsed = 0.0
        if engine == "tanuki":
            result, rc, output, elapsed = run_tanuki_round(
                args, rnd, workers, accounts, accounts_dir, logs_dir)
            if result is None and rc == -2:
                if args.engine != "auto":
                    stopped = "tanuki-missing"
                    break
                engine = "ruyi"
                history.append({"round": rnd, "engine": "ruyi", "switch": "tanuki-missing"})
                state()
                continue
        else:
            result, rc, output, elapsed = run_ruyi_round(
                args, rnd, workers, accounts, accounts_dir, logs_dir)

        success = int((result or {}).get("success") or 0)
        failed = int((result or {}).get("failed") or 0)
        uploaded = int((result or {}).get("uploaded") or 0)
        upload_failed = int((result or {}).get("upload_failed") or 0)
        kpsdk = int((result or {}).get("kpsdk_rejects") or 0)
        limited = int((result or {}).get("device_limiteds") or 0)
        sessions = int((result or {}).get("sessions") or 0)
        totals["success"] += success
        totals["failed"] += failed
        totals["uploaded"] += uploaded
        totals["upload_failed"] += upload_failed
        totals["kpsdk_rejects"] += kpsdk
        totals["device_limiteds"] += limited
        totals["sessions"] += sessions
        accounts_out.extend((result or {}).get("accounts") or [])
        done += 1

        bad = result is None or (
            success == 0 and kpsdk >= max(1, min(args.switch_after, workers))
        )
        if bad:
            consecutive_bad += 1
        else:
            consecutive_bad = 0

        history.append({"round": rnd, "engine": engine, "success": success,
                        "kpsdk": kpsdk, "bad": bad})
        record = {
            "t": time.strftime("%H:%M:%S"),
            "round": rnd,
            "engine": engine,
            "elapsed": round(elapsed, 1),
            "rc": rc,
            "success": success,
            "failed": failed,
            "uploaded": uploaded,
            "upload_failed": upload_failed,
            "kpsdk_rejects": kpsdk,
            "device_limiteds": limited,
            "sessions": sessions,
            "bad": bad,
        }
        with open(progress_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        logger.info(
            f"[round {rnd}] engine={engine} rc={rc} success={success}/{workers * accounts} "
            f"uploaded={uploaded} 5025={kpsdk} 2014={limited} bad={bad} {elapsed:.1f}s"
        )
        if rc != 0 and not result:
            logger.warning(f"[round {rnd}] engine={engine} rc={rc}; last output:\n{output[-1200:]}")

        if bad and args.engine == "auto" and consecutive_bad >= args.switch_after:
            old = engine
            engine = "tanuki" if engine == "ruyi" else "ruyi"
            switches += 1
            consecutive_bad = 0
            logger.warning(f"连续失败切换内核: {old} -> {engine}")
            history.append({"round": rnd, "engine": engine, "switch": f"{old}->{engine}"})
        state({"rounds_done": done, "engine": engine})
        rnd += 1

    state({"rounds_done": done, "running": False, "stopped": stopped})
    payload = {
        "success": totals["success"],
        "failed": totals["failed"],
        "sessions": totals["sessions"],
        "elapsed": round(time.time() - started, 1),
        "uploaded": totals["uploaded"],
        "upload_failed": totals["upload_failed"],
        "kpsdk_rejects": totals["kpsdk_rejects"],
        "device_limiteds": totals["device_limiteds"],
        "accounts": accounts_out,
        "version": "2.2.0",
        "engine": engine,
        "engine_mode": args.engine,
        "engine_history": history[-50:],
        "switches": switches,
        "workers": workers,
        "accounts_per_worker": accounts,
        "rounds_target": rounds,
        "rounds_mode": "unlimited" if rounds == 0 else "fixed",
        "start_round": args.start_round,
        "rounds_done": done,
        "total_target": workers * accounts * rounds if rounds else 0,
        "stopped": stopped,
    }
    (logs_dir / "last_run.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(MARKER + json.dumps(payload, ensure_ascii=False), flush=True)
    logger.info(
        f"合计: 成功={totals['success']} 失败={totals['failed']} "
        f"上传={totals['uploaded']} 上传失败={totals['upload_failed']} "
        f"rounds={done} switches={switches} 用时={payload['elapsed']}s"
    )
    Path(args.tanuki_token_file).unlink(missing_ok=True)
    return 0 if totals["success"] > 0 else 2


if __name__ == "__main__":
    sys.exit(main())
