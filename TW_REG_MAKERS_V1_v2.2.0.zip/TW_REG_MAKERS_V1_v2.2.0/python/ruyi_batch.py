"""Run a built-in ruyijs worker/round batch.

Each round invokes run.py with `workers` threads and `accounts` per worker.
The wrapper loops rounds without an external per-round request, aggregates
results, and writes state/progress for the /batch status route.

Example:
    python ruyi_batch.py --workers 5 --accounts 9 --rounds 0 --seconds 3400
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from loguru import logger

MARKER = "TWREG_RESULT "


def write_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def parse_result(stdout: str) -> dict | None:
    for line in reversed(stdout.splitlines()):
        if line.startswith(MARKER):
            try:
                return json.loads(line[len(MARKER):])
            except json.JSONDecodeError:
                return None
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--accounts", type=int, default=9)
    parser.add_argument("--rounds", type=int, default=0,
                        help="0 = run until the seconds budget/stop")
    parser.add_argument("--start-round", type=int, default=1)
    parser.add_argument("--seconds", type=int, default=3400)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--max-fails", type=int, default=12)
    parser.add_argument("--accounts-dir", default="accounts")
    parser.add_argument("--logs-dir", default="logs")
    parser.add_argument("--state-file", default="logs/ruyi_batch_state.json")
    parser.add_argument("--progress-file", default="logs/ruyi_batch_progress.jsonl")
    parser.add_argument("--stop-file", default="logs/ruyi_batch.stop")
    parser.add_argument("--worker-name", default="reg_ruyi_batch")
    parser.add_argument("--upload", dest="upload", action="store_true", default=True)
    parser.add_argument("--no-upload", dest="upload", action="store_false")
    args = parser.parse_args()

    workers = max(1, args.workers)
    accounts = max(1, args.accounts)
    rounds = max(0, args.rounds)
    accounts_dir = Path(args.accounts_dir)
    logs_dir = Path(args.logs_dir)
    accounts_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    state_path = Path(args.state_file)
    progress_path = Path(args.progress_file)
    stop_path = Path(args.stop_file)
    stop_path.unlink(missing_ok=True)

    started = time.time()
    deadline = started + args.seconds if args.seconds > 0 else float("inf")
    totals = {"success": 0, "failed": 0, "uploaded": 0, "upload_failed": 0,
              "kpsdk_rejects": 0, "device_limiteds": 0, "sessions": 0}
    accounts_out: list[dict] = []

    def state(extra: dict | None = None) -> dict:
        payload = {
            "ok": True,
            "engine": "ruyi",
            "version": "2.2.0",
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(started)),
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "elapsed": round(time.time() - started, 1),
            "workers": workers,
            "accounts_per_worker": accounts,
            "rounds_target": rounds,
            "rounds_mode": "unlimited" if rounds == 0 else "fixed",
            "start_round": args.start_round,
            "rounds_done": 0,
            "total_target": workers * accounts * rounds if rounds else 0,
            **totals,
            "running": True,
        }
        if extra:
            payload.update(extra)
        write_json(state_path, payload)
        return payload

    logger.info(
        f"ruyi 批量开始: workers={workers} accounts/worker={accounts} "
        f"rounds={'∞' if rounds == 0 else rounds} start_round={args.start_round} "
        f"seconds={args.seconds or '∞'} upload={args.upload}"
    )
    state()

    done = 0
    stopped = "done"
    rnd = args.start_round
    while True:
        if rounds and done >= rounds:
            stopped = "done"
            break
        if stop_path.exists():
            stopped = "stop"
            break
        if time.time() >= deadline:
            stopped = "budget"
            break

        cmd = [
            sys.executable, "run.py",
            "--workers", str(workers),
            "--accounts", str(accounts),
            "--engine", "ruyi",
            "--proxy", "direct",
            "--upload" if args.upload else "--no-upload",
            "--start-stagger", "3",
            "--cooldown-sec", "0",
            "--max-fails", str(args.max_fails),
            "--log-dir", str(logs_dir),
            "--accounts-dir", str(accounts_dir),
        ]
        env = dict(os.environ)
        env["MAX_CONCURRENT_CTX"] = str(workers)
        env["WORKER_NAME"] = f"{args.worker_name}-r{rnd}"
        t0 = time.time()
        try:
            proc = subprocess.run(
                cmd, cwd=Path.cwd(), env=env, text=True,
                capture_output=True, timeout=args.timeout * 2 + 60,
            )
            stdout = (proc.stdout or "") + (proc.stderr or "")
            rc = proc.returncode
        except subprocess.TimeoutExpired as exc:
            stdout = (exc.stdout or "") + (exc.stderr or "")
            rc = -9
        elapsed = time.time() - t0
        result = parse_result(stdout) or {}
        success = int(result.get("success") or 0)
        failed = int(result.get("failed") or 0)
        uploaded = int(result.get("uploaded") or 0)
        upload_failed = int(result.get("upload_failed") or 0)
        kpsdk = int(result.get("kpsdk_rejects") or 0)
        limited = int(result.get("device_limiteds") or 0)
        sessions = int(result.get("sessions") or 0)
        totals["success"] += success
        totals["failed"] += failed
        totals["uploaded"] += uploaded
        totals["upload_failed"] += upload_failed
        totals["kpsdk_rejects"] += kpsdk
        totals["device_limiteds"] += limited
        totals["sessions"] += sessions
        accounts_out.extend(result.get("accounts") or [])
        done += 1
        record = {
            "t": time.strftime("%H:%M:%S"),
            "round": rnd,
            "elapsed": round(elapsed, 1),
            "rc": rc,
            "success": success,
            "failed": failed,
            "uploaded": uploaded,
            "upload_failed": upload_failed,
            "kpsdk_rejects": kpsdk,
            "device_limiteds": limited,
            "sessions": sessions,
        }
        with open(progress_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        state({"rounds_done": done})
        logger.info(
            f"[round {rnd}] rc={rc} success={success}/{workers * accounts} "
            f"uploaded={uploaded} 5025={kpsdk} 2014={limited} {elapsed:.1f}s"
        )
        if rc != 0 and not result:
            logger.warning(f"[round {rnd}] run.py rc={rc}; last output:\n{stdout[-1200:]}")
        rnd += 1

    state({"rounds_done": done, "running": False, "stopped": stopped})
    state({"rounds_done": done, "running": False, "stopped": stopped})
    payload = {
        "success": totals["success"],
        "failed": totals["failed"],
        "sessions": totals["sessions"],
        "elapsed": round(time.time() - started, 1),
        "uploaded": totals["uploaded"],
        "upload_failed": totals["upload_failed"],
        "kpsdk_rejects": totals["kpsdk_rejects"],
        "device_limiteds": totals["device_limiteds"],
        "accounts": accounts_out,
        "version": "2.2.0",
        "engine": "ruyi",
        "workers": workers,
        "accounts_per_worker": accounts,
        "rounds_target": rounds,
        "rounds_mode": "unlimited" if rounds == 0 else "fixed",
        "start_round": args.start_round,
        "rounds_done": done,
        "total_target": workers * accounts * rounds if rounds else 0,
        "stopped": stopped,
    }
    (logs_dir / "last_run.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(MARKER + json.dumps(payload, ensure_ascii=False), flush=True)
    logger.info(
        f"合计: 成功={totals['success']} 失败={totals['failed']} "
        f"上传={totals['uploaded']} 上传失败={totals['upload_failed']} "
        f"rounds={done}/{'∞' if rounds == 0 else rounds} 用时={payload['elapsed']}s"
    )
    return 0 if totals["success"] > 0 else 2


if __name__ == "__main__":
    sys.exit(main())
