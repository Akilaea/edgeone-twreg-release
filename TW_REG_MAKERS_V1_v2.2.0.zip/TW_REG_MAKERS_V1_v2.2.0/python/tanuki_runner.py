"""Run Tanuki (CEF) for a built-in worker/round batch.

One Tanuki process registers one account. A worker runs `accounts` sequential
processes per round; `workers` workers run concurrently; `rounds` rounds are
executed without an external per-round request. Upload, progress and state are
written for the EdgeOne /tanuki status route.

Examples:
    python tanuki_runner.py --tanuki-dir tanuki --workers 5 --accounts 9 \
        --rounds 20 --seconds 3400 --upload
    python tanuki_runner.py --tanuki-dir tanuki --start-round 15 \
        --workers 5 --accounts 9 --rounds 14 --seconds 3400
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from loguru import logger

from twreg.config import DEFAULT_API_BASE, DEFAULT_API_TOKEN
from twreg.upload import AccountUploader

ACCOUNT_RE = re.compile(
    r"^ACCOUNT\s+(?P<username>\S+)\s+email=(?P<email>\S+)\s+"
    r"uid=(?P<uid>\S+)\s+token=(?P<token>\S+)\s+cookies=(?P<cookies>\d+)"
)


def detect_country(timeout: int = 10) -> str:
    try:
        import urllib.request

        req = urllib.request.Request(
            "https://cloudflare.com/cdn-cgi/trace",
            headers={"User-Agent": "Mozilla/5.0"},
        )
        text = urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8", "replace")
        for line in text.splitlines():
            if line.startswith("loc="):
                loc = line.split("=", 1)[1].strip().upper()
                if loc:
                    return loc
    except Exception as exc:
        logger.warning(f"出口国家探测失败: {type(exc).__name__}: {exc}")
    return "HK"


def read_last_line(path: Path) -> str:
    if not path.is_file():
        return ""
    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return lines[-1] if lines else ""


def parse_last_account(accounts_file: Path, cookies_file: Path) -> dict:
    line = read_last_line(accounts_file)
    if " " not in line:
        return {}
    left, access_token = line.split(" ", 1)
    if ":" not in left:
        return {}
    username, password = left.split(":", 1)
    return {
        "username": username,
        "password": password,
        "access_token": access_token,
        "cookies": read_last_line(cookies_file),
    }


def write_json(path: Path, payload: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tanuki-dir", required=True)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--accounts", type=int, default=1,
                        help="accounts per worker per round")
    parser.add_argument("--start-round", type=int, default=1)
    parser.add_argument("--seconds", type=int, default=0,
                        help="wall-clock budget; 0 = unlimited")
    parser.add_argument("--accounts-dir", default="accounts")
    parser.add_argument("--logs-dir", default="logs")
    parser.add_argument("--mode", default="multi", choices=["multi", "single", "script"])
    parser.add_argument("--proxy", default="none")
    parser.add_argument("--country", default="auto")
    parser.add_argument("--timezone", default="Asia/Singapore")
    parser.add_argument("--timeout", type=int, default=150)
    parser.add_argument("--code-timeout", type=int, default=60)
    parser.add_argument("--max-fails", type=int, default=12)
    parser.add_argument("--upload", dest="upload", action="store_true", default=True)
    parser.add_argument("--no-upload", dest="upload", action="store_false")
    parser.add_argument("--worker-name", default="reg_tanuki_edgeone")
    parser.add_argument("--mail-api", default="https://mail.minecraft.fashion")
    parser.add_argument("--mail-domain", default="*.jsip.us")
    parser.add_argument("--trace", action="store_true")
    parser.add_argument("--state-file", default="logs/tanuki_state.json")
    parser.add_argument("--progress-file", default="logs/tanuki_progress.jsonl")
    parser.add_argument("--stop-file", default="logs/tanuki.stop")
    args = parser.parse_args()

    tanuki_dir = Path(args.tanuki_dir)
    binary = tanuki_dir / "tanuki-cef"
    run_script = tanuki_dir / "run_cef.sh"
    if args.mode == "script" and not run_script.is_file():
        logger.error(f"Tanuki launcher missing: {run_script}")
        return 3
    if args.mode != "script" and not binary.is_file():
        logger.error(f"Tanuki binary missing: {binary}")
        return 3

    workers = max(1, args.workers)
    rounds = max(1, args.rounds)
    per_round = max(1, args.accounts)
    accounts_dir = Path(args.accounts_dir)
    logs_dir = Path(args.logs_dir)
    accounts_dir.mkdir(parents=True, exist_ok=True)
    logs_dir.mkdir(parents=True, exist_ok=True)
    state_path = Path(args.state_file)
    progress_path = Path(args.progress_file)
    stop_path = Path(args.stop_file)
    stop_path.unlink(missing_ok=True)

    stamp = time.strftime("%Y%m%d_%H%M%S")
    country = detect_country() if args.country.lower() in ("", "auto") else args.country.upper()
    started = time.time()
    deadline = started + args.seconds if args.seconds > 0 else float("inf")
    logger.info(
        f"tanuki 批量开始: workers={workers} rounds={rounds} "
        f"accounts/worker/round={per_round} start_round={args.start_round} "
        f"seconds={args.seconds or '∞'} mode={args.mode} country={country}"
    )

    lock = threading.Lock()
    stop_event = threading.Event()
    totals = {
        "success": 0, "failed": 0, "uploaded": 0, "upload_failed": 0,
        "kpsdk_rejects": 0, "device_limiteds": 0,
    }
    completed: dict[int, set[int]] = {wid: set() for wid in range(workers)}
    accounts_out: list[dict] = []

    def state(extra: dict | None = None) -> dict:
        with lock:
            worker_rounds = {str(w): len(completed[w]) for w in range(workers)}
            payload = {
                "ok": True,
                "engine": "tanuki",
                "version": "2.2.0",
                "started_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(started)),
                "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "elapsed": round(time.time() - started, 1),
                "workers": workers,
                "rounds_target": rounds,
                "start_round": args.start_round,
                "accounts_per_worker_per_round": per_round,
                "rounds_done": min(worker_rounds.values()) if worker_rounds else 0,
                "worker_rounds": worker_rounds,
                "total_target": workers * rounds * per_round,
                **totals,
                "running": not stop_event.is_set() and time.time() < deadline,
                "log": str(logs_dir / "tanuki_batch.log"),
            }
            if extra:
                payload.update(extra)
            write_json(state_path, payload)
            return payload

    def progress(record: dict) -> None:
        with lock:
            with open(progress_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")

    def worker(wid: int) -> None:
        accounts_file = (accounts_dir / f"tanuki_{stamp}_w{wid}.txt").resolve()
        cookies_file = Path(str(accounts_file) + ".cookies.jsonl")
        uploader = None
        if args.upload:
            uploader = AccountUploader(
                DEFAULT_API_BASE, DEFAULT_API_TOKEN, f"{args.worker_name}-w{wid}"
            )
            if not uploader.configured:
                uploader = None
            else:
                uploader.heartbeat()

        env = dict(os.environ)
        env["TANUKI_PROXY"] = args.proxy
        env["TANUKI_TZ"] = args.timezone
        env["TANUKI_CEF_DIR"] = str((tanuki_dir / "cef").resolve())
        env["LD_LIBRARY_PATH"] = (
            str((tanuki_dir / "cef").resolve()) + ":" + env.get("LD_LIBRARY_PATH", "")
        )
        env["TANUKI_CEF_NOGPU"] = "1"
        env["TANUKI_CEF_JS_FLAGS"] = "--lite-mode"
        env["TANUKI_CEF_SWITCHES"] = "disable-software-rasterizer;ozone-platform=headless"
        env.pop("TANUKI_CEF_SINGLE", None)
        if args.mode == "single":
            env["TANUKI_CEF_SINGLE"] = "1"
        if args.trace:
            env["TANUKI_CEF_TRACE"] = "1"

        try:
            for rnd in range(args.start_round, args.start_round + rounds):
                if stop_event.is_set() or time.time() >= deadline:
                    break
                round_ok = True
                for account_idx in range(1, per_round + 1):
                    if stop_event.is_set() or time.time() >= deadline:
                        round_ok = False
                        break
                    if stop_path.exists():
                        stop_event.set()
                        round_ok = False
                        break
                    common = [
                        "--proxy", args.proxy,
                        "--timeout", str(args.timeout),
                        "--accounts-file", str(accounts_file),
                        "--country", country,
                        "--code-timeout", str(args.code_timeout),
                        "--mail-api", args.mail_api,
                        "--mail-domain", args.mail_domain,
                        "--timezone", args.timezone,
                    ]
                    if args.mode == "script":
                        cmd = ["bash", str(run_script), *common]
                    else:
                        cmd = [str(binary), *common]
                    t0 = time.time()
                    try:
                        proc = subprocess.run(
                            cmd, cwd=str(tanuki_dir), env=env, text=True,
                            capture_output=True, timeout=args.timeout * 2 + 30,
                        )
                        output = (proc.stdout or "") + (proc.stderr or "")
                        rc = proc.returncode
                    except subprocess.TimeoutExpired as exc:
                        output = (exc.stdout or "") + (exc.stderr or "")
                        rc = -9
                    elapsed = time.time() - t0

                    match = None
                    for line in reversed(output.splitlines()):
                        match = ACCOUNT_RE.match(line.strip())
                        if match:
                            break
                    parsed = parse_last_account(accounts_file, cookies_file)
                    ok = bool(match and parsed.get("access_token") and rc == 0)
                    uploaded_ok = False
                    if ok and uploader is not None:
                        uploaded_ok = uploader.upload_result(
                            {
                                "username": parsed["username"],
                                "password": parsed["password"],
                                "email": match.group("email"),
                                "access_token": parsed["access_token"],
                                "cookies": parsed.get("cookies") or "[]",
                            },
                            parsed.get("cookies") or "[]",
                        )
                    with lock:
                        if ok:
                            totals["success"] += 1
                            if uploaded_ok:
                                totals["uploaded"] += 1
                            elif uploader is not None:
                                totals["upload_failed"] += 1
                            accounts_out.append({
                                "username": parsed["username"],
                                "password": parsed["password"],
                                "access_token": parsed["access_token"],
                            })
                        else:
                            totals["failed"] += 1
                            if "5025" in output:
                                totals["kpsdk_rejects"] += 1
                            if "2014" in output:
                                totals["device_limiteds"] += 1
                    record = {
                        "t": time.strftime("%H:%M:%S"),
                        "round": rnd,
                        "worker": wid,
                        "account": account_idx,
                        "elapsed": round(elapsed, 1),
                        "rc": rc,
                        "success": ok,
                        "uploaded": uploaded_ok,
                        "username": parsed.get("username", ""),
                        "error": "" if ok else (match.group(0)[:160] if match else output[-300:]),
                    }
                    progress(record)
                    logger.info(
                        f"[R{wid}][{rnd}/{args.start_round + rounds - 1}]"
                        f"[{account_idx}/{per_round}] "
                        f"{'OK' if ok else 'FAIL'} {parsed.get('username', '')} "
                        f"rc={rc} {elapsed:.1f}s"
                    )
                    state()
                    if totals["failed"] >= args.max_fails:
                        logger.error(f"失败达到 {args.max_fails}，停止")
                        stop_event.set()
                        round_ok = False
                        break
                if round_ok and not stop_event.is_set():
                    with lock:
                        completed[wid].add(rnd)
                    state()
                if stop_event.is_set() or time.time() >= deadline:
                    break
        finally:
            if uploader is not None:
                uploader.heartbeat()

    state()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(worker, wid) for wid in range(workers)]
        for future in futures:
            try:
                future.result()
            except Exception as exc:
                logger.error(f"worker 异常: {type(exc).__name__}: {exc}")
                stop_event.set()

    elapsed = time.time() - started
    stopped = "budget" if time.time() >= deadline else (
        "stop" if stop_path.exists() else ("fails" if totals["failed"] >= args.max_fails else "done")
    )
    state({"running": False, "stopped": stopped})
    payload = {
        "success": totals["success"],
        "failed": totals["failed"],
        "sessions": totals["success"] + totals["failed"],
        "elapsed": round(elapsed, 1),
        "file": str(accounts_dir / f"tanuki_{stamp}_w0.txt"),
        "uploaded": totals["uploaded"],
        "upload_failed": totals["upload_failed"],
        "kpsdk_rejects": totals["kpsdk_rejects"],
        "device_limiteds": totals["device_limiteds"],
        "accounts": accounts_out,
        "version": "2.2.0",
        "engine": "tanuki",
        "proxy": args.proxy,
        "workers": workers,
        "rounds_target": rounds,
        "start_round": args.start_round,
        "accounts_per_worker_per_round": per_round,
        "rounds_done": min((len(completed[w]) for w in range(workers)), default=0),
        "worker_rounds": {str(w): len(completed[w]) for w in range(workers)},
        "total_target": workers * rounds * per_round,
        "stopped": stopped,
    }
    (logs_dir / "last_run.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("TWREG_RESULT " + json.dumps(payload, ensure_ascii=False), flush=True)
    logger.info(
        f"合计: 成功={totals['success']} 失败={totals['failed']} "
        f"上传={totals['uploaded']} 上传失败={totals['upload_failed']} "
        f"rounds_done={payload['rounds_done']}/{rounds} 用时={elapsed:.1f}s"
    )
    return 0 if totals["success"] > 0 else 2


if __name__ == "__main__":
    sys.exit(main())
