# Changelog — TW_REG EdgeOne Makers

## v2.2.0 — 2026-11-24

默认改为 **5 线程持续注册 + 自动换核**，直到容器结束。

### 持续批次
- `POST /batch` / `python/auto_batch.py`：`workers=5`、`rounds=0`、`seconds=0`
  默认；一轮接一轮，不限制总轮数/总账号，直到容器被平台关停或 `action=stop`。
- 固定轮数仍可传 `rounds=20/28`；固定预算可传 `seconds=3400`。
- 每轮 5 线程 × 9 账号/线程；轮末退出 5 个 ruyijs Context，不累积会话。

### 自动换核
- `engine=auto` 默认：先 ruyijs；连续 2 轮 `success=0` 且 5025 达到
  `switchAfter` 阈值时自动切 Tanuki；Tanuki 连续失败再切回 ruyijs，循环到结束。
- `/batch` 支持 `engine=auto|ruyi|tanuki`、`switchAfter`、可选 `githubToken`；
  Tanuki 未安装且没有 token 时自动留在 ruyijs。
- 状态/结果新增 `engine`、`engine_mode`、`engine_history`、`switches`。
- `scripts/run_multi.py` 默认 `--containers 2`、`--rounds 0`、`--seconds 0`、
  `--engine auto`；一次流程启动两个项目，各一个无限轮 `/batch`。

### 实测
- 单独 1 线程 1 账号 Tanuki（同 IP `43.163.113.234`）：
  **0/1，1 次 5025，13.1s**；同 IP ruyi 对照 **1/1，13.5s，0 个 5025**。
- auto `/batch` 1×1×1（ruyi 优先）：**1/1，1 上传，0 个 5025，20.6s**。
- 结论：Tanuki 0.2.0 CEF 146 路径自身被 Kasada 拒，不是线程/项目代码问题；
  ruyi TLS159 正常，auto 会在持续 5025 时自动尝试 Tanuki 并切回。

### 发布
- 本版源码包：`TW_REG_MAKERS_V1_v2.2.0.zip`。

## v2.1.2 — 2026-11-24

默认批次改为 **无限轮**：启动后一轮接一轮，直到容器 `seconds` 预算/停止。

### 行为
- `POST /batch` 与 `python/ruyi_batch.py` 的 `rounds` 默认 **0**：
  `0 = 无限轮`，一直跑下一轮，直到 `seconds`（默认 3,400s）或 `action=stop`。
  正数仍是固定轮数（20、28 等可选）。
- `scripts/run_multi.py` 的 `--rounds` 默认 **0**；默认一次启动 2 个独立项目，
  每个项目只调用一次 `/batch`，各自跑到 3,400s 预算结束；客户端只轮询状态。
- 状态/结果新增 `rounds_mode: "unlimited" | "fixed"`；无限模式
  `rounds_target=0`，`total_target=0`，实际 `rounds_done` 按容器寿命累计。
- 20/28 轮固定模式保留，传 `rounds=20` 或 `rounds=28` 即可。

### 发布
- 本版源码包：`TW_REG_MAKERS_V1_v2.1.2.zip`。

## v2.1.1 — 2026-11-24

把默认批次改成 **2 个独立容器 × 20 轮**，一个流程启动，不再默认 28 轮。

### 默认值
- `scripts/run_multi.py`：`--containers 2`、`--rounds 20`、`--workers 5`、
  `--accounts 9`，合计 **2 × 5 × 9 × 20 = 1,800 个/批**。
- 一个 `run_multi.py` 流程同时启动两个独立 Makers 项目；每个项目只调用一次
  `POST /batch` 跑 20 轮，之后只轮询 `/batch?action=status`，不再每轮发请求。
- 两个容器必须用两个项目：新增 `--signed-url-b` / `--token-b`；缺第二个
  项目时直接报错，不再把两个 CID 塞进同一个项目。
- `POST /batch`、`python/ruyi_batch.py` 的 `rounds` 默认 28 → 20。
  `/tanuki` 路由默认也改为 20（Tanuki 仍因 07:40 p.js 更新暂不可用）。
- 版本号 2.1.1；历史 28 轮 1,260/1,260 实测记录保留。

### 发布
- 本版源码包：`TW_REG_MAKERS_V1_v2.1.1.zip`。

## v2.1.0 — 2026-11-24

新增 **Tanuki（内嵌 Chromium 146 / CEF）** 内核，并在 EdgeOne Sandbox 实测通过。

### 新增
- `POST /tanuki`：首次用 GitHub Token 下载私有 Release `v0.2.0`
  （`tanuki-linux-x64.tar.xz`，75MB，SHA256 校验），解压到
  `/home/user/twreg/tanuki`，后续复用。
- `python/tanuki_runner.py`：顺序运行 Tanuki、解析 `ACCOUNT`/Cookie、
  上传账号、写 `logs/last_run.json`；支持 `--accounts`、`--timeout`、
  `--country auto`、`--upload`。
- 默认 **`mode=multi`**：直接运行 `tanuki-cef` 多进程 CEF。
- `/tanuki run` 改为后台批次：内置 `workers × rounds × accounts` 循环，
  默认 **5 × 28 × 9 = 1,260**，不需要每轮手动请求；立即返回 `202`，
  用 `action=status` 轮询、`action=stop` 收尾。
- `startRound`/`seconds` 支持沙箱到期后续跑；进度写
  `logs/tanuki_state.json` 与 `logs/tanuki_progress.jsonl`。
- Tanuki 运行时 256MB；EdgeOne 沙箱无需额外 apt 依赖（实测 `ldd` 无缺失）。
- **Tanuki 状态**：07:40 UTC 前单轮 42/45；07:40 p.js 更新后，Tanuki 0.2.0
  （CEF 146）在 7 个不同 EdgeOne IP 上全部 5025。同一 IP 上 ruyi TLS159
  仍 1/1，说明被 patch 的是 CEF 146 路径，不是 IP。Tanuki 路由保留为实验。
- 新增 `POST /batch`：服务端内置 `workers × rounds × accounts` 轮次循环，
  默认 **5 × 28 × 9 = 1,260**，一次请求启动，`action=status` 轮询、
  `action=stop` 收尾；`startRound` 支持续跑。
- **完整 5×9×28 实测**：分两个沙箱完成（第一个沙箱已有 14 分钟历史，
  1 小时生命周期在第 20 轮到期）：
  - 沙箱 A（`43.134.62.198`）：第 1–20 轮，900/900 成功，900 上传，
    11 次失败尝试，6 次 5025，0 个 2014，2,372.2s。
  - 沙箱 B（`43.128.110.187`）：第 21–28 轮，360/360 成功，360 上传，
    1 次失败尝试，1 次 5025，0 个 2014，782.3s。
  - **合计 28 轮：1,260/1,260 注册、1,260/1,260 上传、0 个 2014；
    12 次失败尝试（重试后仍成功）、7 次会话级 5025；有效运行 3,154.5s。**
- 完整测试使用 ruyi `/batch`；Tanuki 受 07:40 p.js 更新影响暂不可用。

### 实测（EdgeOne SG，直连，单线程）
- 安装：10.5s（75MB 下载 + 解压 + SHA256，无 apt）。
- 1 账号：**1/1，2026 + Step2 200，上传 1/1，18.2s，0 个 5025**。
- 5 账号：**5/5，上传 5/5，0 失败，0 个 5025，0 个 2014，98.0s**
  （约 19.6s/账号）。
- `run_cef.sh` 的 single-process 路径在 EdgeOne 内会卡到超时；改用
  `tanuki-cef` 直接多进程后稳定通过。`mode=single/script` 仅保留诊断。

### 注意
- Tanuki Release 是私有仓库资产，首次安装需要 `githubToken`；
  Token 只写入沙箱临时文件，下载后立即删除，不写入项目环境变量。
- 每个 Tanuki 进程一个账号；当前 runner 顺序执行。2 并发需另测内存/CPU。
- ruyijs 2.0.1 路径保留；Tanuki 通过 `/tanuki` 独立路由使用。

### 发布
- 本版源码包：`TW_REG_MAKERS_V1_v2.1.0.zip`。

## v2.0.1 — 2026-11-22

修复 ruyijs 注册持续 5025（Kasada 拒绝）。

### 根因与修复
- 2026-11-22 07:00 UTC 后 Twitch 更新 p.js；ruyijs 默认的 Firefox 160
  TLS/UA 组合在沙箱内被 Kasada 全部拒绝（step1 5025，20 个会话 0 成功）。
- 强制回到已验证的 **Firefox 159 网络指纹**：`Context(tls="159")`，并同步
  `navigator.userAgent` / `platform` / `oscpu` 为 Windows Firefox 159。
- `requirements.txt` 升级到 `ruyijs==0.4.3`（Firefox 160 引擎，兼容 `tls="159"`）。
- 依赖标记从固定 `.deps_ok` 改为按 bundle 版本命名，部署新 bundle 自动重装，
  不再复用旧版 ruyijs。
- `twitch.lohp.countryCode` 默认 `auto`，通过 Cloudflare trace 取实际出口国家，
  避免 SG 出口配 HK cookie 的跨字段不一致。
- `probe` 增加 UA / firefox / platform / oscpu / KPSDK / 请求网络日志，便于定位 5025。

### 实测（EdgeOne Makers，SG 沙箱，直连，单线程）
- 1/1：成功 1，上传 1，0 个 5025，18.1s。
- **30/30：成功 30，上传 30/30，0 失败，2 次 5025（会话级，自动重建），
  0 个 2014，272.4s**。
- 5025 仍是会话级边界（约 14–15 个/会话），不再是开局全拒。

### 发布
- 推荐参数不变：2 个 worker（两个独立项目）× 5 线程 × 28 轮目标。
- 本版源码包：`TW_REG_MAKERS_V1_v2.0.1.zip`。

## v2.0.0 — 2026-11-21

首个可复现的 EdgeOne Makers 移植版。

### 架构
- 从本机 / GitHub Actions 的 Chromium 注册机迁移到 **EdgeOne Makers Agent + Sandbox**。
- 默认引擎改为 **ruyijs**（Linux 上的真实 Firefox SpiderMonkey + Necko，无窗口）；
  `engine=chromium` 保留为 Windows / 本地 CloakBrowser 可选路径。
- 沙箱内运行 `usque` 4.2.1 WARP（MASQUE over HTTP/2，TCP/443）；
  默认直连沙箱本机 IP，WARP 为可选换出口手段。
- 移除旧代理 / WARP 控制层 / VPNGate / URnetwork 的运行依赖。

### 修复与能力
- ruyijs 字体：运行时生成 `fonts/fontconfig.conf`，指向系统 DejaVu 与
  `~/.local/share/fonts`；解决 `canvas text measurement failed`。
- `/mfc` CORS 预检本地桩，避免 p.js 卡死。
- ruyijs Context 设备 cookie 播种；5025/2014 时关闭 Context 并新建会话。
- CloakBrowser 模式补齐 Linux stealth 参数（`--fingerprint` /
  `--fingerprint-platform=windows`），但 Linux + Windows 伪装仍会被 Kasada 5025。
- 上传默认开启（`upload=true`）；每个成功账号立即上传 TwitchCDK 控制台。
- 效率参数：`workers` 上限 6，`maxConcurrentCtx` 默认等于 workers，`startStagger`
  默认 3s；`syncProject` 用 bundle 版本标记跳过重复写入。
- 新增 `kpsdk_rejects` / `device_limiteds` 计数和 20KB 日志尾部，便于定位 5025。
- 新增 2 容器编排脚本 `scripts/run_multi.py`：每项目一容器、5 线程、5×9、轮次目标。
- 账号上传、账号落盘、`/status`、`/rotate`、`/diag`、`/fonts`、`/warp` 路由齐全。

### 实测
- 3×15：45/45，上传 45/45，203.3s（直连沙箱 IP）。
- 5×9：45/45，0 失败，上传 45/45，runner 111.1s / 总 125.9s。
- 单 worker 累计：1×45 45/45（3 次 5025）；同沙箱累计 60/60（4 次 5025）。
- 新工作区累计 180/180，上传 180/180，0 个 2014。
- 2 容器 × 5 线程 × 1 小时：A/B 各 29 轮、各 1,305，合计 2,610/2,610 上传，
  5 次 5025，0 个 2014，约 54.5 分钟。

### 推荐生产参数
- **2 个 worker（两个独立 Makers 项目 / 两个 `run_multi.py --containers 1` 进程）**
- **每容器 5 线程 × 28 轮目标 × 5×9=45/轮 = 2,520 个/批**
- 上传默认开启；28 轮约 3,080s，给 1 小时沙箱到期留约 500s。
- 18,000 vCPU-s 配额下约 13,600 vCPU-s；容器实测 2 vCPU / 4 GiB。

### 已知边界
- 5025 是**会话级**：每 ruyijs 会话约 14–15 个后出现一次，重建 Context 后继续。
- 单沙箱最长 3,600s；到期前要 `/rotate` 或重建项目。
- Free 版 Sandbox CPU 18,000 vCPU-s / 内存 100,000 GB-s / 最大并发 20；
  按 2 vCPU/4 GiB、1 小时算，约 2.5 个容器小时（2 个满 1 小时 + 0.5 小时余量）。
- 2 容器必须用**两个独立项目**；同一项目并发 warm 会 `RemoteDisconnected`。
- 2014 在 60/180 个内未出现；原“单 IP ≤15”应理解为**单会话 ≤15**。

### 发布方式
- 本文件是发布说明的源；每次更新先改这里，再执行：
  ```bash
  python scripts/build_release.py --version X.Y.Z
  ```
- 产物在 `release/`：`TW_REG_MAKERS_V1_vX.Y.Z.zip`、`CHANGELOG.md`、
  `SHA256SUMS`。
