/**
 * POST /batch — start a built-in ruyijs worker/round batch.
 *
 * One call starts `workers x rounds x accounts` in the sandbox. `rounds=0`
 * (default) means run round after round until the `seconds` budget or stop;
 * `seconds=0` means until the container dies. Engine default is auto: ruyi
 * first, switch to Tanuki after repeated zero-success 5025 rounds, and back.
 * A positive rounds value is a fixed batch. The HTTP call returns 202;
 * poll action=status, action=stop ends before the next round.
 *
 * Body:
 *   { "action": "run" | "status" | "stop",
 *     "workers": 5, "accounts": 9, "rounds": 0, "startRound": 1,
 *     "seconds": 0, "timeout": 300, "maxFails": 12, "upload": true,
 *     "engine": "auto", "switchAfter": 2, "githubToken": "ghp_..." }
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import {
  ROOT,
  ensureDeps,
  resolvePython,
  syncProject,
  tail,
} from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

const STATE = `${ROOT}/logs/ruyi_batch_state.json`;
const PROGRESS = `${ROOT}/logs/ruyi_batch_progress.jsonl`;
const STOP = `${ROOT}/logs/ruyi_batch.stop`;
const PID = `${ROOT}/.ruyi_batch.pid`;
const LOG = `${ROOT}/.ruyi_batch.log`;

function quote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function intIn(value: unknown, min: number, max: number, fallback: number): number {
  const parsed = typeof value === 'number' ? value : Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(parsed)));
}

function boolOf(value: unknown, fallback: boolean): boolean {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['1', 'true', 'yes', 'on'].includes(v)) return true;
    if (['0', 'false', 'no', 'off', ''].includes(v)) return false;
  }
  return fallback;
}

async function readSafe(sandbox: any, path: string, limit = 4000): Promise<string> {
  try {
    const text = String(await sandbox.files.read(path));
    return text.length <= limit ? text : text.slice(-limit);
  } catch {
    return '';
  }
}

function parseJson<T>(text: string): T | null {
  if (!text) return null;
  try {
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

async function pidAlive(sandbox: any, pid: string): Promise<boolean> {
  if (!/^\d+$/.test(pid)) return false;
  try {
    const res = await sandbox.commands.run(
      `kill -0 ${pid} 2>/dev/null && echo alive || echo dead`,
      { cwd: ROOT, timeout: 10 },
    );
    return String(res.stdout ?? '').includes('alive');
  } catch {
    return false;
  }
}

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'POST' && method !== 'GET') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) return json({ ok: false, error: 'sandbox unavailable' }, 503);
  const body = (context.request.body ?? {}) as Record<string, unknown>;
  const action = String(body.action ?? (method === 'GET' ? 'status' : 'run')).toLowerCase();

  try {
    await syncProject(sandbox);
    if (action === 'status') {
      const stateText = await readSafe(sandbox, STATE, 20000);
      const lastText = await readSafe(sandbox, `${ROOT}/logs/last_run.json`, 20000);
      const state = parseJson<Record<string, unknown>>(stateText);
      const last = parseJson<Record<string, unknown>>(lastText);
      const pid = (await readSafe(sandbox, PID, 40)).trim();
      return json({
        ok: true,
        bundle: BUNDLE_VERSION,
        pid,
        running: pid ? await pidAlive(sandbox, pid) : false,
        state,
        last_run: last ? {
          success: last.success,
          failed: last.failed,
          uploaded: last.uploaded,
          upload_failed: last.upload_failed,
          kpsdk_rejects: last.kpsdk_rejects,
          device_limiteds: last.device_limiteds,
          elapsed: last.elapsed,
          engine: last.engine,
          engine_mode: last.engine_mode,
          switches: last.switches,
          rounds_mode: last.rounds_mode,
          rounds_target: last.rounds_target,
          rounds_done: last.rounds_done,
          total_target: last.total_target,
          stopped: last.stopped,
        } : null,
        progress_tail: await readSafe(sandbox, PROGRESS, 5000),
        log_tail: await readSafe(sandbox, LOG, 4000),
      });
    }

    if (action === 'stop') {
      await sandbox.files.write(STOP, new Date().toISOString());
      const pid = (await readSafe(sandbox, PID, 40)).trim();
      return json({ ok: true, action, pid, note: 'runner stops before the next round' });
    }

    if (action !== 'run') {
      return json({ ok: false, error: `unknown action: ${action}` }, 400);
    }

    const workers = intIn(body.workers, 1, 6, 5);
    const accounts = intIn(body.accounts, 1, 20, 9);
    const rounds = intIn(body.rounds, 0, 1000, 0);
    const roundsMode = rounds > 0 ? 'fixed' : 'unlimited';
    const startRound = intIn(body.startRound, 1, 50, 1);
    const seconds = intIn(body.seconds, 0, 3500, 0);
    const timeout = intIn(body.timeout, 60, 600, 300);
    const maxFails = intIn(body.maxFails, 1, 100, 12);
    const switchAfter = intIn(body.switchAfter, 1, 10, 2);
    const engineMode = ['auto', 'ruyi', 'tanuki'].includes(String(body.engine))
      ? String(body.engine)
      : 'auto';
    const githubToken = typeof body.githubToken === 'string'
      ? body.githubToken.trim()
      : '';
    const upload = boolOf(body.upload, true);
    const workerName = typeof body.workerName === 'string'
      ? body.workerName.slice(0, 64)
      : 'reg_auto_batch';

    const oldPid = (await readSafe(sandbox, PID, 40)).trim();
    if (oldPid && await pidAlive(sandbox, oldPid)) {
      return json({ ok: false, error: 'a batch is already running; stop it first' }, 409);
    }

    await ensureDeps(sandbox);
    await sandbox.commands.run(
      `rm -f ${quote(STATE)} ${quote(PROGRESS)} ${quote(STOP)} `
      + `${quote(LOG)} ${quote(PID)} ${quote(`${ROOT}/logs/last_run.json`)}`,
      { cwd: ROOT, timeout: 20 },
    );
    if (githubToken) {
      await sandbox.files.write(`${ROOT}/.tanuki_gh`,
        `Authorization: Bearer ${githubToken}\n`);
    }

    const py = await resolvePython(sandbox);
    const args = [
      py, 'auto_batch.py',
      '--workers', String(workers),
      '--accounts', String(accounts),
      '--rounds', String(rounds),
      '--start-round', String(startRound),
      '--seconds', String(seconds),
      '--timeout', String(timeout),
      '--max-fails', String(maxFails),
      '--engine', engineMode,
      '--switch-after', String(switchAfter),
      '--tanuki-dir', `${ROOT}/tanuki`,
      '--tanuki-token-file', `${ROOT}/.tanuki_gh`,
      '--accounts-dir', `${ROOT}/accounts`,
      '--logs-dir', `${ROOT}/logs`,
      '--state-file', STATE,
      '--progress-file', PROGRESS,
      '--stop-file', STOP,
      '--worker-name', workerName,
    ];
    args.push(upload ? '--upload' : '--no-upload');

    const command = args.map(quote).join(' ');
    const runner = `setsid ${command} > ${quote(LOG)} 2>&1 < /dev/null & `
      + `echo $! > ${quote(PID)}; cat ${quote(PID)}`;
    const launch = await sandbox.commands.run(runner, { cwd: ROOT, timeout: 30 });
    const pid = String(launch.stdout ?? '').trim().split(/\r?\n/)[0] || '';
    await new Promise((resolve) => setTimeout(resolve, 800));
    return json({
      ok: true,
      started: true,
      bundle: BUNDLE_VERSION,
      engine: engineMode,
      action,
      pid,
      workers,
      accounts,
      rounds,
      roundsMode,
      startRound,
      seconds,
      switchAfter,
      total_target: rounds > 0 ? workers * accounts * rounds : 0,
      upload,
      state: parseJson<Record<string, unknown>>(await readSafe(sandbox, STATE, 4000)),
      note: 'poll action=status; action=stop ends before the next round',
      log_tail: await readSafe(sandbox, LOG, 4000),
    }, 202);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message, 2000) }, 500);
  }
}
