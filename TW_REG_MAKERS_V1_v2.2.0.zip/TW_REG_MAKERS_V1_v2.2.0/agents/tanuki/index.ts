/**
 * POST /tanuki — install and run the Tanuki CEF Linux runtime.
 *
 * Tanuki is a private-release Rust/CEF executable. The release asset is
 * downloaded with a short-lived GitHub token supplied in the request body,
 * then deleted from the sandbox. One Tanuki process registers one account.
 *
 * `action=run` starts a detached batch in the sandbox:
 *   workers x accounts x rounds, default 5 x 9 x 28, upload on.
 * The call returns immediately; poll action=status for state/progress.
 * action=stop asks the runner to stop starting new accounts.
 *
 * Body:
 *   { "action": "install" | "run" | "status" | "stop",
 *     "githubToken": "ghp_...",   // required for the first install
 *     "workers": 5, "accounts": 9, "rounds": 28, "startRound": 1,
 *     "seconds": 3400, "timeout": 150, "upload": true,
 *     "proxy": "none", "country": "auto", "trace": false }
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import {
  ROOT,
  resolvePython,
  syncProject,
  tail,
} from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

const TANUKI_ROOT = `${ROOT}/tanuki`;
const TANUKI_MARKER = `${TANUKI_ROOT}/.installed`;
const TANUKI_STATE = `${ROOT}/logs/tanuki_state.json`;
const TANUKI_PROGRESS = `${ROOT}/logs/tanuki_progress.jsonl`;
const TANUKI_STOP = `${ROOT}/logs/tanuki.stop`;
const TANUKI_PID = `${ROOT}/.tanuki_batch.pid`;
const TANUKI_LOG = `${ROOT}/.tanuki_batch.log`;
const TANUKI_ASSET =
  'https://api.github.com/repos/xbox-cn/tanuki/releases/assets/785826846';
const TANUKI_SHA =
  '241b1cf3b5c691efc6276ec701669f92ea2ea72b98181dc470f32e36af2689f2';
const TANUKI_DEPS = [
  'libnss3', 'libnspr4', 'libatk1.0-0', 'libatk-bridge2.0-0',
  'libcups2', 'libdrm2', 'libgbm1', 'libxkbcommon0', 'libxcomposite1',
  'libxdamage1', 'libxrandr2', 'libasound2', 'libpango-1.0-0',
  'libcairo2', 'libatspi2.0-0', 'libudev1', 'libpulse0',
  'libxshmfence1', 'libxfixes3', 'libxi6', 'libxtst6', 'libxss1',
].join(' ');

function quote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function intIn(value: unknown, min: number, max: number, fallback: number): number {
  const parsed = typeof value === 'number' ? value : Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(parsed)));
}

function boolOf(value: unknown, fallback: boolean): boolean {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['1', 'true', 'yes', 'on'].includes(v)) return true;
    if (['0', 'false', 'no', 'off', ''].includes(v)) return false;
  }
  return fallback;
}

async function exists(sandbox: any, path: string): Promise<boolean> {
  try {
    return Boolean(await sandbox.files.exists(path));
  } catch {
    return false;
  }
}

async function readSafe(sandbox: any, path: string, limit = 4000): Promise<string> {
  try {
    const text = String(await sandbox.files.read(path));
    return text.length <= limit ? text : text.slice(-limit);
  } catch {
    return '';
  }
}

function parseJson<T>(text: string): T | null {
  if (!text) return null;
  try {
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

async function pidAlive(sandbox: any, pid: string): Promise<boolean> {
  if (!/^\d+$/.test(pid)) return false;
  try {
    const res = await sandbox.commands.run(
      `kill -0 ${pid} 2>/dev/null && echo alive || echo dead`,
      { cwd: ROOT, timeout: 10 },
    );
    return String(res.stdout ?? '').includes('alive');
  } catch {
    return false;
  }
}

async function ensurePython(sandbox: any): Promise<void> {
  const marker = `${ROOT}/.tanuki_py_ok`;
  if (await exists(sandbox, marker)) return;
  const py = await resolvePython(sandbox);
  const install = await sandbox.commands.run(
    `${quote(py)} -m pip install --no-cache-dir requests==2.34.2 loguru==0.8.0 `
    + '> .tanuki_pip.log 2>&1; echo $? > .tanuki_pip.rc; '
    + 'tail -15 .tanuki_pip.log',
    { cwd: ROOT, timeout: 180 },
  );
  const rc = Number((await readSafe(sandbox, `${ROOT}/.tanuki_pip.rc`, 20)).trim());
  if (Number.isFinite(rc) && rc !== 0) {
    throw new Error(`tanuki python deps failed rc=${rc}: ${tail(String(install.stdout ?? install.stderr ?? ''))}`);
  }
  await sandbox.files.write(marker, BUNDLE_VERSION);
}

async function ensureRuntime(sandbox: any, token: string): Promise<{
  installed: boolean;
  deps: string;
  log: string;
}> {
  if (await exists(sandbox, TANUKI_MARKER)) {
    return { installed: true, deps: '', log: 'cached' };
  }
  if (!token) {
    throw new Error('githubToken is required for the first Tanuki install');
  }

  await sandbox.files.write(`${ROOT}/.gh_auth`,
    `Authorization: Bearer ${token}\n`);
  const download = await sandbox.commands.run(
    `cd ${ROOT} && rm -rf tanuki tanuki-linux tanuki.tar.xz && `
    + `curl -fL --retry 3 -H @${ROOT}/.gh_auth `
    + `-H 'Accept: application/octet-stream' -o tanuki.tar.xz `
    + `${quote(TANUKI_ASSET)} 2>&1; echo $? > .tanuki_dl.rc`,
    { cwd: ROOT, timeout: 360 },
  );
  await sandbox.commands.run(`rm -f ${ROOT}/.gh_auth`, { cwd: ROOT, timeout: 10 });
  const dlRc = Number((await readSafe(sandbox, `${ROOT}/.tanuki_dl.rc`, 20)).trim());
  if (Number.isFinite(dlRc) && dlRc !== 0) {
    throw new Error(`tanuki download failed rc=${dlRc}: ${tail(String(download.stdout ?? ''))}`);
  }

  const verify = await sandbox.commands.run(
    `cd ${ROOT} && echo '${TANUKI_SHA}  tanuki.tar.xz' | sha256sum -c -`,
    { cwd: ROOT, timeout: 30 },
  );
  if (verify.exitCode !== 0) {
    throw new Error(`tanuki sha256 failed: ${tail(String(verify.stdout ?? verify.stderr ?? ''))}`);
  }

  const extract = await sandbox.commands.run(
    `cd ${ROOT} && `
    + `(tar -xJf tanuki.tar.xz 2>/dev/null || `
    + `python3 -c "import tarfile; tarfile.open('tanuki.tar.xz').extractall('.')") && `
    + `mv tanuki-linux tanuki && `
    + `chmod +x tanuki/tanuki-cef tanuki/run_cef.sh && `
    + `rm -f tanuki.tar.xz && echo OK`,
    { cwd: ROOT, timeout: 300 },
  );
  if (extract.exitCode !== 0) {
    throw new Error(`tanuki extract failed: ${tail(String(extract.stdout ?? extract.stderr ?? ''))}`);
  }

  const ldd = await sandbox.commands.run(
    `cd ${ROOT} && ldd tanuki/tanuki-cef tanuki/cef/libcef.so 2>&1 `
    + `| grep 'not found' || true`,
    { cwd: ROOT, timeout: 30 },
  );
  let deps = String(ldd.stdout ?? '').trim();
  if (deps) {
    const install = await sandbox.commands.run(
      'DEBIAN_FRONTEND=noninteractive apt-get update > .tanuki_apt.log 2>&1 && '
      + `DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends ${TANUKI_DEPS} `
      + '>> .tanuki_apt.log 2>&1; echo $? >> .tanuki_apt.log; '
      + 'tail -20 .tanuki_apt.log',
      { cwd: ROOT, timeout: 360 },
    );
    deps += '\n[apt]\n' + tail(String(install.stdout ?? install.stderr ?? ''), 1600);
  }

  await sandbox.files.write(TANUKI_MARKER, `${BUNDLE_VERSION}\n`);
  return { installed: true, deps, log: tail(String(download.stdout ?? ''), 1000) };
}

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'POST' && method !== 'GET') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) return json({ ok: false, error: 'sandbox unavailable' }, 503);
  const body = (context.request.body ?? {}) as Record<string, unknown>;
  const action = String(body.action ?? (method === 'GET' ? 'status' : 'install')).toLowerCase();
  const token = typeof body.githubToken === 'string' ? body.githubToken.trim() : '';

  try {
    await syncProject(sandbox);
    if (action === 'status') {
      const stateText = await readSafe(sandbox, TANUKI_STATE, 20000);
      const lastText = await readSafe(sandbox, `${ROOT}/logs/last_run.json`, 20000);
      const state = parseJson<Record<string, unknown>>(stateText);
      const last = parseJson<Record<string, unknown>>(lastText);
      const pid = (await readSafe(sandbox, TANUKI_PID, 40)).trim();
      const alive = pid ? await pidAlive(sandbox, pid) : false;
      const progress = await readSafe(sandbox, TANUKI_PROGRESS, 5000);
      const log = await readSafe(sandbox, TANUKI_LOG, 4000);
      return json({
        ok: true,
        bundle: BUNDLE_VERSION,
        installed: await exists(sandbox, TANUKI_MARKER),
        marker: await readSafe(sandbox, TANUKI_MARKER, 200),
        pid,
        running: alive,
        state,
        last_run: last ? {
          success: last.success,
          failed: last.failed,
          uploaded: last.uploaded,
          upload_failed: last.upload_failed,
          kpsdk_rejects: last.kpsdk_rejects,
          device_limiteds: last.device_limiteds,
          elapsed: last.elapsed,
          rounds_target: last.rounds_target,
          rounds_done: last.rounds_done,
          worker_rounds: last.worker_rounds,
          total_target: last.total_target,
          stopped: last.stopped,
        } : null,
        progress_tail: progress,
        log_tail: log,
      });
    }

    if (action === 'stop') {
      await sandbox.files.write(TANUKI_STOP, new Date().toISOString());
      const pid = (await readSafe(sandbox, TANUKI_PID, 40)).trim();
      return json({ ok: true, action, pid, note: 'runner will stop before the next account' });
    }

    if (action !== 'install' && action !== 'run') {
      return json({ ok: false, error: `unknown action: ${action}` }, 400);
    }

    const runtime = await ensureRuntime(sandbox, token);
    if (action === 'install') {
      return json({
        ok: true,
        bundle: BUNDLE_VERSION,
        action,
        installed: runtime.installed,
        deps: runtime.deps,
        log: runtime.log,
      });
    }
    await ensurePython(sandbox);

    const workers = intIn(body.workers, 1, 5, 5);
    const accounts = intIn(body.accounts, 1, 20, 9);
    const rounds = intIn(body.rounds, 1, 50, 20);
    const startRound = intIn(body.startRound, 1, 50, 1);
    const seconds = intIn(body.seconds, 0, 3500, 3400);
    const timeout = intIn(body.timeout, 60, 300, 150);
    const codeTimeout = intIn(body.codeTimeout, 30, 180, 60);
    const maxFails = intIn(body.maxFails, 1, 100, 12);
    const upload = boolOf(body.upload, true);
    const trace = boolOf(body.trace, false);
    const mode = ['multi', 'single', 'script'].includes(String(body.mode))
      ? String(body.mode)
      : 'multi';
    const proxy = typeof body.proxy === 'string' && body.proxy.trim()
      ? body.proxy.trim()
      : 'none';
    const country = typeof body.country === 'string' && body.country.trim()
      ? body.country.trim()
      : 'auto';
    const workerName = typeof body.workerName === 'string'
      ? body.workerName.slice(0, 64)
      : 'reg_tanuki_edgeone';

    const oldPid = (await readSafe(sandbox, TANUKI_PID, 40)).trim();
    if (oldPid && await pidAlive(sandbox, oldPid)) {
      return json({ ok: false, error: 'a Tanuki batch is already running; stop it first' }, 409);
    }

    await sandbox.commands.run(
      `rm -f ${quote(TANUKI_STATE)} ${quote(TANUKI_PROGRESS)} `
      + `${quote(TANUKI_STOP)} ${quote(TANUKI_LOG)} ${quote(TANUKI_PID)} `
      + `${quote(`${ROOT}/logs/last_run.json`)}`,
      { cwd: ROOT, timeout: 20 },
    );

    const py = await resolvePython(sandbox);
    const args = [
      py, 'tanuki_runner.py',
      '--tanuki-dir', TANUKI_ROOT,
      '--mode', mode,
      '--workers', String(workers),
      '--rounds', String(rounds),
      '--accounts', String(accounts),
      '--start-round', String(startRound),
      '--seconds', String(seconds),
      '--accounts-dir', `${ROOT}/accounts`,
      '--logs-dir', `${ROOT}/logs`,
      '--state-file', TANUKI_STATE,
      '--progress-file', TANUKI_PROGRESS,
      '--stop-file', TANUKI_STOP,
      '--proxy', proxy,
      '--country', country,
      '--timezone', 'Asia/Singapore',
      '--timeout', String(timeout),
      '--code-timeout', String(codeTimeout),
      '--max-fails', String(maxFails),
      '--worker-name', workerName,
    ];
    args.push(upload ? '--upload' : '--no-upload');
    if (trace) args.push('--trace');

    const command = args.map(quote).join(' ');
    const runner = `setsid ${command} > ${quote(TANUKI_LOG)} 2>&1 < /dev/null & `
      + `echo $! > ${quote(TANUKI_PID)}; cat ${quote(TANUKI_PID)}`;
    const started = Date.now();
    const launch = await sandbox.commands.run(runner, { cwd: ROOT, timeout: 30 });
    const pid = String(launch.stdout ?? '').trim().split(/\r?\n/)[0] || '';
    await new Promise((resolve) => setTimeout(resolve, 800));
    const stateText = await readSafe(sandbox, TANUKI_STATE, 4000);
    return json({
      ok: true,
      started: true,
      bundle: BUNDLE_VERSION,
      engine: 'tanuki',
      action,
      pid,
      workers,
      accounts,
      rounds,
      startRound,
      seconds,
      total_target: workers * rounds * accounts,
      mode,
      upload,
      state: parseJson<Record<string, unknown>>(stateText),
      note: 'poll action=status; action=stop stops before the next account',
      elapsed: ((Date.now() - started) / 1000).toFixed(1),
      log_tail: await readSafe(sandbox, TANUKI_LOG, 4000),
    }, 202);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message, 2000) }, 500);
  }
}
