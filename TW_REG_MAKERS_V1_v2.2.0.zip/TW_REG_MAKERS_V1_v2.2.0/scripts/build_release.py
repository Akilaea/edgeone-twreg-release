#!/usr/bin/env python3
"""Build a clean, versioned release package under release/.

Usage:
    python scripts/build_release.py --version 2.0.0
    python scripts/build_release.py --version 2.0.1 --notes "- fixed ..."

The version must already exist in CHANGELOG.md, or --notes must be supplied
so a new section can be added. package.json and python/twreg/__init__.py must
carry the same version. Runtime state, secrets and build caches are excluded.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RELEASE_DIR = ROOT / "release"
STAGE_ROOT = RELEASE_DIR / ".build"
PROJECT = ROOT.name

EXCLUDE_DIRS = {
    ".git",
    ".idea",
    ".vscode",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".edgeone",
    ".tef_dist",
    ".wrangler",
    ".test",
    ".tanuki",
    "_cdp_profile",
    "_sdk",
    "_sdkq",
    "logs",
    "accounts",
    "cache",
    "release",
    ".build",
}
EXCLUDE_NAMES = {
    ".env",
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    "_dev.log",
}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".bak", ".swp"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_versions() -> tuple[str, str]:
    package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
    package_version = str(package.get("version", "")).strip()
    init_text = (ROOT / "python" / "twreg" / "__init__.py").read_text(encoding="utf-8")
    match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', init_text)
    python_version = match.group(1) if match else ""
    return package_version, python_version


def changelog_section(text: str, version: str) -> str:
    lines = text.splitlines()
    heading = f"## v{version}"
    out: list[str] = []
    active = False
    for line in lines:
        if line.startswith("## v"):
            if active:
                break
            active = line.startswith(heading)
            continue
        if active:
            out.append(line)
    return "\n".join(out).strip()


def ensure_changelog(version: str, date: str, notes: str | None) -> Path:
    path = ROOT / "CHANGELOG.md"
    text = path.read_text(encoding="utf-8") if path.exists() else "# Changelog\n"
    if changelog_section(text, version):
        return path
    if not notes:
        raise SystemExit(
            f"CHANGELOG.md 中没有 v{version}。先补更新说明，或传 --notes \"...\"。"
        )
    section = f"## v{version} — {date}\n\n{notes.strip()}\n\n"
    marker = "\n## v"
    index = text.find(marker)
    if index == -1:
        text = text.rstrip() + "\n\n" + section
    else:
        text = text[: index + 1] + section + text[index + 1 :]
    path.write_text(text, encoding="utf-8")
    return path


def should_skip_file(name: str) -> bool:
    if name in EXCLUDE_NAMES:
        return True
    if name.startswith(".env.") and name != ".env.example":
        return True
    return Path(name).suffix.lower() in EXCLUDE_SUFFIXES


def copy_tree(src: Path, dst: Path) -> int:
    copied = 0
    dst.mkdir(parents=True, exist_ok=True)
    for dirpath, dirnames, filenames in os.walk(src):
        dirnames[:] = sorted(
            name for name in dirnames if name not in EXCLUDE_DIRS
        )
        rel = Path(dirpath).relative_to(src)
        target = dst / rel
        target.mkdir(parents=True, exist_ok=True)
        for name in sorted(filenames):
            if should_skip_file(name):
                continue
            source = Path(dirpath) / name
            if source.is_symlink():
                continue
            shutil.copy2(source, target / name)
            copied += 1
    return copied


def make_zip(stage: Path, zip_path: Path, version: str) -> tuple[int, int]:
    prefix = f"{PROJECT}_v{version}"
    files = 0
    with zipfile.ZipFile(
        zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in sorted(stage.rglob("*")):
            if not path.is_file():
                continue
            arcname = Path(prefix) / path.relative_to(stage)
            archive.write(path, arcname.as_posix())
            files += 1
    return files, zip_path.stat().st_size


def write_sha256sums() -> None:
    lines = []
    for path in sorted(RELEASE_DIR.glob("*.zip")):
        lines.append(f"{sha256(path)}  {path.name}")
    (RELEASE_DIR / "SHA256SUMS").write_text(
        "\n".join(lines) + ("\n" if lines else ""), encoding="utf-8"
    )


def write_index(entry: dict) -> None:
    path = RELEASE_DIR / "releases.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = {}
    else:
        data = {}
    releases = data.get("releases") or []
    releases = [item for item in releases if item.get("version") != entry["version"]]
    releases.append(entry)

    def sort_key(item: dict):
        parts = re.split(r"[.+-]", str(item.get("version", "0")))
        return tuple(int(part) if part.isdigit() else 0 for part in parts)

    releases.sort(key=sort_key, reverse=True)
    payload = {
        "project": PROJECT,
        "updated_at": entry["built_at"],
        "releases": releases,
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a versioned release zip.")
    parser.add_argument("--version", help="Release version, e.g. 2.0.0")
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"))
    parser.add_argument("--notes", help="Changelog notes when the version is new")
    parser.add_argument("--keep-stage", action="store_true")
    parser.add_argument(
        "--no-relay",
        action="store_true",
        help="Do not bundle the sibling TW_RELAY_V1 project",
    )
    args = parser.parse_args()

    package_version, python_version = read_versions()
    version = (args.version or package_version).strip()
    if not version:
        raise SystemExit("版本为空：检查 package.json 的 version。")
    if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", version):
        raise SystemExit(f"版本格式不合法: {version}")
    if package_version != python_version or package_version != version:
        raise SystemExit(
            "版本不一致："
            f"package.json={package_version or '?'} "
            f"python/twreg/__init__.py={python_version or '?'} "
            f"release={version}。先统一版本再打包。"
        )

    changelog = ensure_changelog(version, args.date, args.notes)
    changelog_text = changelog.read_text(encoding="utf-8")
    notes = changelog_section(changelog_text, version)
    if not notes:
        raise SystemExit(f"CHANGELOG.md 中 v{version} 没有内容。")

    RELEASE_DIR.mkdir(parents=True, exist_ok=True)
    stage = STAGE_ROOT / f"{PROJECT}_v{version}"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)

    copied = copy_tree(ROOT, stage)

    relay = ROOT.parent / "TW_RELAY_V1"
    relay_included = False
    if relay.is_dir() and not args.no_relay:
        copied += copy_tree(relay, stage / "extras" / "TW_RELAY_V1")
        relay_included = True

    built_at = datetime.now().astimezone().isoformat(timespec="seconds")
    (stage / "VERSION").write_text(
        f"project={PROJECT}\nversion={version}\nbuilt_at={built_at}\n",
        encoding="utf-8",
    )
    (stage / "BUILD_INFO.json").write_text(
        json.dumps(
            {
                "project": PROJECT,
                "version": version,
                "built_at": built_at,
                "source_files": copied,
                "relay_included": relay_included,
                "excluded": sorted(EXCLUDE_DIRS) + sorted(EXCLUDE_NAMES),
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    zip_path = RELEASE_DIR / f"{PROJECT}_v{version}.zip"
    if zip_path.exists():
        zip_path.unlink()
    file_count, size = make_zip(stage, zip_path, version)
    digest = sha256(zip_path)

    shutil.copy2(changelog, RELEASE_DIR / "CHANGELOG.md")
    write_sha256sums()
    write_index(
        {
            "version": version,
            "date": args.date,
            "file": zip_path.name,
            "sha256": digest,
            "size_bytes": size,
            "files": file_count,
            "built_at": built_at,
            "relay_included": relay_included,
            "notes": notes,
        }
    )

    if not args.keep_stage:
        shutil.rmtree(stage, ignore_errors=True)
        try:
            STAGE_ROOT.rmdir()
        except OSError:
            pass

    print(f"release: {zip_path}")
    print(f"files:   {file_count} (source {copied})")
    print(f"size:    {size / 1024 / 1024:.2f} MiB")
    print(f"sha256:  {digest}")
    print(f"changelog: {RELEASE_DIR / 'CHANGELOG.md'}")
    print(f"index:     {RELEASE_DIR / 'releases.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
