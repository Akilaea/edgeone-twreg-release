"""Run two EdgeOne Makers projects with one built-in batch each.

Default: **2 containers x 5 workers x 9 accounts, unlimited rounds** until
each container's lifetime (no fixed round count).
Each container is one independent Makers project. A single POST /batch starts
the server-side round loop; this script then polls /batch?action=status. It
does not send one request per round.

Two containers on the SAME project are not reliable (EdgeOne closes concurrent
agent requests). Pass a second project's signed URL/token with
``--signed-url-b`` and ``--token-b``.

Example:
    python scripts/run_multi.py \
        --signed-url "$A_SIGNED" --token "$A_TOKEN" \
        --signed-url-b "$B_SIGNED" --token-b "$B_TOKEN" \
        --containers 2 --workers 5 --accounts 9 --rounds 0 \
        --seconds 0 --out .test/two_stats.jsonl
"""

from __future__ import annotations

import argparse
import json
import threading
import time

import requests
from urllib3 import disable_warnings

disable_warnings()

PRINT_LOCK = threading.Lock()
STATS_LOCK = threading.Lock()


def _post_json(session: requests.Session, base: str, path: str, body: dict,
               timeout: float) -> tuple[int, dict]:
    response = session.post(base + path, json=body, timeout=timeout, verify=False)
    try:
        return response.status_code, response.json()
    except Exception:
        return response.status_code, {"error": response.text[:300]}


def _write(out_path: str, record: dict) -> None:
    with STATS_LOCK:
        with open(out_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")


def container_loop(index: int, cid: str, args: argparse.Namespace,
                   signed: str, token: str, out_path: str,
                   totals: dict) -> None:
    session = requests.Session()
    session.trust_env = False
    session.headers.update({
        "Authorization": "Bearer " + token,
        "Makers-Conversation-Id": cid,
    })
    session.get(signed, timeout=30, verify=False, allow_redirects=True)
    base = signed.split("?")[0]

    started = time.time()
    body = {
        "action": "run",
        "workers": args.workers,
        "accounts": args.accounts,
        "rounds": args.rounds,
        "startRound": 1,
        "seconds": args.seconds,
        "timeout": args.round_timeout,
        "maxFails": args.max_fails,
        "upload": True,
        "engine": args.engine,
        "switchAfter": args.switch_after,
        "workerName": f"{args.worker_name}-{index}",
    }
    if args.github_token:
        body["githubToken"] = args.github_token
    try:
        status, payload = _post_json(session, base, "/batch", body,
                                     timeout=args.round_timeout + 120)
    except Exception as exc:  # noqa: BLE001
        error = f"{type(exc).__name__}: {exc}"
        totals[index] = {"cid": cid, "rounds": 0, "success": 0, "failed": 0,
                         "uploaded": 0, "upload_failed": 0,
                         "kpsdk_rejects": 0, "device_limiteds": 0,
                         "error": f"start: {error}"}
        with PRINT_LOCK:
            print(f"[C{index}] start error {error}", flush=True)
        return

    if status not in (200, 202) or not payload.get("started"):
        totals[index] = {"cid": cid, "rounds": 0, "success": 0, "failed": 0,
                         "uploaded": 0, "upload_failed": 0,
                         "kpsdk_rejects": 0, "device_limiteds": 0,
                         "error": str(payload.get("error") or f"http {status}")}
        _write(out_path, {"t": time.strftime("%H:%M:%S"), "container": index,
                          "cid": cid, "started": False, "status": status,
                          "error": payload.get("error")})
        return

    _write(out_path, {"t": time.strftime("%H:%M:%S"), "container": index,
                      "cid": cid, "started": True, "pid": payload.get("pid"),
                      "target": payload.get("total_target")})
    with PRINT_LOCK:
        print(f"[C{index}] started pid={payload.get('pid')} "
              f"target={payload.get('total_target')}", flush=True)

    last_state: dict = {}
    error = ""
    while True:
        time.sleep(args.poll)
        try:
            status, payload = _post_json(session, base, "/batch",
                                         {"action": "status"}, timeout=60)
        except Exception as exc:  # noqa: BLE001
            error = f"status: {type(exc).__name__}: {exc}"
            break
        state = payload.get("state") or {}
        if state:
            last_state = state
        running = payload.get("running")
        record = {
            "t": time.strftime("%H:%M:%S"),
            "container": index,
            "cid": cid,
            "round": last_state.get("rounds_done"),
            "success": last_state.get("success"),
            "failed": last_state.get("failed"),
            "uploaded": last_state.get("uploaded"),
            "upload_failed": last_state.get("upload_failed"),
            "kpsdk_rejects": last_state.get("kpsdk_rejects"),
            "device_limiteds": last_state.get("device_limiteds"),
            "elapsed": last_state.get("elapsed"),
            "running": running,
            "error": payload.get("error"),
        }
        _write(out_path, record)
        with PRINT_LOCK:
            print(json.dumps(record, ensure_ascii=False), flush=True)
        if status != 200:
            error = str(payload.get("error") or f"http {status}")
            break
        if running is False:
            break
        poll_limit = args.seconds + 600 if args.seconds > 0 else 4200
        if time.time() - started > poll_limit:
            error = "client poll timeout"
            break

    totals[index] = {
        "cid": cid,
        "rounds": int(last_state.get("rounds_done") or 0),
        "success": int(last_state.get("success") or 0),
        "failed": int(last_state.get("failed") or 0),
        "uploaded": int(last_state.get("uploaded") or 0),
        "upload_failed": int(last_state.get("upload_failed") or 0),
        "kpsdk_rejects": int(last_state.get("kpsdk_rejects") or 0),
        "device_limiteds": int(last_state.get("device_limiteds") or 0),
        "seconds": round(time.time() - started, 1),
        "error": error or str(last_state.get("stopped") or ""),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--signed-url", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--signed-url-b", default="")
    parser.add_argument("--token-b", default="")
    parser.add_argument("--containers", type=int, default=2)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--accounts", type=int, default=9)
    parser.add_argument("--rounds", type=int, default=0,
                        help="0 = run until seconds/stop; >0 = fixed rounds")
    parser.add_argument("--seconds", type=int, default=0,
                        help="0 = until the container ends")
    parser.add_argument("--round-timeout", type=int, default=300)
    parser.add_argument("--max-fails", type=int, default=12)
    parser.add_argument("--engine", choices=["auto", "ruyi", "tanuki"],
                        default="auto")
    parser.add_argument("--switch-after", type=int, default=2,
                        help="consecutive zero-success 5025 rounds before switching")
    parser.add_argument("--github-token", default="",
                        help="optional Tanuki private release token")
    parser.add_argument("--worker-name", default="reg_edgeone_two")
    parser.add_argument("--cid-prefix", default="twreg-two")
    parser.add_argument("--poll", type=int, default=30)
    parser.add_argument("--out", default=".test/two_stats.jsonl")
    args = parser.parse_args()

    if args.containers < 1 or args.containers > 2:
        parser.error("--containers must be 1 or 2")
    if args.containers == 2 and (not args.signed_url_b or not args.token_b):
        parser.error("two containers need --signed-url-b and --token-b "
                     "(two independent Makers projects)")

    targets = [
        (1, f"{args.cid_prefix}-a", args.signed_url, args.token),
    ]
    if args.containers == 2:
        targets.append((2, f"{args.cid_prefix}-b",
                        args.signed_url_b, args.token_b))

    totals: dict = {}
    threads = []
    for index, cid, signed, token in targets:
        thread = threading.Thread(
            target=container_loop,
            args=(index, cid, args, signed, token, args.out, totals),
            daemon=False,
        )
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join()

    summary = {
        "containers": args.containers,
        "workers": args.workers,
        "accounts_per_worker": args.accounts,
        "engine": args.engine,
        "switch_after": args.switch_after,
        "rounds_target": args.rounds,
        "rounds_mode": "unlimited" if args.rounds == 0 else "fixed",
        "seconds": args.seconds,
        "total_target": (args.containers * args.workers * args.accounts * args.rounds
                         if args.rounds else 0),
        "total_rounds": sum(v.get("rounds", 0) for v in totals.values()),
        "total_success": sum(v.get("success", 0) for v in totals.values()),
        "total_failed": sum(v.get("failed", 0) for v in totals.values()),
        "total_uploaded": sum(v.get("uploaded", 0) for v in totals.values()),
        "total_upload_failed": sum(v.get("upload_failed", 0) for v in totals.values()),
        "total_5025": sum(v.get("kpsdk_rejects", 0) for v in totals.values()),
        "total_2014": sum(v.get("device_limiteds", 0) for v in totals.values()),
        "per_container": totals,
    }
    print("SUMMARY " + json.dumps(summary, ensure_ascii=False), flush=True)
    with open(args.out, "a", encoding="utf-8") as fh:
        fh.write("SUMMARY " + json.dumps(summary, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
