# TW_REG — EdgeOne Makers 移植版

把原来的 `TW_REG_RELEASE_V1`（Twitch 注册机）移植到 **EdgeOne Makers Agent + Sandbox**。
代理/WARP/VPNGate 不再是必需；默认用 **Linux ruyijs** 跑注册，出站直接使用
**沙箱实例自己的公网 IP**。

> **实测结论（2026-11-21）：EdgeOne Sandbox + ruyijs 已跑通，直连沙箱本机 IP 即可，WARP 可选。**
> 默认 `engine=ruyi`（Linux ruyijs / Firefox）：
> **直连（无 WARP）`1/1`（16.9s）、`2/2`（24.4s）**；
> **3×15 直连 `45/45`，上传 `45/45`，`203.3s`**；
> **优化到 5×9：`45/45`，0 失败，上传 `45/45`，runner `111.1s` / 总 `125.9s`**
> （比 3×15 快约 45%）。
> **2 容器 × 5 线程 × 1 小时：58 轮 / 2,610 注册 / 2,610 上传 / 0 个 2014**
> （历史 28 轮实测；v2.2.0 默认 2 容器 × 5 线程，不限轮次直到容器结束）
> （两项目各一容器，约 48 个/分钟）。
> **推荐参数：2 个独立项目 × 每容器 5 线程 × 9 账号，无限轮直到容器寿命结束**；
> 上传默认开；默认 auto 引擎（ruyijs 优先，连续 5025 自动切 Tanuki，再切回）。
> 完整矩阵见 [TEST_RESULTS.md](TEST_RESULTS.md)。
>
> **v2.0.1 5025 修复（2026-11-22）**：Twitch 更新 p.js 后，ruyijs 默认
> Firefox 160 TLS/UA 被 Kasada 全拒。强制 `Context(tls="159")` + Firefox 159 UA
> 后，单线程 **30/30 成功、30/30 上传、0 失败、2 次会话级 5025、0 个 2014**（272.4s）。
>
> **v2.1.0 Tanuki / `/batch`**：Tanuki v0.2.0 在 07:40 UTC p.js 更新后，CEF 146
> 路径在 7 个 EdgeOne IP 上全部 5025；同一 IP 的 ruyi TLS159 仍正常。
> 新增服务端 `/batch` 内置 5×9×28：**1,260/1,260 注册、1,260 上传、0 个 2014、
> 7 次会话级 5025、12 次失败尝试（重试后成功）**，分两个沙箱共 3,154.5s。
> Tanuki 路由保留实验，当前生产用 ruyi `/batch`。
>
> **v2.2.0 自动换核**：`/batch` 默认 `engine=auto`，先跑 ruyijs；连续 2 轮
> 0 成功且 5025 达到阈值时自动切 Tanuki，Tanuki 再连续失败就切回 ruyijs，
> 循环到容器结束。默认 `workers=5`、`rounds=0`、`seconds=0`（跑到容器被杀）。
> 1 线程 1 账号 Tanuki 实测仍 **0/1、1 次 5025**；同 IP ruyi 对照 **1/1**。
>
> 之前的 5025 不是 WARP/EdgeOne IP 的问题，而是 **CloakBrowser 的 Linux +
> Windows 伪装**被 Kasada 拒：同一台 SG 沙箱、同一条 WARP 出口，换成 ruyijs
> 后立即通过。`cloady-direct` 分支的关键修复（DejaVu fontconfig、`/mfc` CORS 桩、
> ruyijs Context、usque HTTP/2）已全部移植。
>
> CloakBrowser 仍保留为 `engine=chromium`（Windows/本地用）；Makers 沙箱默认走
> `ruyi`，不需要下载 206MB 的 Chromium，也不会撞沙箱磁盘。

> 运行时边界：这个 workload 只能落在 Sandbox，不能落在 Edge Functions。
> Edge Functions 是 5 MB 代码包 / 200 ms CPU / 仅 JS；Cloud Functions 有 Node/Python/Go
> 但跑不了 ruyijs 的 manylinux 原生引擎。Makers 的 Sandbox 是 Linux，能装 ruyijs
> 0.4.3、跑真实 Firefox SpiderMonkey + Necko，并允许沙箱内 usque WARP。

---

## 1. 架构

```
POST /reg  (EdgeOne Makers Agent handler, TypeScript)
   │
   ├─ 1. 把内嵌的 Python 项目写进沙箱  /home/user/twreg
   ├─ 2. pip install（ruyijs 0.4.3；engine=chromium 才额外拉 CloakBrowser）
   ├─ 3. POST /warp up → usque 4.2.1 MASQUE HTTP/2 → 127.0.0.1:25345
   ├─ 4. python3 run.py --engine ruyi --proxy http://127.0.0.1:25345
   │       └─ RuyiSession（Firefox SpiderMonkey + Necko，无窗口）
   │           └─ passport.twitch.tv  ← WARP SIN 出口
   └─ 5. 读 logs/last_run.json + accounts/*.txt，返回 JSON
```

- **默认引擎 ruyi**：Linux ruyijs，真实 Firefox JS+网络栈；不会暴露 Linux Chrome
  headless 指纹。`engine=chromium` 保留给 Windows/本地 CloakBrowser。
- **WARP 在沙箱内**：usque HTTP/2（TCP/443，UDP 被沙箱封）；`/warp rotate` 换身份，
  `POST /rotate` 杀沙箱换实例 IP。一个 `Makers-Conversation-Id` 绑定一个沙箱。
- **会话重建**：5025/2014 时关闭当前 ruyijs Context，新建一个设备会话；
  CloakBrowser 模式则是整进程重启。

## 2. 目录

```
TW_REG_MAKERS_V1/
├─ edgeone.json                 # agents.timeout / sandbox.timeout
├─ package.json                 # TS 依赖 + 脚本
├─ tsconfig.json
├─ agents/
│  ├─ reg/index.ts              # POST /reg   跑批次 / warm / probe / install
│  ├─ status/index.ts           # GET  /status 读最近结果与账号
│  ├─ rotate/index.ts           # POST /rotate 杀沙箱换出口 IP
│  ├─ ip/index.ts               # GET  /ip     查沙箱出口 IP / colo
│  ├─ diag/index.ts             # GET  /diag   安装状态/字体/网络连通性
│  ├─ fonts/index.ts            # POST /fonts  上传一个 Windows 字体
│  ├─ warp/index.ts             # POST /warp   up/down/rotate/status/tunnel
│  ├─ tanuki/index.ts           # POST /tanuki 下载/安装/运行 Tanuki CEF
│  ├─ batch/index.ts            # POST /batch  auto 换核无限轮批次
│  ├─ _http.ts                  # JSON 响应 + 可选 Bearer 鉴权
│  ├─ _sandbox.ts               # 沙箱文件/命令/浏览器编排
│  └─ _twreg_bundle.ts          # 自动生成：内嵌的 Python 源码
├─ edge-functions/              # 诊断/relay（Agent 项目内不激活，见 TW_RELAY_V1）
│  ├─ edge-ip/index.js          # 边缘节点出口 IP
│  └─ relay/index.js            # Twitch 请求转发到边缘出口
├─ python/                      # 移植后的注册器（本地可直接跑）
│  ├─ run.py
│  ├─ tanuki_runner.py          # Tanuki CEF 单进程循环 + 上传 + last_run.json
│  ├─ ruyi_batch.py             # 服务端固定 ruyi 批次（兼容）
│  ├─ auto_batch.py             # ruyi ↔ Tanuki 自动换核无限轮
│  ├─ netcheck.py               # /diag 用的连通性检查
│  ├─ requirements.txt
│  ├─ twreg/{config,ruyi,registration_ruyi,chromium,runner,registration_chromium,mail,cookies,profile,upload,logging_setup,warp}.py
│  └─ tests/test_units.py
├─ scripts/
│  ├─ build_bundle.py           # python/ → agents/_twreg_bundle.ts
│  ├─ build_release.py          # 生成 release/ 版本化 zip + SHA256 + releases.json
│  ├─ fake_sandbox_test.ts      # 无凭证的编排测试
│  ├─ upload_fonts.py           # 从本机 Windows 字体目录上传
│  └─ run_multi.py              # 一次启两个项目，无限轮直到容器结束
├─ CHANGELOG.md                 # 版本更新说明（发布说明的源）
├─ TEST_RESULTS.md              # 2026-11-21 真实部署/5025 矩阵
└─ release/                     # 版本化 zip、CHANGELOG 副本、SHA256SUMS、releases.json

../TW_RELAY_V1/                 # 独立 Functions 项目（relay 实际生效的位置）
```

## 3. 与旧版的差异

| 旧版 | 本版 |
|---|---|
| `ruyijs` / Firefox 引擎 | **默认 `engine=ruyi`**；CloakBrowser 作为 `engine=chromium` 可选 |
| `PROXY_SERVER` / `EGRESS_LIST` | 沙箱内 usque WARP；`/warp up|rotate|down` |
| WARP / VPNGate / URnetwork | WARP 保留并内置；VPNGate/URnetwork 移除 |
| `egress.py` / `egress_manager.py` / `vpngate.py` | 移除；`warp.py` 移植进沙箱 |
| 本机多线程批跑 | 沙箱内多线程；Agent 请求负责编排 |
| `--probe` 探 ruyijs | `--probe --engine ruyi` 探 ruyijs + KPSDK |
| 账号落 `accounts/` | 落沙箱 + `/reg` 响应返回 + 可选上传控制台 |

保留：随机资料、临时邮箱、Step1 → 收码 → Step2、8 项 cookie、2014/5025/2002/2008 处理、
会话重建、账号上传、日志。

## 4. 部署

前提：Node.js 20+、一个 EdgeOne Makers 项目、Makers API Token（控制台
`.../edgeone/pages?tab=settings`）。CLI 已内置于 Makers 沙箱；本机用 npm 装。

```bash
cd TW_REG_MAKERS_V1
npm install
npm run bundle                 # 改了 python/ 之后必须重跑
npx tsc --noEmit               # 类型检查

npm install -g edgeone
edgeone login                  # 或 edgeone login -t <API_TOKEN>
edgeone makers link -n tw-reg --mode create_upload
edgeone makers env set REG_API_TOKEN <随机串>
edgeone makers deploy -n tw-reg
```

- `deploy` 默认上传当前目录；本项目没有前端，不需要 `buildCommand` / `outputDirectory`。
- 环境变量（可选）：
  - `REG_API_TOKEN`：设置后 `/reg`、`/status`、`/rotate`、`/ip`、`/diag`、`/fonts` 需要
    `Authorization: Bearer <token>`。**建议设置**。
  - `API_BASE_URL` / `API_TOKEN`：账号上传控制台；代码里已有默认值。
  - `WORKER_NAME`：上传时的 worker 标识，默认 `reg_worker_edgeone`。
- 区域：`edgeone.json` 的 `cloudFunctions.overseasRegions` 只影响 Cloud Functions；
  实测沙箱仍固定在项目 area 对应的 SG。改成 `ap-hongkong` 不会改变沙箱出口。

### 可选：独立 relay 项目

Agent 项目里的 `edge-functions/` 会构建但不激活路由。relay 需要单独建一个
**纯 Functions 项目**（本仓库同级目录 `../TW_RELAY_V1`）：

```bash
cd ../TW_RELAY_V1
npx edgeone makers link -n tw-relay-mk1 --mode create_upload -a overseas
npx edgeone makers deploy -n tw-relay-mk1
```

部署后用 SDK 取 signed URL，把它作为 `relayUrl` 传给 `/reg`。实测该 relay 能把
页面、p.js、gql、注册 POST 全部转发到 HKG 边缘节点（`43.152.24.203`）；
`engine=chromium` 下仍 5025，`engine=ruyi` + 沙箱 WARP 不需要 relay。
详见 [TEST_RESULTS.md](TEST_RESULTS.md)。

## 5. 调用

所有请求都带同一个会话头，保证命中同一个沙箱：

```bash
BASE=https://<你的项目域名>
AUTH='Authorization: Bearer <REG_API_TOKEN>'
CID='Makers-Conversation-Id: twreg-001'
```

**验证出口 IP（不注册）**

```bash
curl -s -H "$AUTH" -H "$CID" "$BASE/ip"
# {"ok":true,"egress":{"ip":"...","loc":"SG","colo":"SIN","warp":"off"}}
```

**预热依赖 + 浏览器（每个新沙箱一次，约 1–3 分钟）**

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/reg" \
  -H 'Content-Type: application/json' -d '{"accounts":0}'
```

**探活：打开 /signup，等 KPSDK 就绪（不注册）**

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/reg" \
  -H 'Content-Type: application/json' -d '{"probe":true}'
# {"ok":true,"probe":true,"mode":"cloak","probe_stdout":"{...\"ready\": true...}"}
```

**注册 1 个账号（只落盘，不上传）**

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/reg" \
  -H 'Content-Type: application/json' \
  -d '{"workers":1,"accounts":1,"upload":false}' | jq
```

返回：

```json
{
  "ok": true,
  "bundle": "059f71881b10",
  "mode": "cloak",
  "result": {"success":1,"failed":0,"sessions":2,"elapsed":36.2,
             "file":"accounts/accounts_...txt"},
  "accounts_list": [{"username":"...","password":"...","access_token":"..."}],
  "exitCode": 0
}
```

**上传到控制台**

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/reg" \
  -H 'Content-Type: application/json' \
  -d '{"workers":1,"accounts":3,"upload":true}'
```

**读最近结果 / 账号**

```bash
curl -s -H "$AUTH" -H "$CID" "$BASE/status"
```

**换出口 IP**

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/rotate"
# 下一次 /reg 会惰性创建新沙箱，新 IP
```

### 参数

| 字段 | 默认 | 范围 | 说明 |
|---|---|---|---|
| `workers` | 1 | 1–6 | 沙箱内并行线程 |
| `accounts` | 1 | 0–60 | 每线程账号数；`0` = 只预热 |
| `maxConcurrentCtx` | `workers` | 1–8 | 同时存活的 ruyijs Context 上限 |
| `startStagger` | 3 | 0–30 | 线程启动错峰秒数（R0 立即，R1 等 N 秒…） |
| `engine` | `ruyi` | `ruyi` / `chromium` | ruyi=Linux ruyijs Firefox（默认）；chromium=CloakBrowser |
| `ruyiFirefox` | `159` | `159` / `160` / `auto` | ruyijs TLS/UA 版本；159 是当前 Kasada 通过组合 |
| `mode` | `cloak` | `cloak` / `cdp` | 仅 `engine=chromium` 时生效 |
| `upload` | true | bool | 上传到 TwitchCDK 控制台（默认开启） |
| `reset` | false | bool | 先杀沙箱；下一次请求新 IP |
| `probe` | false | bool | 只做 KPSDK 探活 |
| `timeout` | 900 | 60–1650 | `run.py` 命令超时（秒） |
| `cooldown` | 30 | 0–300 | 连续 2 个 0 账号会话后的冷却 |
| `maxFails` | 30 | 1–50 | 单线程失败上限；测试用 1 |
| `fallback` | true | bool | cloak 安装失败时退回 cdp |
| `install` | false | bool | 仅 `engine=chromium`：后台拉 CloakBrowser；`ruyi` 只做 pip |
| `mailApiUrl` | – | string | 覆盖邮箱 API 地址 |
| `relayUrl` | – | string | Edge relay 的 signed URL；页面 + POST 走边缘出口 |
| `warp` | false | bool | 浏览器走沙箱内 WARP 代理 `127.0.0.1:25345` |
| `workerName` | – | string | 上传 worker 标识 |

### Tanuki（CEF，v2.1.0）

Tanuki 是内嵌 **Chromium 146（CEF）** 的 Rust 框架，不是外部浏览器、不是 CDP；
`/signup` 只返回最小壳，`/fp`、`ips.js`、`/tl`、`protected_register` 全走真实
Chromium 网络栈。EdgeOne 实测通过：

```bash
# 首次安装：私有 Release v0.2.0，需一个能读 xbox-cn/tanuki 的 GitHub Token
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/tanuki" \
  -H 'Content-Type: application/json' \
  -d '{"action":"install","githubToken":"ghp_xxx"}'

# 内置 5×9×20：5 workers × 每 worker 每轮 9 个 × 20 轮 = 900/容器
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/tanuki" \
  -H 'Content-Type: application/json' \
  -d '{"action":"run","workers":5,"accounts":9,"rounds":20,
       "startRound":1,"seconds":3400,"timeout":120,"upload":true}'

# 轮询进度（不会每轮发请求）
curl -s -H "$AUTH" -H "$CID" "$BASE/tanuki?action=status" | jq

# 需要提前收尾时
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/tanuki" \
  -H 'Content-Type: application/json' -d '{"action":"stop"}'
```

- `action=run` 立即返回 `202`，后台在沙箱内跑完整的 `workers × rounds × accounts`；
  轮次、worker、账号全部由 `tanuki_runner.py` 内置循环，不需要每轮手动调用。
- 安装：75MB tar.xz，SHA256 校验，解压 256MB；实测 10.5s，沙箱无需额外 apt。
- 默认 **`mode=multi`**：直接运行 `tanuki-cef` 多进程。`run_cef.sh` 的
  single-process 在 EdgeOne 内会卡到超时，`mode=single/script` 只保留诊断。
- 单线程实测：1/1（18.2s）、**5/5（98.0s，5/5 上传，0 个 5025，0 个 2014）**。
- `seconds` 默认 3,400s，给 1 小时沙箱留 200s；Sandbox 到期前会写
  `logs/tanuki_state.json` 和 `logs/tanuki_progress.jsonl`。如果 20 轮未跑完，
  用 `startRound` 从下一轮续跑，例如 `startRound=20`。
- Cookie 里的 `twitch.lohp.countryCode` 由 `country=auto` 按出口探测；账号
  通过现有 TwitchCDK 上传器上传，`logs/last_run.json` 与 `/status` 兼容。
- `githubToken` 只写入沙箱临时文件，下载后立即删除；不写入项目环境变量。
  沙箱重建后需要重新 install。

| 字段 | 默认 | 范围 | 说明 |
|---|---|---|---|
| `action` | `install` | `install` / `run` / `status` / `stop` | `run` 启动后台批次 |
| `githubToken` | – | string | 首次安装私有 Release 必需 |
| `workers` | 5 | 1–5 | 并发 Tanuki 进程 |
| `accounts` | 9 | 1–20 | 每 worker 每轮账号数 |
| `rounds` | 20 | 1–50 | 内置轮数 |
| `startRound` | 1 | 1–50 | 续跑起始轮号 |
| `seconds` | 3400 | 0–3500 | 批次墙钟预算；0=不限 |
| `maxFails` | 12 | 1–100 | 全局失败上限 |
| `mode` | `multi` | `multi` / `single` / `script` | EdgeOne 用 `multi` |
| `timeout` | 150 | 60–300 | 单账号 CEF 超时 |
| `codeTimeout` | 60 | 30–180 | 等验证码秒数 |
| `upload` | true | bool | 上传到 TwitchCDK |
| `proxy` | `none` | URL / `none` | 传给 Tanuki；`none` 直连 |
| `country` | `auto` | `auto` / `SG` / `HK` | Cookie countryCode |
| `trace` | false | bool | 打印 CEF/控制台细节 |

- **2026-11-24 07:40 UTC p.js 更新后，Tanuki 0.2.0（CEF 146）全部 5025；
  同一 IP 上 ruyi TLS159 仍 1/1 成功。** Tanuki 路由保留为实验路径，当前
  生产注册走下面的 ruyi `/batch`。

### 内置批次（auto 换核，默认无限轮）

`POST /batch` 在沙箱内启动后台批次，**一次请求后一轮接一轮**，默认
`seconds=0` 一直跑到容器被平台关停。`engine=auto`（默认）先跑 ruyijs；
连续 2 轮 0 成功且 5025 达到 `switchAfter` 阈值时自动切 Tanuki，Tanuki 再连续
失败就切回 ruyijs，循环到容器结束。固定轮数/单引擎仍可传参。

```bash
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/batch" \
  -H 'Content-Type: application/json' \
  -d '{"action":"run","workers":5,"accounts":9,"rounds":0,
       "startRound":1,"seconds":0,"timeout":300,"maxFails":12,
       "engine":"auto","switchAfter":2,"upload":true}'

curl -s -H "$AUTH" -H "$CID" "$BASE/batch?action=status" | jq
curl -s -H "$AUTH" -H "$CID" -X POST "$BASE/batch" \
  -H 'Content-Type: application/json' -d '{"action":"stop"}'
```

- 默认 `workers=5`、`rounds=0`、`seconds=0`：5 线程不断注册，直到容器结束。
- `engine=auto`：ruyijs 优先；连续 2 轮 `success=0` 且 5025 ≥ 2 切 Tanuki；
  Tanuki 连续失败再切回；状态里 `engine_history` / `switches` 可查。
- Tanuki 首次自动安装需要 `/batch` body 里带 `githubToken`（私有 Release）；
  没装且没 token 时自动留在 ruyijs。
- 单轮实测：**45/45，上传 45/45，0 个 2014，103.9s**。
- 历史 5×9×28（v2.1.0）：1,260/1,260、0 个 2014；固定 20/28 轮仍可传 `rounds`。
- 1 线程 1 账号 Tanuki 实测仍 **0/1、1 次 5025**；同 IP ruyi 对照 **1/1**。
- ruyi 仍必须使用 **Firefox 159 TLS/UA**（v2.0.1 修复）；默认 TLS160 会被 5025。

### 效率优化（实测）

| 配置 | 成功 | 失败尝试 | 会话 | runner 耗时 | 总耗时 | 上传 |
|---|---|---|---|---|---|---|
| 3×15 | 45/45 | 2 | 6 | 203.3s | 206.4s | 45/45 |
| **5×9** | **45/45** | **0** | 6 | **111.1s** | **125.9s** | **45/45** |

- `workers` 上限 3 → 6，`maxConcurrentCtx` 默认等于 `workers`（5），同时跑 5 个 Context。
- 保留 `startStagger=3`，避免开局集中 5025；5×9 失败尝试 0。
- `syncProject` 用 bundle 版本标记，未变更时跳过 16 个文件写入（`files=0`）。
- 默认 ruyi 不下载 206MB CloakBrowser；上传随 worker 并发。
- 5×9 总耗时 125.9s，与 GA Windows XEHN 3×15 的 125.9s 持平。

### 单 worker 上限（实测）

| 轮次 | 成功 | 5025 | 2014 | 会话 | 耗时 |
|---|---|---|---|---|---|
| 1×30 | 30/30 | 2 | 0 | 3 | 287.7s |
| 1×45 | 45/45 | 3 | 0 | 4 | 407.9s |
| 同沙箱 +15（累计 60） | 60/60 | 4 | 0 | 6 | 559.3s |

> 这张表和新工作区的 150/180 都是 `workers=1, maxConcurrentCtx=1` **单线程串行**；
> `3×15`（3 线程）和 `5×9`（5 线程）是另外的多线程基准，不是这里的 150/容器数据。

- **5025 是会话级边界**：每个 ruyijs 会话约 14–15 个后，下一次 step1/step2 5025；
  重建 Context 后继续，不是累计 IP 耗尽。
- **零 5025 目标**：`14` 个/worker；留余量用 `9`（5×9 即 0 失败）。
- **允许自动重建**：`45` 个/worker（45/45，3 次 5025，407.9s）；
  `60` 累计也可（60/60，4 次 5025，559.3s），单请求会超 540s，建议拆 45 + 15。
- **批量效率**：5×9（45）111.1s，优于 1×45 的 407.9s 和 3×15 的 203.3s。
- 60 个内没有出现 2014；原 README 的“单 IP ≤15”应理解为**单会话 ≤15**。
- **旧工作区的硬上限是 EdgeOne Sandbox CPU 时长配额**：继续加轮时命中
  `SANDBOX_LIMIT_EXCEEDED: pages-sandbox-cpu-duration`，不是 Twitch 5025/2014。
- **新工作区复测（上传默认开启）**：累计 **180/180，上传 180/180，0 个 2014**；
  5025 仍是每会话约 14–15 个一次。
- **单沙箱生命周期 1 小时**：第 7 轮命中 `expiresAt` 被 `terminated`；
  `/rotate` 新沙箱后第 8 轮继续成功。长跑要按 1 小时主动换沙箱。
- **容器规格实测：2 vCPU / 4 GiB**（cgroup v1 `200000/100000`；
  `nproc=3` 是 cpuset 可见 3 核，计费按 2 vCPU）。
  Free 18,000 vCPU-s → `18,000 ÷ (2×3,600) = 2.5`：
  **2 个跑满 1 小时 + 0.5 小时余量**；内存 `100,000 ÷ (4×3,600)=6.9` 不是瓶颈；
  20 并发也不是瓶颈，CPU 配额才是。

### 2 容器 × 5 线程（v2.2.0 默认无限轮）

**默认生产参数：2 个独立项目 × 每容器 5 线程 × 9 账号，无限轮直到容器结束**；
上传默认开。`scripts/run_multi.py` 一次启动两个项目，每个项目只调用一次
`POST /batch`，自动换核、一轮接一轮直到容器被平台关停；客户端只轮询状态。

- 架构：**两个独立 Makers 项目**，每个项目一个容器、5 线程；同一项目并发
  `RemoteDisconnected`，所以必须两个项目、两个 signed URL/token。
- 每轮 `workers=5, accounts=9`（5×9=45），`upload=true`；一轮约 100s。
- 历史 28 轮实测（v2.0.1，旧固定默认）：

| 容器 | 轮次 | 注册 | 上传 | 失败尝试 | 5025 | 2014 | 用时 |
|---|---|---|---|---|---|---|---|
| A | 29 | 1,305 | 1,305 | 6 | 2 | 0 | 3,268s |
| B | 29 | 1,305 | 1,305 | 5 | 3 | 0 | 3,255s |
| **合计** | **58** | **2,610** | **2,610** | **11** | **5** | **0** | **~54.5 分钟** |

- 0 上传失败，0 个 2014；约 **48 个/分钟**（2 容器合计）。
- 18,000 vCPU-s：容器 3,600s 时 `2 × 2 × 3,600 = 14,400`，在配额内，
  约剩 0.5 小时。
- 单流程启动两个项目、无限轮：

```bash
python scripts/run_multi.py \
  --signed-url "$A_SIGNED" --token "$A_TOKEN" \
  --signed-url-b "$B_SIGNED" --token-b "$B_TOKEN" \
  --github-token "$GITHUB_TOKEN" \
  --containers 2 --workers 5 --accounts 9 --rounds 0 \
  --seconds 0 --out two_stats.jsonl
```

- `--engine auto` 是默认；`--switch-after 2` 控制连续几轮 5025 后换核。
- 需要固定轮数时把 `--rounds` 改成 `20` 或 `28` 即可。

### 安装与诊断

- `POST /reg {"accounts":0}`：同步代码 + pip install + 检查市场；CloakBrowser 已装则直接返回。
- `POST /reg {"install":true}`：`engine=ruyi`（默认）只做 pip install，返回
  `202 + install:"deps"`；`engine=chromium` 才后台下载 CloakBrowser，返回 `202 + pid`，
  轮询 `/diag` 直到 `state.cloakOk=true`。避免 600s 网关超时。
- `GET /diag`：`depsOk` / `cloakOk` / `pipLog` / `cloakLog` / `Win fonts` / 网络连通性。
- `POST /fonts`：`{"name":"calibri.ttf","b64":"..."}`，一次一个字体；
  `scripts/upload_fonts.py` 负责从本机 `C:/Windows/Fonts` 批量上传。
- `POST /rotate`：kill 沙箱；测试结束务必调用，避免沙箱继续计时。

### WARP 出口（可选，沙箱内 usque）

> 默认不启用 WARP：`/reg` 不传 `warp` 就是直连沙箱本机 IP，已实测 `1/1`、`2/2`。
> 需要换出口/分散 IP 时再起 WARP。

```bash
POST /warp {"action":"up","http2":true}      # 下载 usque + 注册 + 起隧道
POST /reg  {"workers":1,"accounts":1,"warp":true}
POST /warp {"action":"rotate","http2":true}  # 换身份/出口 IP
POST /warp {"action":"down"}                 # 停隧道
```

- usque 4.2.1，用户态，无 TUN/root；本地 HTTP CONNECT 代理 `127.0.0.1:25345`。
- QUIC 在沙箱里 UDP 被封；用 HTTP/2（`--http2`）。
- 实测（engine 默认 ruyi）：`104.28.222.46 / SIN / warp=on`，Twitch 200；
  `1/1`（12.1s）、`2/2`（22.2s）、默认引擎 `1/1`（27.5s）。
- 同一条 WARP 出口下，`engine=chromium`（CloakBrowser）仍 5025；
  换成 ruyijs 才通过。出口没问题，引擎才是变量。
- `tunnel` 动作（`bore` 公网 TCP）只用于隔离测试，测完记得 `/rotate` 杀沙箱。
- 单 WARP IP 建议 ≤15 个/窗口；用 `/warp rotate` 换身份/出口 IP。

## 6. 本地开发与验证

```bash
# Python 单测（不联网、不开浏览器）
python -m unittest discover -s python/tests -v

# TS 类型检查 + 编排测试（假沙箱，无 EdgeOne 凭证）
npx tsc --noEmit
npx tsx scripts/fake_sandbox_test.ts

# 本地真实注册：Windows 参考路径用 CloakBrowser
cd python
python -m pip install -r requirements.txt
python -m cloakbrowser install
python run.py --workers 1 --accounts 1 --no-upload \
  --engine chromium --browser-mode cloak --proxy http://127.0.0.1:7897

# Linux 沙箱路径（EdgeOne 默认）：ruyijs + 沙箱 WARP
python run.py --workers 1 --accounts 1 --no-upload \
  --engine ruyi --warp --warp-http2
```

`--proxy` 只用于本机 Windows 调试；Makers 沙箱默认 `engine=ruyi` +
`--proxy http://127.0.0.1:25345`（沙箱内 WARP）。

### 本机 + 真实 EdgeOne 实测（2026-11-21）

- Python 单测：24/24 通过
- `npx tsc --noEmit`：通过
- `npx tsx scripts/fake_sandbox_test.ts`：16 个文件内嵌、命令拼装、结果解析、handler
  warm/probe/auth/reset 全部通过
- 本机 `--proxy 127.0.0.1:7897`（HK 住宅）+ cloak：`1/1`，36.2s
- **真实 EdgeOne 部署**：`tw-reg-mk2.edgeone.dev`（overseas/SG），Agent + Sandbox
  - `/ip`：`43.163.122.167 / SG`
  - **`engine=ruyi` + 直连（无 WARP）**：probe `ready: true`；注册
    **`1/1`（16.9s）**、**`2/2`（24.4s）**；
    **3×15 `45/45`，上传 `45/45`，`203.3s`**（2 failed 重试，6 sessions）
  - **优化 5×9**：`workers=5, maxConcurrentCtx=5, startStagger=3`；
    **`45/45`，0 失败，6 sessions，runner `111.1s` / 总 `125.9s`，
    上传 `45/45`**（与 GA 3×15 的 125.9s 持平）
  - **`engine=ruyi` + WARP**：probe `ready: true`；注册 **`1/1`（12.1s）**、
    **`2/2`（22.2s）**、默认引擎 **`1/1`（27.5s）**
  - 同一 WARP 出口下 `engine=chromium`（CloakBrowser）：`5025`
  - CloakBrowser 直连/Edge relay（HKG）/WARP：全部 `5025`，确认是 Linux/Windows
    伪装引擎的问题
- 结论：**EdgeOne Sandbox + ruyijs 已跑通，直连沙箱本机 IP 即可，WARP 可选**；
  5×9 优化版 `45/45`、总 `125.9s`，与 GA 3×15 持平；默认引擎 ruyi，
  不需要下载 CloakBrowser。完整矩阵见 [TEST_RESULTS.md](TEST_RESULTS.md)。

## 7. 发布 / Release

源码和说明按版本打包到 `release/`，以后每次更新都走同一入口：

```bash
python scripts/build_release.py --version 2.2.0
```

- `release/TW_REG_MAKERS_V1_vX.Y.Z.zip`：完整源码包（不含 `.env`、`node_modules`、
  `.edgeone`、日志、账号、缓存、测试用 signed URL）。
- `release/CHANGELOG.md`：根 `CHANGELOG.md` 的副本。
- `release/SHA256SUMS` + `release/releases.json`：校验值和版本索引。
- 包内附带 `extras/TW_RELAY_V1/`，需要 relay 时单独部署。
- `release/README.md`：包内使用方式与更新流程。

每次更新顺序：

1. 改代码并验证（`npm run bundle`、`npx tsc --noEmit`、Python 单测）。
2. 在 `CHANGELOG.md` 写 `## vX.Y.Z — YYYY-MM-DD` 更新内容。
3. 同步 `package.json` 与 `python/twreg/__init__.py` 的版本。
4. 执行构建脚本；版本章节不存在时可加 `--notes "- ..."` 让脚本写入。

包内完整说明见 [release/README.md](release/README.md)，版本记录见
[CHANGELOG.md](CHANGELOG.md)。

## 8. 风险与边界

- **已实测：CloakBrowser 的 Linux/Windows 伪装被 Kasada 拒，ruyijs 通过。**
  SG 沙箱（`43.163.122.167`）、HKG Edge Function（`43.152.24.203`）、WARP SIN
  上 `engine=chromium` 都 5025；同一条 WARP SIN 出口换 `engine=ruyi` 连续成功
  （`1/1`、`2/2`、`1/1`）。默认引擎已是 ruyi，不需要住宅代理。
- **CloakBrowser 只在 Windows/本地用**：`engine=chromium` 会下载 206MB Chromium，
  sandbox 磁盘可能被占满（实测出现过 `No space left on device` 和 ruyijs
  `AbortError`）；默认 ruyi 跳过这一步。同一沙箱不要混跑两种引擎，换引擎前先
  `/rotate` 开新实例。
- **沙箱 QUIC 被封**：usque 的 QUIC/WireGuard 端点全部超时，必须用
  `--http2`（MASQUE over TCP/443）。
- **Edge Functions 不能和 Agent 路由混用**：Agent 项目里 `edge-functions/` 会构建但
  不激活路由；relay 实际生效的位置是独立的 `../TW_RELAY_V1` 项目（纯 Functions）。
- **CloakBrowser 安装可能失败**：沙箱缺 Chromium 运行库或下载域名不可达时，
  `fallback` 会退回 `cdp`；cdp 若仍 5025，说明沙箱自带浏览器不是隐身内核。
- **免费版沙箱最长 1 小时**，Agent 最长 30 分钟。默认 `workers=1, accounts=1`；
  大批量先 `accounts:0` 预热，再分批跑。Pro 可把 `agents.timeout` / `sandbox.timeout` 调高。
- **沙箱是临时的**：账号结果通过 `/reg` 响应和 `/status` 取；要长期保留请开
  `upload=true` 或自行落 EdgeOne KV/Blob。`persist()` 只归档项目目录，不适合存账号。
- **不要泄露** `REG_API_TOKEN`；`/reg` 能创建账单资源。

## 9. 参考

- EdgeOne Makers 产品与文档：<https://pages.edgeone.ai/document/product-introduction>
- Cloud Functions / Node.js：<https://pages.edgeone.ai/document/node-functions>
- Sandbox 原子 API：<https://pages.edgeone.ai/document/sandbox-atomic-api>
- Sandbox + Agent 框架：<https://pages.edgeone.ai/document/sandbox-using-the-agent-framework>
- edgeone.json：<https://pages.edgeone.ai/document/edgeone-json>
- EdgeOne CLI：<https://pages.edgeone.ai/document/edgeone-cli>
