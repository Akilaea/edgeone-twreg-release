# Changelog — TW_REG EdgeOne Makers

## v2.0.2 — 2026-11-24

新增沙箱内部持续执行模式。

- `POST /reg` 新增 `continuous: true` 与 `duration`（60–3600 秒，默认 3400）。
- 连续模式在沙箱内写入 `.continuous.sh`，用 `setsid`/`nohup` 后台循环执行
  `run.py`，HTTP 请求立即返回 PID，不再需要管理器重复请求。
- 每个批次顺序执行，批次间休息 3 秒；沙箱寿命上限仍由 EdgeOne 控制。
- 后台日志写入 `.continuous.log`，PID 写入 `.continuous.pid`。
- 原有单批 `/reg` 行为保持不变；只有显式传 `continuous:true` 才进入持续模式。

## v2.0.1 — 2026-11-22

修复 ruyijs 注册持续 5025（Kasada 拒绝）。

### 根因与修复
- 2026-11-22 07:00 UTC 后 Twitch 更新 p.js；ruyijs 默认的 Firefox 160
  TLS/UA 组合在沙箱内被 Kasada 全部拒绝（step1 5025，20 个会话 0 成功）。
- 强制回到已验证的 **Firefox 159 网络指纹**：`Context(tls="159")`，并同步
  `navigator.userAgent` / `platform` / `oscpu` 为 Windows Firefox 159。
- `requirements.txt` 升级到 `ruyijs==0.4.3`（Firefox 160 引擎，兼容 `tls="159"`）。
- 依赖标记从固定 `.deps_ok` 改为按 bundle 版本命名，部署新 bundle 自动重装，
  不再复用旧版 ruyijs。
- `twitch.lohp.countryCode` 默认 `auto`，通过 Cloudflare trace 取实际出口国家，
  避免 SG 出口配 HK cookie 的跨字段不一致。
- `probe` 增加 UA / firefox / platform / oscpu / KPSDK / 请求网络日志，便于定位 5025。

### 实测（EdgeOne Makers，SG 沙箱，直连，单线程）
- 1/1：成功 1，上传 1，0 个 5025，18.1s。
- **30/30：成功 30，上传 30/30，0 失败，2 次 5025（会话级，自动重建），
  0 个 2014，272.4s**。
- 5025 仍是会话级边界（约 14–15 个/会话），不再是开局全拒。

### 发布
- 推荐参数不变：2 个 worker（两个独立项目）× 5 线程 × 28 轮目标。
- 本版源码包：`TW_REG_MAKERS_V1_v2.0.1.zip`。

## v2.0.0 — 2026-11-21

首个可复现的 EdgeOne Makers 移植版。

### 架构
- 从本机 / GitHub Actions 的 Chromium 注册机迁移到 **EdgeOne Makers Agent + Sandbox**。
- 默认引擎改为 **ruyijs**（Linux 上的真实 Firefox SpiderMonkey + Necko，无窗口）；
  `engine=chromium` 保留为 Windows / 本地 CloakBrowser 可选路径。
- 沙箱内运行 `usque` 4.2.1 WARP（MASQUE over HTTP/2，TCP/443）；
  默认直连沙箱本机 IP，WARP 为可选换出口手段。
- 移除旧代理 / WARP 控制层 / VPNGate / URnetwork 的运行依赖。

### 修复与能力
- ruyijs 字体：运行时生成 `fonts/fontconfig.conf`，指向系统 DejaVu 与
  `~/.local/share/fonts`；解决 `canvas text measurement failed`。
- `/mfc` CORS 预检本地桩，避免 p.js 卡死。
- ruyijs Context 设备 cookie 播种；5025/2014 时关闭 Context 并新建会话。
- CloakBrowser 模式补齐 Linux stealth 参数（`--fingerprint` /
  `--fingerprint-platform=windows`），但 Linux + Windows 伪装仍会被 Kasada 5025。
- 上传默认开启（`upload=true`）；每个成功账号立即上传 TwitchCDK 控制台。
- 效率参数：`workers` 上限 6，`maxConcurrentCtx` 默认等于 workers，`startStagger`
  默认 3s；`syncProject` 用 bundle 版本标记跳过重复写入。
- 新增 `kpsdk_rejects` / `device_limiteds` 计数和 20KB 日志尾部，便于定位 5025。
- 新增 2 容器编排脚本 `scripts/run_multi.py`：每项目一容器、5 线程、5×9、轮次目标。
- 账号上传、账号落盘、`/status`、`/rotate`、`/diag`、`/fonts`、`/warp` 路由齐全。

### 实测
- 3×15：45/45，上传 45/45，203.3s（直连沙箱 IP）。
- 5×9：45/45，0 失败，上传 45/45，runner 111.1s / 总 125.9s。
- 单 worker 累计：1×45 45/45（3 次 5025）；同沙箱累计 60/60（4 次 5025）。
- 新工作区累计 180/180，上传 180/180，0 个 2014。
- 2 容器 × 5 线程 × 1 小时：A/B 各 29 轮、各 1,305，合计 2,610/2,610 上传，
  5 次 5025，0 个 2014，约 54.5 分钟。

### 推荐生产参数
- **2 个 worker（两个独立 Makers 项目 / 两个 `run_multi.py --containers 1` 进程）**
- **每容器 5 线程 × 28 轮目标 × 5×9=45/轮 = 2,520 个/批**
- 上传默认开启；28 轮约 3,080s，给 1 小时沙箱到期留约 500s。
- 18,000 vCPU-s 配额下约 13,600 vCPU-s；容器实测 2 vCPU / 4 GiB。

### 已知边界
- 5025 是**会话级**：每 ruyijs 会话约 14–15 个后出现一次，重建 Context 后继续。
- 单沙箱最长 3,600s；到期前要 `/rotate` 或重建项目。
- Free 版 Sandbox CPU 18,000 vCPU-s / 内存 100,000 GB-s / 最大并发 20；
  按 2 vCPU/4 GiB、1 小时算，约 2.5 个容器小时（2 个满 1 小时 + 0.5 小时余量）。
- 2 容器必须用**两个独立项目**；同一项目并发 warm 会 `RemoteDisconnected`。
- 2014 在 60/180 个内未出现；原“单 IP ≤15”应理解为**单会话 ≤15**。

### 发布方式
- 本文件是发布说明的源；每次更新先改这里，再执行：
  ```bash
  python scripts/build_release.py --version X.Y.Z
  ```
- 产物在 `release/`：`TW_REG_MAKERS_V1_vX.Y.Z.zip`、`CHANGELOG.md`、
  `SHA256SUMS`。
