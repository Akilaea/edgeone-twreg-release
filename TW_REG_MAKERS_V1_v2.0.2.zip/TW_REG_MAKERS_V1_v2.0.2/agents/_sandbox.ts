/**
 * Sandbox orchestration for the EdgeOne Makers port.
 *
 * The Python runner is embedded in `_twreg_bundle.ts` and written into the
 * sandbox on first use. Registration runs entirely inside the sandbox, so
 * outbound traffic uses the sandbox instance's IP — no proxy, no WARP, no
 * VPNGate.
 */

import type { AgentContext } from '@edgeone/types';
import { BUNDLE_VERSION, TWREG_FILES } from './_twreg_bundle';

export type Sandbox = NonNullable<AgentContext['sandbox']>;
export type BrowserMode = 'cloak' | 'cdp';

export const ROOT = '/home/user/twreg';
const DEPS_MARKER = `${ROOT}/.deps_${BUNDLE_VERSION}`;
const CLOAK_MARKER = `${ROOT}/.cloak_ok`;
const BUNDLE_MARKER = `${ROOT}/.bundle_version`;

export interface RunOptions {
  workers: number;
  accounts: number;
  mode: BrowserMode;
  upload: boolean;
  timeoutSec: number;
  cooldownSec: number;
  maxFails?: number;
  startStagger?: number;
  maxConcurrentCtx?: number;
  cdpUrl?: string;
  workerName?: string;
  mailApiUrl?: string;
  relayUrl?: string;
  proxy?: string;
  engine?: 'chromium' | 'ruyi';
  ruyiFirefox?: string;
}

export interface AccountLine {
  username: string;
  password: string;
  access_token: string;
}

export interface RunResult {
  success: number;
  failed: number;
  sessions: number;
  elapsed: number;
  uploaded?: number;
  upload_failed?: number;
  kpsdk_rejects?: number;
  device_limiteds?: number;
  file?: string;
  accounts?: AccountLine[];
  version?: string;
  cdp?: boolean;
  proxy?: string;
  engine?: string;
}

async function exists(sandbox: Sandbox, path: string): Promise<boolean> {
  try {
    const value = await sandbox.files.exists(path);
    return Boolean(value);
  } catch {
    return false;
  }
}

async function ensureDir(sandbox: Sandbox, path: string): Promise<void> {
  if (await exists(sandbox, path)) return;
  try {
    await sandbox.files.makeDir(path);
  } catch {
    // A concurrent request may have created it between exists() and makeDir().
  }
}

/** Write the embedded Python project into the sandbox. Idempotent. */
export async function syncProject(sandbox: Sandbox): Promise<number> {
  await ensureDir(sandbox, ROOT);
  if (await exists(sandbox, BUNDLE_MARKER)) {
    try {
      const current = String(await sandbox.files.read(BUNDLE_MARKER)).trim();
      if (current === BUNDLE_VERSION) return 0;
    } catch {
      /* rewrite below */
    }
  }
  let written = 0;
  for (const [rel, content] of Object.entries(TWREG_FILES)) {
    const path = `${ROOT}/${rel}`;
    const slash = path.lastIndexOf('/');
    if (slash > ROOT.length) await ensureDir(sandbox, path.slice(0, slash));
    await sandbox.files.write(path, content);
    written += 1;
  }
  await sandbox.files.write(BUNDLE_MARKER, BUNDLE_VERSION);
  return written;
}

/**
 * Some sandbox images expose `python3`, some only `python`. Resolve it once
 * and cache the absolute path in the project directory.
 */
export async function resolvePython(sandbox: Sandbox): Promise<string> {
  const marker = `${ROOT}/.python`;
  if (await exists(sandbox, marker)) {
    const cached = String(await sandbox.files.read(marker)).trim();
    if (cached) return cached;
  }
  const found = await sandbox.commands.run(
    'command -v python3 || command -v python || command -v /usr/bin/python3 || true',
    { timeout: 20 },
  );
  const py = String(found.stdout ?? '').trim().split(/\r?\n/)[0] || 'python3';
  await sandbox.files.write(marker, py);
  return py;
}

/** pip install once per bundle/sandbox; a requirements change forces reinstall. */
export async function ensureDeps(sandbox: Sandbox): Promise<void> {
  if (await exists(sandbox, DEPS_MARKER)) {
    try {
      const current = String(await sandbox.files.read(DEPS_MARKER)).trim();
      if (current === BUNDLE_VERSION) return;
    } catch {
      /* reinstall below */
    }
  }
  const py = shellQuote(await resolvePython(sandbox));
  const probe = await sandbox.commands.run(`${py} -V && ${py} -m pip -V`, {
    cwd: ROOT,
    timeout: 60,
  });
  if (probe.exitCode !== 0) {
    throw new Error(`sandbox python unavailable: ${tail(probe.stderr || probe.stdout)}`);
  }
  const install = await sandbox.commands.run(
    `${py} -m pip install --no-cache-dir -r requirements.txt `
    + '> .pip_install.log 2>&1; echo $? > .pip_install.rc; '
    + 'tail -30 .pip_install.log; exit 0',
    { cwd: ROOT, timeout: 600 },
  );
  const rc = Number((await readSafe(sandbox, `${ROOT}/.pip_install.rc`, 20)).trim());
  if (Number.isFinite(rc) && rc !== 0) {
    throw new Error(`pip install failed rc=${rc}: ${tail(install.stdout)}`);
  }
  await sandbox.files.write(DEPS_MARKER, BUNDLE_VERSION);
}

/**
 * Download CloakBrowser's stealth Chromium once. This is the default engine:
 * Kasada binds its rejection to the browser process, so the runner must be
 * able to kill and relaunch a fresh process on 5025. A CDP attach to the
 * sandbox's shared browser cannot do that.
 */
export async function ensureCloak(sandbox: Sandbox): Promise<void> {
  if (await exists(sandbox, CLOAK_MARKER)) return;
  const py = shellQuote(await resolvePython(sandbox));
  const pid = (await readSafe(sandbox, `${ROOT}/.cloak_install.pid`, 20)).trim();
  if (/^\d+$/.test(pid)) {
    const alive = await sandbox.commands.run(
      `kill -0 ${pid} 2>/dev/null && echo alive || echo dead`,
      { cwd: ROOT, timeout: 10 },
    );
    if (String(alive.stdout ?? '').includes('alive')) {
      throw new Error(`cloakbrowser install already running (pid=${pid}); poll /diag`);
    }
  }
  const previousRc = (await readSafe(sandbox, `${ROOT}/.cloak_install.rc`, 20)).trim();
  if (previousRc && Number(previousRc) !== 0) {
    throw new Error(`previous cloakbrowser install failed rc=${previousRc}: `
      + tail(await readSafe(sandbox, `${ROOT}/.cloak_install.log`, 800)));
  }
  const install = await sandbox.commands.run(
    `${py} -m cloakbrowser install `
    + '> .cloak_install.log 2>&1; echo $? > .cloak_install.rc; '
    + 'tail -30 .cloak_install.log; exit 0',
    { cwd: ROOT, timeout: 600 },
  );
  const rc = Number((await readSafe(sandbox, `${ROOT}/.cloak_install.rc`, 20)).trim());
  if (Number.isFinite(rc) && rc !== 0) {
    throw new Error(`cloakbrowser install failed rc=${rc}: ${tail(install.stdout)}`);
  }
  await sandbox.files.write(CLOAK_MARKER, new Date().toISOString());
}

/** Attach to the sandbox's built-in Chromium (optional mode). */
export async function resolveCdpUrl(sandbox: Sandbox): Promise<string> {
  const browser = sandbox.browser;
  if (!browser) throw new Error('sandbox.browser unavailable');
  let cdp = typeof browser.cdpUrl === 'string' ? browser.cdpUrl : '';
  if (!cdp) {
    await browser.goto('about:blank');
    cdp = typeof browser.cdpUrl === 'string' ? browser.cdpUrl : '';
  }
  if (!cdp) throw new Error('sandbox browser did not expose a cdpUrl');
  return cdp;
}

function shellQuote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function buildCommand(args: string[], env: Record<string, string> = {}): string {
  const assignments = Object.entries(env)
    .map(([key, value]) => `${key}=${shellQuote(value)}`)
    .join(' ');
  const command = args.map(shellQuote).join(' ');
  return assignments ? `${assignments} ${command}` : command;
}

export async function runBatch(sandbox: Sandbox, opts: RunOptions): Promise<{
  exitCode: number;
  stdout: string;
  stderr: string;
  result: RunResult | null;
}> {
  const py = await resolvePython(sandbox);
  const args = [
    py,
    'run.py',
    '--workers', String(opts.workers),
    '--accounts', String(opts.accounts),
    '--engine', opts.engine || 'ruyi',
    '--browser-mode', opts.mode,
    '--proxy', opts.proxy || 'direct',
    '--cooldown-sec', String(opts.cooldownSec),
    '--max-fails', String(opts.maxFails ?? 30),
    '--start-stagger', String(opts.startStagger ?? 3),
    '--log-dir', 'logs',
    '--accounts-dir', 'accounts',
  ];
  if (opts.mailApiUrl) args.push('--mail-api-url', opts.mailApiUrl);
  if (opts.ruyiFirefox) args.push('--ruyi-firefox', opts.ruyiFirefox);
  if (opts.relayUrl) args.push('--relay-url', opts.relayUrl);
  if (opts.upload) args.push('--upload');
  else args.push('--no-upload');
  if (opts.mode === 'cdp') {
    if (!opts.cdpUrl) throw new Error('cdp mode requires a cdpUrl');
    args.push('--cdp-url', opts.cdpUrl);
  }

  const env: Record<string, string> = {};
  if (opts.workerName) env.WORKER_NAME = opts.workerName;
  env.MAX_CONCURRENT_CTX = String(opts.maxConcurrentCtx ?? opts.workers);

  const command = buildCommand(args, env);
  const wrapper = `${command} > .run.out 2>&1; echo $? > .run.rc; `
    + 'cat .run.out; exit 0';
  const res = await sandbox.commands.run(wrapper, {
    cwd: ROOT,
    timeout: opts.timeoutSec,
  });
  const rcText = (await readSafe(sandbox, `${ROOT}/.run.rc`, 20)).trim();
  const stdout = String(res.stdout ?? '');
  return {
    exitCode: rcText && Number.isFinite(Number(rcText)) ? Number(rcText) : 0,
    stdout,
    stderr: String(res.stderr ?? ''),
    result: parseResult(stdout),
  };
}

/**
 * Start a detached batch loop inside the sandbox. The HTTP request returns
 * immediately; the sandbox command keeps running until durationSec elapses.
 */
export async function startContinuous(
  sandbox: Sandbox,
  opts: RunOptions & { durationSec: number },
): Promise<{ pid: string; durationSec: number }> {
  const py = await resolvePython(sandbox);
  const args = [
    py,
    'run.py',
    '--workers', String(opts.workers),
    '--accounts', String(Math.max(1, opts.accounts)),
    '--engine', opts.engine || 'ruyi',
    '--browser-mode', opts.mode,
    '--proxy', opts.proxy || 'direct',
    '--cooldown-sec', String(opts.cooldownSec),
    '--max-fails', String(opts.maxFails ?? 30),
    '--start-stagger', String(opts.startStagger ?? 3),
    '--log-dir', 'logs',
    '--accounts-dir', 'accounts',
  ];
  if (opts.mailApiUrl) args.push('--mail-api-url', opts.mailApiUrl);
  if (opts.ruyiFirefox) args.push('--ruyi-firefox', opts.ruyiFirefox);
  if (opts.relayUrl) args.push('--relay-url', opts.relayUrl);
  if (opts.upload) args.push('--upload');
  else args.push('--no-upload');
  if (opts.mode === 'cdp') {
    if (!opts.cdpUrl) throw new Error('cdp mode requires a cdpUrl');
    args.push('--cdp-url', opts.cdpUrl);
  }

  const env: Record<string, string> = {};
  if (opts.workerName) env.WORKER_NAME = opts.workerName;
  env.MAX_CONCURRENT_CTX = String(opts.maxConcurrentCtx ?? opts.workers);
  const command = buildCommand(args, env);
  const duration = Math.min(3600, Math.max(60, Math.trunc(opts.durationSec || 3400)));
  const script = [
    '#!/bin/bash',
    'set -u',
    `cd '${ROOT}'`,
    `END=$(( $(date +%s) + ${duration} ))`,
    'while [ "$(date +%s)" -lt "$END" ]; do',
    `  ${command} > .continuous.log 2>&1`,
    '  sleep 3',
    'done',
    '',
  ].join('\n');
  await sandbox.files.write(`${ROOT}/.continuous.sh`, script);
  const launched = await sandbox.commands.run(
    'chmod +x .continuous.sh; '
    + 'if command -v setsid >/dev/null 2>&1; then '
    + 'setsid nohup bash .continuous.sh >/dev/null 2>&1 < /dev/null & '
    + 'else nohup bash .continuous.sh >/dev/null 2>&1 < /dev/null & fi; '
    + 'echo $! > .continuous.pid; cat .continuous.pid',
    { cwd: ROOT, timeout: 20 },
  );
  const pid = String(launched.stdout ?? '').trim().split(/\r?\n/).filter(Boolean).pop() || '';
  return { pid, durationSec: duration };
}

/** Open /signup once and report whether KPSDK becomes ready. */
export async function runProbe(sandbox: Sandbox, opts: {
  mode: BrowserMode;
  cdpUrl?: string;
  proxy?: string;
  engine?: 'chromium' | 'ruyi';
  timeoutSec?: number;
}): Promise<{ exitCode: number; stdout: string; stderr: string }> {
  const py = await resolvePython(sandbox);
  const args = [
    py,
    'run.py',
    '--probe',
    '--engine', opts.engine || 'ruyi',
    '--browser-mode', opts.mode,
    '--proxy', opts.proxy || 'direct',
  ];
  if (opts.mode === 'cdp') {
    if (!opts.cdpUrl) throw new Error('cdp mode requires a cdpUrl');
    args.push('--cdp-url', opts.cdpUrl);
  }
  const wrapper = `${buildCommand(args)} > .probe.out 2>&1; echo $? > .probe.rc; `
    + 'cat .probe.out; exit 0';
  const res = await sandbox.commands.run(wrapper, {
    cwd: ROOT,
    timeout: opts.timeoutSec ?? 180,
  });
  const rcText = (await readSafe(sandbox, `${ROOT}/.probe.rc`, 20)).trim();
  return {
    exitCode: rcText && Number.isFinite(Number(rcText)) ? Number(rcText) : 0,
    stdout: String(res.stdout ?? ''),
    stderr: String(res.stderr ?? ''),
  };
}

export function parseResult(stdout: string): RunResult | null {
  const marker = 'TWREG_RESULT ';
  const line = stdout
    .split(/\r?\n/)
    .reverse()
    .find((item) => item.startsWith(marker));
  if (!line) return null;
  try {
    return JSON.parse(line.slice(marker.length)) as RunResult;
  } catch {
    return null;
  }
}

export function parseAccountLines(text: string): AccountLine[] {
  const lines: AccountLine[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    const space = line.indexOf(' ');
    if (space <= 0) continue;
    const left = line.slice(0, space);
    const token = line.slice(space + 1);
    const colon = left.indexOf(':');
    if (colon <= 0) continue;
    lines.push({
      username: left.slice(0, colon),
      password: left.slice(colon + 1),
      access_token: token,
    });
  }
  return lines;
}

export async function readLastRun(sandbox: Sandbox): Promise<{
  result: RunResult | null;
  accounts: AccountLine[];
}> {
  let result: RunResult | null = null;
  try {
    const raw = await sandbox.files.read(`${ROOT}/logs/last_run.json`);
    result = JSON.parse(raw) as RunResult;
  } catch {
    result = null;
  }

  let accounts: AccountLine[] = [];
  try {
    const entries = await sandbox.files.list(`${ROOT}/accounts`);
    const files = (entries || [])
      .filter((entry: any) => String(entry?.name || '').endsWith('.txt'))
      .sort((a: any, b: any) => String(b.name).localeCompare(String(a.name)));
    if (files.length > 0) {
      const text = await sandbox.files.read(`${ROOT}/accounts/${files[0].name}`);
      accounts = parseAccountLines(String(text));
    }
  } catch {
    accounts = [];
  }
  return { result, accounts };
}

/** Read the sandbox egress IP / Cloudflare colo for verification. */
export async function fetchEgress(sandbox: Sandbox): Promise<Record<string, string>> {
  const curl = await sandbox.commands.run(
    'curl -s --max-time 10 https://cloudflare.com/cdn-cgi/trace || true',
    { timeout: 20 },
  );
  let text = String(curl.stdout ?? '');
  if (!text.includes('ip=')) {
    const python = shellQuote(await resolvePython(sandbox));
    const py = await sandbox.commands.run(
      `${python} -c "import urllib.request;`
      + "print(urllib.request.urlopen('https://cloudflare.com/cdn-cgi/trace',"
      + 'timeout=10).read().decode())"',
      { timeout: 25 },
    );
    text = String(py.stdout ?? '');
  }
  const out: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    const key = line.slice(0, eq).trim();
    if (['ip', 'loc', 'colo', 'warp', 'h'].includes(key)) {
      out[key] = line.slice(eq + 1).trim();
    }
  }
  return out;
}

export interface InstallState {
  rootExists: boolean;
  depsOk: boolean;
  cloakOk: boolean;
  pipLog: string;
  cloakLog: string;
  cloakRc: string;
  python: string;
  cloakInfo: string;
  envInfo: string;
  netChecks: string;
  hardware: string;
}

/**
 * Start the CloakBrowser binary download in the background so the HTTP
 * request can return before EdgeOne's 600s gateway timeout. Poll /diag.
 */
export async function startCloakInstall(sandbox: Sandbox): Promise<string> {
  const py = await resolvePython(sandbox);
  const script = [
    '#!/bin/sh',
    `cd ${ROOT}`,
    `${py} -m cloakbrowser install > .cloak_install.log 2>&1`,
    'rc=$?',
    'echo $rc > .cloak_install.rc',
    '[ "$rc" -eq 0 ] && touch .cloak_ok',
    'exit $rc',
    '',
  ].join('\n');
  await sandbox.files.write(`${ROOT}/install_cloak.sh`, script);
  const res = await sandbox.commands.run(
    'chmod +x install_cloak.sh; nohup ./install_cloak.sh >/dev/null 2>&1 & echo $!',
    { cwd: ROOT, timeout: 20 },
  );
  const pid = String(res.stdout ?? '').trim().split(/\r?\n/)[0] || '';
  await sandbox.files.write(`${ROOT}/.cloak_install.pid`, pid);
  return pid;
}

async function readSafe(sandbox: Sandbox, path: string, limit = 3000): Promise<string> {
  try {
    const text = String(await sandbox.files.read(path));
    return text.length <= limit ? text : text.slice(-limit);
  } catch {
    return '';
  }
}

/** Inspect the sandbox install state without starting a long job. */
export async function installState(sandbox: Sandbox): Promise<InstallState> {
  const rootExists = await exists(sandbox, ROOT);
  const depsOk = await exists(sandbox, DEPS_MARKER);
  const cloakOk = await exists(sandbox, CLOAK_MARKER);
  const python = rootExists ? await readSafe(sandbox, `${ROOT}/.python`, 200) : '';
  const pipLog = rootExists ? await readSafe(sandbox, `${ROOT}/.pip_install.log`) : '';
  const cloakLog = rootExists ? await readSafe(sandbox, `${ROOT}/.cloak_install.log`) : '';
  const cloakRc = rootExists ? await readSafe(sandbox, `${ROOT}/.cloak_install.rc`, 20) : '';
  let cloakInfo = '';
  let envInfo = '';
  let netChecks = '';
  let hardware = '';
  try {
    const hw = await sandbox.commands.run(
      'echo nproc=$(nproc 2>/dev/null || true); '
      + 'echo processors=$(grep -c "^processor" /proc/cpuinfo 2>/dev/null || true); '
      + 'echo cgroup_v2_cpu_max=$(cat /sys/fs/cgroup/cpu.max 2>/dev/null || true); '
      + 'echo cgroup_v1_quota=$(cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us 2>/dev/null || true); '
      + 'echo cgroup_v1_period=$(cat /sys/fs/cgroup/cpu/cpu.cfs_period_us 2>/dev/null || true); '
      + "echo mem_total_kb=$(awk '/MemTotal/{print $2}' /proc/meminfo 2>/dev/null || true); "
      + 'echo cgroup_v2_mem_max=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || true); '
      + 'echo cgroup_v1_mem_limit=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || true); '
      + 'echo cpus_allowed=$(grep Cpus_allowed_list /proc/self/status 2>/dev/null || true)',
      { timeout: 20 },
    );
    hardware = tail(String(hw.stdout ?? hw.stderr ?? ''), 1000);
  } catch (error) {
    hardware = error instanceof Error ? error.message : String(error);
  }
  if (depsOk) {
    const py = shellQuote(python.trim() || await resolvePython(sandbox));
    try {
      const res = await sandbox.commands.run(
        `${py} -m cloakbrowser info 2>&1 | head -25`,
        { timeout: 30 },
      );
      cloakInfo = tail(String(res.stdout ?? res.stderr ?? ''), 1200);
    } catch (error) {
      cloakInfo = error instanceof Error ? error.message : String(error);
    }
    try {
      const env = await sandbox.commands.run(
        'echo DISPLAY=${DISPLAY:-unset}; uname -a; '
        + 'echo fonts=$(fc-list 2>/dev/null | wc -l); '
        + 'fc-list 2>/dev/null | grep -iE "segoe|calibri|arial|liberation|dejavu" | head -8',
        { timeout: 20 },
      );
      envInfo = tail(String(env.stdout ?? env.stderr ?? ''), 1200);
    } catch (error) {
      envInfo = error instanceof Error ? error.message : String(error);
    }
    try {
      const py = shellQuote(python.trim() || await resolvePython(sandbox));
      const checks = await sandbox.commands.run(
        `${py} netcheck.py`,
        { cwd: ROOT, timeout: 150 },
      );
      netChecks = tail(String(checks.stdout ?? checks.stderr ?? ''), 1200);
    } catch (error) {
      netChecks = error instanceof Error ? error.message : String(error);
    }
  }
  return { rootExists, depsOk, cloakOk, pipLog, cloakLog, cloakRc, python,
           cloakInfo, envInfo, netChecks, hardware };
}

/** Kill the instance so the next request lazily creates a new sandbox/IP. */
export async function killSandbox(sandbox: Sandbox): Promise<boolean> {
  const candidate = sandbox as any;
  if (typeof candidate.kill !== 'function') return false;
  await candidate.kill();
  return true;
}

export function tail(text: string, limit = 1500): string {
  const clean = (text || '').trim();
  return clean.length <= limit ? clean : clean.slice(-limit);
}
