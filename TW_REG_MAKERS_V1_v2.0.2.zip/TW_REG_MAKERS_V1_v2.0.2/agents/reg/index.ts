/**
 * POST /reg — run a registration batch inside the EdgeOne Sandbox.
 *
 * Body:
 *   {
 *     "workers": 1,          // 1..3
 *     "accounts": 1,         // per worker, 1..60
 *     "mode": "cloak",       // cloak (default, process rebuild) | cdp
 *     "upload": true,        // push results to the TwitchCDK console (default)
 *     "reset": false,        // kill the sandbox first (new egress IP next call)
 *     "timeout": 1500,       // seconds, 60..1650
 *     "cooldown": 30,        // seconds after two zero-account sessions
 *     "fallback": true,      // cdp fallback if CloakBrowser install fails
 *     "workerName": "reg_edgeone"
 *   }
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import {
  ensureCloak,
  ensureDeps,
  killSandbox,
  readLastRun,
  resolveCdpUrl,
  runBatch,
  runProbe,
  startCloakInstall,
  startContinuous,
  syncProject,
  tail,
  type BrowserMode,
  type RunResult,
} from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

function intIn(value: unknown, min: number, max: number, fallback: number): number {
  const parsed = typeof value === 'number' ? value : Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(parsed)));
}

function boolOf(value: unknown, fallback: boolean): boolean {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (['1', 'true', 'yes', 'on'].includes(v)) return true;
    if (['0', 'false', 'no', 'off', ''].includes(v)) return false;
  }
  return fallback;
}

export async function onRequest(context: AgentContext): Promise<Response> {
  if (context.request.method !== 'POST') {
    return methodNotAllowed(context.request.method);
  }
  const denied = requireAuth(context);
  if (denied) return denied;

  const body = (context.request.body ?? {}) as Record<string, unknown>;
  const sandbox = context.sandbox;
  if (!sandbox) {
    return json({ error: 'sandbox unavailable; check edgeone.json agents.sandbox' }, 503);
  }

  if (boolOf(body.reset, false)) {
    const killed = await killSandbox(sandbox);
    return json({
      ok: true,
      reset: true,
      killed,
      note: killed
        ? 'next /reg lazily creates a new sandbox with a new egress IP'
        : 'sandbox.kill() is not available on this runtime',
    });
  }

  const workers = intIn(body.workers, 1, 6, 1);
  const accounts = intIn(body.accounts, 0, 60, 1);
  const probeOnly = boolOf(body.probe, false);
  const installOnly = boolOf(body.install, false);
  const mode = (String(body.mode ?? 'cloak').toLowerCase() === 'cdp' ? 'cdp' : 'cloak') as BrowserMode;
  const engine = String(body.engine ?? 'ruyi').toLowerCase() === 'ruyi'
    ? 'ruyi'
    : 'chromium';
  const ruyiFirefox = typeof body.ruyiFirefox === 'string'
    ? body.ruyiFirefox.trim().slice(0, 8)
    : undefined;
  const upload = boolOf(body.upload, true);
  const continuous = boolOf(body.continuous, false);
  const durationSec = intIn(body.duration, 60, 3600, 3400);
  const timeoutSec = intIn(body.timeout, 60, 1650, 900);
  const cooldownSec = intIn(body.cooldown, 0, 300, 30);
  const maxFails = intIn(body.maxFails, 1, 50, 30);
  const staggerRaw = Number(body.startStagger);
  const startStagger = Number.isFinite(staggerRaw)
    ? Math.min(30, Math.max(0, staggerRaw))
    : 3;
  const maxConcurrentCtx = intIn(body.maxConcurrentCtx, 1, 8, workers);
  const fallback = boolOf(body.fallback, true);
  const workerName = typeof body.workerName === 'string'
    ? body.workerName.slice(0, 64)
    : undefined;
  const mailApiUrl = typeof body.mailApiUrl === 'string' && body.mailApiUrl.trim()
    ? body.mailApiUrl.trim()
    : (context.env.MAIL_API_URL || undefined);
  const relayUrl = typeof body.relayUrl === 'string' && body.relayUrl.trim()
    ? body.relayUrl.trim()
    : (context.env.TWREG_RELAY_URL || undefined);
  const warp = boolOf(body.warp, false);
  let proxy: string | undefined;
  const rawProxy = typeof body.proxy === 'string' ? body.proxy.trim() : '';
  if (/^(http|socks5)h?:\/\/127\.0\.0\.1:\d+$/.test(rawProxy)) {
    proxy = rawProxy;
  }
  if (warp) proxy = 'http://127.0.0.1:25345';

  const startedAt = Date.now();
  try {
    const files = await syncProject(sandbox);
    await ensureDeps(sandbox);

    if (installOnly) {
      if (engine === 'ruyi') {
        return json({
          ok: true,
          install: 'deps',
          engine,
          bundle: BUNDLE_VERSION,
          note: 'ruyijs installed from requirements; no CloakBrowser download needed',
        }, 202);
      }
      const pid = await startCloakInstall(sandbox);
      return json({
        ok: true,
        install: 'cloak',
        engine,
        pid,
        bundle: BUNDLE_VERSION,
        note: 'background download started; poll /diag until state.cloakOk is true',
      }, 202);
    }

    let effectiveMode: BrowserMode = mode;
    let cdpUrl: string | undefined;
    let warning: string | undefined;

    if (engine === 'chromium') {
      if (effectiveMode === 'cloak') {
        try {
          await ensureCloak(sandbox);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          if (!fallback) throw error;
          effectiveMode = 'cdp';
          warning = `CloakBrowser install failed, fell back to cdp: ${tail(message, 400)}`;
        }
      }
      if (effectiveMode === 'cdp') {
        cdpUrl = await resolveCdpUrl(sandbox);
      }
    }

    if (probeOnly) {
      const probe = await runProbe(sandbox, {
        mode: effectiveMode,
        cdpUrl,
        proxy,
        engine,
        timeoutSec: Math.min(300, timeoutSec),
      });
      return json({
        ok: probe.exitCode === 0,
        warm: true,
        probe: true,
        engine,
        bundle: BUNDLE_VERSION,
        mode: engine === 'ruyi' ? 'ruyi' : effectiveMode,
        warning,
        exitCode: probe.exitCode,
        probe_stdout: tail(probe.stdout, 4000),
        probe_stderr: tail(probe.stderr),
      }, probe.exitCode === 0 ? 200 : 502);
    }

    if (continuous) {
      const started = await startContinuous(sandbox, {
        workers,
        accounts: Math.max(1, accounts),
        engine,
        mode: effectiveMode,
        upload,
        timeoutSec,
        cooldownSec,
        maxFails,
        startStagger,
        maxConcurrentCtx,
        cdpUrl,
        workerName,
        mailApiUrl,
        relayUrl,
        proxy,
        ruyiFirefox,
        durationSec,
      });
      return json({
        ok: true,
        continuous: true,
        pid: started.pid,
        duration: started.durationSec,
        workers,
        accounts: Math.max(1, accounts),
        engine,
        mode: engine === 'ruyi' ? 'ruyi' : effectiveMode,
        bundle: BUNDLE_VERSION,
        warning,
        note: 'continuous loop started in sandbox; no follow-up request required',
      });
    }

    if (accounts === 0) {
      return json({
        ok: true,
        warm: true,
        engine,
        bundle: BUNDLE_VERSION,
        mode: engine === 'ruyi' ? 'ruyi' : effectiveMode,
        warning,
        note: 'dependencies and engine are ready; send accounts>0 to register',
      });
    }

    const run = await runBatch(sandbox, {
      workers,
      accounts,
      engine,
      mode: effectiveMode,
      upload,
      timeoutSec,
      cooldownSec,
      maxFails,
      startStagger,
      maxConcurrentCtx,
      cdpUrl,
      workerName,
      mailApiUrl,
      relayUrl,
      proxy,
      ruyiFirefox,
    });

    let result: RunResult | null = run.result;
    if (!result) {
      const fallbackRead = await readLastRun(sandbox);
      result = fallbackRead.result;
    }
    const stored = await readLastRun(sandbox);

    const ok = Boolean(result && (result.success ?? 0) > 0);
    const payload = {
      ok,
      bundle: BUNDLE_VERSION,
      engine,
      mode: engine === 'ruyi' ? 'ruyi' : effectiveMode,
      warning,
      workers,
      accounts,
      requested: workers * accounts,
      elapsed: ((Date.now() - startedAt) / 1000).toFixed(1),
      result: result ?? null,
      accounts_list: stored.accounts,
      exitCode: run.exitCode,
      log_tail: tail(run.stdout, 20000) || undefined,
      error_tail: run.exitCode === 0 ? undefined : tail(run.stderr) || undefined,
      files,
    };
    return json(payload, ok ? 200 : 502);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({
      ok: false,
      bundle: BUNDLE_VERSION,
      mode,
      error: message,
      elapsed: ((Date.now() - startedAt) / 1000).toFixed(1),
    }, 500);
  }
}
