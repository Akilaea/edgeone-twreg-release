"""Upload Windows fonts into an EdgeOne Makers sandbox.

Usage:
    python scripts/upload_fonts.py \
        --signed-url "https://<project>.edgeone.dev?eo_token=...&eo_time=..." \
        --token "<REG_API_TOKEN>" \
        --conversation twreg-test-001 \
        --fonts-dir "C:/Windows/Fonts"

Each font is sent as one base64 JSON body to POST /fonts. The Makers preset
domain access cookie is established by GET-ing the signed URL first.
"""

from __future__ import annotations

import argparse
import base64
import pathlib
import sys

import requests
from urllib3 import disable_warnings

disable_warnings()

DEFAULT_FONTS = [
    "segoeui.ttf",       # Segoe UI
    "segoeuil.ttf",      # Segoe UI Light
    "calibri.ttf",       # Calibri
    "marlett.ttf",       # Marlett
    "framd.ttf",         # Franklin Gothic
    "consola.ttf",       # Consolas
    "cour.ttf",          # Courier New
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--signed-url", required=True,
                        help="signed Makers URL with eo_token/eo_time query")
    parser.add_argument("--token", required=True, help="REG_API_TOKEN")
    parser.add_argument("--conversation", default="twreg-test-001")
    parser.add_argument("--fonts-dir", default="C:/Windows/Fonts")
    parser.add_argument("--only", nargs="*", default=None,
                        help="subset of font filenames")
    args = parser.parse_args()

    base = args.signed_url.split("?")[0]
    session = requests.Session()
    session.trust_env = False
    session.headers.update({
        "Authorization": f"Bearer {args.token}",
        "Makers-Conversation-Id": args.conversation,
    })
    session.get(args.signed_url, timeout=30, verify=False, allow_redirects=True)

    fonts_dir = pathlib.Path(args.fonts_dir)
    names = args.only or DEFAULT_FONTS
    failures = 0
    for name in names:
        path = fonts_dir / name
        if not path.is_file():
            print(f"MISS {name}")
            failures += 1
            continue
        payload = base64.b64encode(path.read_bytes()).decode("ascii")
        try:
            response = session.post(
                f"{base}/fonts",
                json={"name": name, "b64": payload},
                timeout=180,
                verify=False,
            )
        except Exception as exc:  # noqa: BLE001 - diagnostics
            print(f"FAIL {name}: {type(exc).__name__}: {exc}")
            failures += 1
            continue
        text = response.text.replace("\n", " ")[:220]
        print(f"{response.status_code} {name} ({len(payload)} b64) {text}")
        if response.status_code != 200:
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
