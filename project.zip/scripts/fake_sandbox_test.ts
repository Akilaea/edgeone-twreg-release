/**
 * Pure orchestration test with a fake sandbox. No EdgeOne credentials needed.
 *
 *   npx tsx scripts/fake_sandbox_test.ts
 */

import {
  ROOT,
  parseAccountLines,
  parseResult,
  runBatch,
  syncProject,
  type Sandbox,
} from '../agents/_sandbox';
import { TWREG_FILES } from '../agents/_twreg_bundle';
import { onRequest as regHandler } from '../agents/reg/index';

const store = new Map<string, string>();
const dirs = new Set<string>([ROOT]);
const calls: Array<{ cmd: string; opts: any }> = [];

const sandbox = {
  files: {
    exists: async (path: string) => store.has(path) || dirs.has(path),
    makeDir: async (path: string) => {
      dirs.add(path);
    },
    write: async (path: string, content: string) => {
      store.set(path, content);
    },
    read: async (path: string) => {
      const value = store.get(path);
      if (value === undefined) throw new Error(`ENOENT ${path}`);
      return value;
    },
    list: async (path: string) => [...store.keys()]
      .filter((key) => key.startsWith(`${path}/`))
      .map((key) => ({ name: key.slice(path.length + 1), type: 'file', path: key })),
  },
  commands: {
    run: async (cmd: string, opts: any) => {
      calls.push({ cmd, opts });
      if (cmd.includes('command -v python3')) {
        return { exitCode: 0, stdout: '/usr/bin/python3\n', stderr: '' };
      }
      return {
        exitCode: 0,
        stdout: 'noise\nTWREG_RESULT {"success":1,"failed":0,"sessions":2,'
          + '"elapsed":36.2,"accounts":[{"username":"u","password":"p","access_token":"t"}]}\n',
        stderr: '',
      };
    },
  },
  browser: { cdpUrl: '' },
  kill: async () => undefined,
} as unknown as Sandbox;

function assert(condition: unknown, message: string): void {
  if (!condition) throw new Error(`ASSERT: ${message}`);
}

async function main(): Promise<void> {
  const written = await syncProject(sandbox);
  assert(written === Object.keys(TWREG_FILES).length, 'every embedded file written');
  assert(store.has(`${ROOT}/run.py`), 'run.py present');
  assert(store.has(`${ROOT}/twreg/chromium.py`), 'nested module present');
  assert(store.get(`${ROOT}/requirements.txt`)?.includes('cloakbrowser'), 'requirements present');

  const cloak = await runBatch(sandbox, {
    workers: 1,
    accounts: 1,
    mode: 'cloak',
    upload: false,
    timeoutSec: 120,
    cooldownSec: 0,
    workerName: 'test-worker',
  });
  assert(cloak.exitCode === 0, 'cloak exit code');
  assert(cloak.result?.success === 1, 'result parsed');
  const cloakCall = calls[calls.length - 1];
  assert(cloakCall.cmd.includes("'--browser-mode' 'cloak'"), 'mode flag');
  assert(cloakCall.cmd.includes("'--proxy' 'direct'"), 'direct proxy flag');
  assert(cloakCall.cmd.includes("'--no-upload'"), 'no-upload flag');
  assert(!cloakCall.cmd.includes('--cdp-url'), 'no cdp url in cloak mode');
  assert(cloakCall.opts.cwd === ROOT, 'cwd is sandbox root');
  assert(cloakCall.cmd.startsWith("WORKER_NAME='test-worker'"), 'env prefix');

  const cdp = await runBatch(sandbox, {
    workers: 2,
    accounts: 3,
    mode: 'cdp',
    upload: true,
    timeoutSec: 600,
    cooldownSec: 10,
    cdpUrl: 'ws://127.0.0.1:9222/devtools/browser/x',
  });
  assert(cdp.exitCode === 0, 'cdp exit code');
  const cdpCall = calls[calls.length - 1];
  assert(cdpCall.cmd.includes("'--cdp-url' 'ws://127.0.0.1:9222/devtools/browser/x'"),
    'cdp url is shell-quoted');
  assert(cdpCall.cmd.includes("'--upload'"), 'upload flag');

  assert(parseResult('x\nTWREG_RESULT {"success":0}')?.success === 0, 'parse zero result');
  const accounts = parseAccountLines('u1:p1 t1\nu2:p2 t2\n');
  assert(accounts.length === 2, 'account lines');
  assert(accounts[0].username === 'u1' && accounts[0].access_token === 't1', 'account parse');

  // ---- handler-level flow (fake sandbox, no EdgeOne credentials) ----
  store.set(`${ROOT}/.deps_ok`, 'ok');
  store.set(`${ROOT}/.cloak_ok`, 'ok');

  const makeContext = (body: Record<string, unknown>, auth?: string) => ({
    request: {
      method: 'POST',
      body,
      headers: auth ? { authorization: `Bearer ${auth}` } : {},
    },
    env: { REG_API_TOKEN: 'secret' },
    sandbox,
  }) as any;

  const warm = await regHandler(makeContext({ accounts: 0 }, 'secret'));
  const warmJson: any = await warm.json();
  assert(warm.status === 200, 'warm status');
  assert(warmJson.warm === true && warmJson.mode === 'ruyi', 'warm payload');

  const probe = await regHandler(makeContext({ probe: true, accounts: 1 }, 'secret'));
  const probeJson: any = await probe.json();
  assert(probe.status === 200, 'probe status');
  assert(probeJson.probe === true && probeJson.mode === 'ruyi', 'probe payload');

  const denied = await regHandler({
    request: { method: 'POST', body: { accounts: 0 }, headers: {} },
    env: { REG_API_TOKEN: 'secret' },
    sandbox,
  } as any);
  assert(denied.status === 401, 'auth gate');

  const reset = await regHandler(makeContext({ reset: true }, 'secret'));
  const resetJson: any = await reset.json();
  assert(resetJson.reset === true, 'reset payload');

  console.log(`ok — ${written} files embedded, ${calls.length} sandbox commands checked`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
