"""Run one Makers container with W workers (round-based, uploads on).

Each container is one Makers conversation id -> one sandbox instance.  Rounds
are 5x9 by default (workers=5, accounts=9) so every worker stays below the
~14-15 per-session 5025 boundary; uploads are on.

EdgeOne closes concurrent agent requests on the SAME project, so the tested
2-container pattern is: two independent Makers projects, two instances of this
script (one per project).  ``--containers`` is kept for independent CIDs but
same-project concurrency is not reliable.

Example (one container / one project; run this twice for two projects):
    python scripts/run_multi.py \
        --signed-url "https://<project>.edgeone.dev?eo_token=...&eo_time=..." \
        --token "<REG_API_TOKEN>" \
        --containers 1 --workers 5 --accounts 9 \
        --seconds 3400 --out .test/multi_a.jsonl
"""

from __future__ import annotations

import argparse
import json
import threading
import time

import requests
from urllib3 import disable_warnings

disable_warnings()

PRINT_LOCK = threading.Lock()
STATS_LOCK = threading.Lock()


def _post_json(session: requests.Session, base: str, path: str, body: dict,
               timeout: float) -> tuple[int, dict]:
    response = session.post(base + path, json=body, timeout=timeout, verify=False)
    try:
        return response.status_code, response.json()
    except Exception:
        return response.status_code, {"error": response.text[:300]}


def container_loop(index: int, cid: str, args: argparse.Namespace,
                   signed: str, token: str, out_path: str,
                   totals: dict) -> None:
    session = requests.Session()
    session.trust_env = False
    session.headers.update({
        "Authorization": "Bearer " + token,
        "Makers-Conversation-Id": cid,
    })
    session.get(signed, timeout=30, verify=False, allow_redirects=True)
    base = signed.split("?")[0]

    # Warm the sandbox and install ruyijs once.  The sandbox lifetime clock
    # starts before this call, so the round loop is bounded from here.
    started = time.time()
    try:
        _post_json(session, base, "/reg",
                   {"workers": args.workers, "accounts": 0, "upload": True},
                   timeout=180)
    except Exception as exc:  # noqa: BLE001
        with PRINT_LOCK:
            print(f"[C{index}] warm error {type(exc).__name__}: {exc}", flush=True)
        totals[index] = {"rounds": 0, "success": 0, "failed": 0,
                         "uploaded": 0, "upload_failed": 0,
                         "kpsdk_rejects": 0, "device_limiteds": 0,
                         "error": f"warm: {exc}"}
        return

    rounds = success = failed = uploaded = upload_failed = 0
    kpsdk_rejects = device_limiteds = 0
    error = ""
    while rounds < args.rounds:
        remaining = args.seconds - (time.time() - started)
        if remaining < args.round_guard:
            break
        body = {
            "workers": args.workers,
            "accounts": args.accounts,
            "upload": True,
            "maxFails": args.max_fails,
            "timeout": args.round_timeout,
            "startStagger": args.start_stagger,
            "maxConcurrentCtx": args.workers,
            "cooldown": 0,
            "workerName": args.worker_name,
        }
        t0 = time.time()
        try:
            status, payload = _post_json(session, base, "/reg", body,
                                         timeout=args.round_timeout + 60)
        except Exception as exc:  # noqa: BLE001
            error = f"{type(exc).__name__}: {exc}"
            break
        result = payload.get("result") or {}
        rounds += 1
        success += int(result.get("success") or 0)
        failed += int(result.get("failed") or 0)
        uploaded += int(result.get("uploaded") or 0)
        upload_failed += int(result.get("upload_failed") or 0)
        kpsdk_rejects += int(result.get("kpsdk_rejects") or 0)
        device_limiteds += int(result.get("device_limiteds") or 0)
        record = {
            "t": time.strftime("%H:%M:%S"),
            "container": index,
            "cid": cid,
            "round": rounds,
            "status": status,
            "success": result.get("success"),
            "failed": result.get("failed"),
            "sessions": result.get("sessions"),
            "elapsed": result.get("elapsed"),
            "kpsdk_rejects": result.get("kpsdk_rejects"),
            "device_limiteds": result.get("device_limiteds"),
            "uploaded": result.get("uploaded"),
            "upload_failed": result.get("upload_failed"),
            "round_wall": round(time.time() - t0, 1),
            "error": payload.get("error"),
        }
        with STATS_LOCK:
            with open(out_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        with PRINT_LOCK:
            print(json.dumps(record, ensure_ascii=False), flush=True)
        if status != 200 or not result:
            error = str(payload.get("error") or f"http {status}")
            break
    totals[index] = {
        "cid": cid, "rounds": rounds, "success": success, "failed": failed,
        "uploaded": uploaded, "upload_failed": upload_failed,
        "kpsdk_rejects": kpsdk_rejects, "device_limiteds": device_limiteds,
        "seconds": round(time.time() - started, 1), "error": error,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--signed-url", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--containers", type=int, default=1)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--accounts", type=int, default=9)
    parser.add_argument("--rounds", type=int, default=28)
    parser.add_argument("--seconds", type=int, default=3400)
    parser.add_argument("--round-guard", type=int, default=160)
    parser.add_argument("--round-timeout", type=int, default=300)
    parser.add_argument("--max-fails", type=int, default=12)
    parser.add_argument("--start-stagger", type=float, default=3)
    parser.add_argument("--worker-name", default="reg_edgeone_multi")
    parser.add_argument("--cid-prefix", default="twreg-multi")
    parser.add_argument("--out", default=".test/multi_stats.jsonl")
    args = parser.parse_args()

    totals: dict = {}
    threads = []
    for index in range(1, args.containers + 1):
        cid = f"{args.cid_prefix}-{index:03d}"
        thread = threading.Thread(
            target=container_loop,
            args=(index, cid, args, args.signed_url, args.token, args.out, totals),
            daemon=False,
        )
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join()

    summary = {
        "containers": args.containers,
        "workers": args.workers,
        "accounts_per_worker": args.accounts,
        "rounds_target": args.rounds,
        "seconds": args.seconds,
        "total_rounds": sum(v.get("rounds", 0) for v in totals.values()),
        "total_success": sum(v.get("success", 0) for v in totals.values()),
        "total_failed": sum(v.get("failed", 0) for v in totals.values()),
        "total_uploaded": sum(v.get("uploaded", 0) for v in totals.values()),
        "total_upload_failed": sum(v.get("upload_failed", 0) for v in totals.values()),
        "total_5025": sum(v.get("kpsdk_rejects", 0) for v in totals.values()),
        "total_2014": sum(v.get("device_limiteds", 0) for v in totals.values()),
        "per_container": totals,
    }
    print("SUMMARY " + json.dumps(summary, ensure_ascii=False), flush=True)
    with open(args.out, "a", encoding="utf-8") as fh:
        fh.write("SUMMARY " + json.dumps(summary, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
