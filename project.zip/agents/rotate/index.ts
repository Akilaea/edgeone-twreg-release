/**
 * POST /rotate — kill the sandbox instance.
 *
 * EdgeOne Makers creates a fresh sandbox on the next access, which is the
 * platform-native way to change the egress IP. This replaces the old
 * WARP/VPNGate rotation layer.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { killSandbox } from '../_sandbox';

export async function onRequest(context: AgentContext): Promise<Response> {
  if (context.request.method !== 'POST') {
    return methodNotAllowed(context.request.method);
  }
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) {
    return json({ ok: false, error: 'sandbox unavailable' }, 503);
  }
  try {
    const killed = await killSandbox(sandbox);
    return json({
      ok: true,
      rotated: killed,
      note: killed
        ? 'sandbox killed; next /reg gets a new instance and a new egress IP'
        : 'sandbox.kill() is not available on this runtime',
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: message }, 500);
  }
}
