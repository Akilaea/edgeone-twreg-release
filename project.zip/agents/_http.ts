import type { AgentContext } from '@edgeone/types';

export const JSON_HEADERS = {
  'Content-Type': 'application/json; charset=UTF-8',
  'Cache-Control': 'no-store',
} as const;

export function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

/**
 * Optional bearer gate. Set REG_API_TOKEN in the Makers project env to turn
 * the registration routes into a private endpoint. Unset = open (default,
 * because the route path itself is already the secret).
 */
export function requireAuth(context: AgentContext): Response | null {
  const expected = (context.env.REG_API_TOKEN || '').trim();
  if (!expected) return null;
  const raw = context.request.headers['authorization'] || '';
  const token = raw.replace(/^Bearer\s+/i, '').trim();
  if (token === expected) return null;
  return json({ error: 'unauthorized' }, 401);
}

export function methodNotAllowed(method: string): Response {
  return json({ error: `method ${method} not allowed` }, 405);
}
