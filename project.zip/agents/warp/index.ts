/**
 * POST /warp — manage the in-sandbox usque WARP tunnel.
 *
 * Body:
 *   { "action": "up" | "down" | "rotate" | "status", "http2": true }
 *
 * "up" downloads the usque binary, registers a WARP identity, starts the
 * userspace MASQUE tunnel, and exposes an HTTP CONNECT proxy on
 * 127.0.0.1:25345. The usque process is detached, so it survives the request.
 * Then call /reg with {"warp": true} to send Chromium through it.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { ROOT, resolvePython, syncProject, tail } from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

const PROXY = 'http://127.0.0.1:25345';

function parseTrace(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of text.split(/\r?\n/)) {
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return out;
}

async function proxyTrace(sandbox: any): Promise<{ ok: boolean; trace: Record<string, string>; raw: string }> {
  const res = await sandbox.commands.run(
    `curl -s --max-time 20 -x ${PROXY} https://cloudflare.com/cdn-cgi/trace || true`,
    { timeout: 30 },
  );
  const raw = String(res.stdout ?? '');
  const trace = parseTrace(raw);
  return { ok: Boolean(trace.ip), trace, raw: tail(raw, 600) };
}

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'POST' && method !== 'GET') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) return json({ ok: false, error: 'sandbox unavailable' }, 503);

  const body = (context.request.body ?? {}) as Record<string, unknown>;
  const action = String(body.action ?? (method === 'GET' ? 'status' : 'status')).toLowerCase();
  const http2 = body.http2 === undefined ? true : Boolean(body.http2);
  const endpoints = typeof body.endpoints === 'string' ? body.endpoints.trim() : '';
  const endpointFlag = endpoints && /^[0-9A-Fa-f:.,=\-]+$/.test(endpoints)
    ? ` --endpoints '${endpoints}'`
    : '';

  try {
    await syncProject(sandbox);
    const py = await resolvePython(sandbox);
    const flag = http2 ? ' --http2' : '';

    if (action === 'status') {
      const state = await proxyTrace(sandbox);
      return json({ ok: state.ok, bundle: BUNDLE_VERSION, action, proxy: PROXY,
                    trace: state.trace, raw: state.raw });
    }

    if (action === 'tunnel') {
      // Expose the sandbox WARP proxy on a public TCP port for a local
      // isolation test (Windows browser -> WARP SIN). Short-lived by design.
      const install = await sandbox.commands.run(
        'if [ ! -x ./bore ]; then '
        + 'curl -sL -m 120 -o bore.tar.gz '
        + 'https://github.com/ekzhang/bore/releases/download/v0.6.0/'
        + 'bore-v0.6.0-x86_64-unknown-linux-musl.tar.gz && '
        + 'tar xzf bore.tar.gz && chmod +x bore; fi; ./bore --version || true',
        { cwd: ROOT, timeout: 180 },
      );
      await sandbox.commands.run(
        '(pkill -f "bore local" >/dev/null 2>&1 || true); '
        + 'setsid ./bore local 25345 --to bore.pub > .bore.log 2>&1 '
        + '< /dev/null & echo $!; true',
        { cwd: ROOT, timeout: 20 },
      );
      let log = '';
      for (let i = 0; i < 25; i += 1) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
        try {
          log = String(await sandbox.files.read(`${ROOT}/.bore.log`));
        } catch {
          log = '';
        }
        const match = log.match(/bore\.pub:(\d+)/);
        if (match) {
          return json({
            ok: true,
            action,
            host: 'bore.pub',
            port: Number(match[1]),
            install: tail(String(install.stdout ?? ''), 300),
            log: tail(log, 600),
          });
        }
      }
      return json({ ok: false, action, log: tail(log, 1200) }, 502);
    }

    if (action === 'down') {
      const res = await sandbox.commands.run(
        `${py} -m twreg.warp --down --work-dir .warp`,
        { cwd: ROOT, timeout: 120 },
      );
      return json({ ok: true, action, proxy: PROXY,
                    stdout: tail(String(res.stdout ?? '')),
                    stderr: tail(String(res.stderr ?? '')) });
    }

    if (action !== 'up' && action !== 'rotate') {
      return json({ ok: false, error: `unknown action: ${action}` }, 400);
    }

    const command = action === 'up'
      ? `${py} -m twreg.warp --up${flag}${endpointFlag} --work-dir .warp`
      : `${py} -m twreg.warp --rotate${flag}${endpointFlag} --work-dir .warp`;
    const wrapper = `${command} > .warp_cmd.out 2>&1; `
      + 'echo $? > .warp_cmd.rc; cat .warp_cmd.out; exit 0';
    const started = Date.now();
    const res = await sandbox.commands.run(wrapper, { cwd: ROOT, timeout: 500 });
    let rc = '';
    try {
      rc = String(await sandbox.files.read(`${ROOT}/.warp_cmd.rc`)).trim();
    } catch {
      rc = '';
    }
    const state = await proxyTrace(sandbox);
    return json({
      ok: state.ok && (rc === '' || rc === '0'),
      bundle: BUNDLE_VERSION,
      action,
      http2,
      endpoints: endpoints || undefined,
      rc,
      proxy: PROXY,
      elapsed: ((Date.now() - started) / 1000).toFixed(1),
      trace: state.trace,
      raw: state.raw,
      stdout: tail(String(res.stdout ?? ''), 2000),
      stderr: tail(String(res.stderr ?? '')),
    }, state.ok && (rc === '' || rc === '0') ? 200 : 502);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message) }, 500);
  }
}
