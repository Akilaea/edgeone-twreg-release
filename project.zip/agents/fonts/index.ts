/**
 * POST /fonts — install one Windows font into the sandbox.
 *
 * Body: { name: "calibri.ttf", b64: "<base64>" }
 *
 * CloakBrowser's Windows fingerprint profile checks eight tell-tale fonts
 * (Segoe UI, Segoe UI Light, Calibri, Marlett, MS UI Gothic, Franklin Gothic,
 * Consolas, Courier New). Without them a Linux host contradicts the Windows
 * claim and Kasada's font probe flags the session.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { ROOT, syncProject, tail } from '../_sandbox';

const NAME_RE = /^[A-Za-z0-9._-]+\.(ttf|ttc|otf)$/i;

export async function onRequest(context: AgentContext): Promise<Response> {
  if (context.request.method !== 'POST') {
    return methodNotAllowed(context.request.method);
  }
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) return json({ ok: false, error: 'sandbox unavailable' }, 503);

  const body = (context.request.body ?? {}) as Record<string, unknown>;
  const name = String(body.name ?? '').trim();
  const b64 = String(body.b64 ?? '').replace(/\s+/g, '');
  if (!NAME_RE.test(name)) return json({ ok: false, error: 'invalid font name' }, 400);
  if (!b64) return json({ ok: false, error: 'b64 required' }, 400);
  if (b64.length > 5_500_000) {
    return json({ ok: false, error: `b64 too large: ${b64.length}` }, 413);
  }

  try {
    await syncProject(sandbox);
    await sandbox.files.write(`${ROOT}/fonts/${name}.b64`, b64);
    const command = [
      'mkdir -p "$HOME/.local/share/fonts"',
      `base64 -d "${ROOT}/fonts/${name}.b64" > "$HOME/.local/share/fonts/${name}"`,
      'fc-cache -f >/dev/null 2>&1 || true',
      `ls -l "$HOME/.local/share/fonts/${name}"`,
      "fc-list 2>/dev/null | grep -icE 'segoe|calibri|marlett|franklin|consolas|courier' || true",
    ].join('; ');
    const res = await sandbox.commands.run(command, { cwd: ROOT, timeout: 120 });
    return json({
      ok: true,
      name,
      size: b64.length,
      output: tail(String(res.stdout ?? res.stderr ?? ''), 800),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message) }, 500);
  }
}
