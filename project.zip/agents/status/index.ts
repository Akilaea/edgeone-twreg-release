/**
 * GET /status — inspect the current sandbox batch result and saved accounts.
 * POST is accepted as well so a browser form / curl -X POST works.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { readLastRun, tail } from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'GET' && method !== 'POST') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) {
    return json({ ok: false, error: 'sandbox unavailable' }, 503);
  }

  try {
    const { result, accounts } = await readLastRun(sandbox);
    return json({
      ok: true,
      bundle: BUNDLE_VERSION,
      result,
      accounts,
      accounts_count: accounts.length,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message) }, 500);
  }
}
