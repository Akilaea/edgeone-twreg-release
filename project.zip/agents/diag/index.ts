/**
 * GET /diag — inspect the sandbox install state and recent logs.
 *
 * This route never starts a long job; it is safe to poll while a warm-up is
 * running in another request.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { installState, tail } from '../_sandbox';
import { BUNDLE_VERSION } from '../_twreg_bundle';

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'GET' && method !== 'POST') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) return json({ ok: false, error: 'sandbox unavailable' }, 503);

  try {
    const state = await installState(sandbox);
    return json({ ok: true, bundle: BUNDLE_VERSION, state });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message) }, 500);
  }
}
