/**
 * GET /ip — report the sandbox egress IP and Cloudflare colo.
 *
 * Useful to prove the "no proxy, EdgeOne sandbox IP" property before a run.
 */

import type { AgentContext } from '@edgeone/types';
import { json, methodNotAllowed, requireAuth } from '../_http';
import { fetchEgress, tail } from '../_sandbox';

export async function onRequest(context: AgentContext): Promise<Response> {
  const method = context.request.method;
  if (method !== 'GET' && method !== 'POST') return methodNotAllowed(method);
  const denied = requireAuth(context);
  if (denied) return denied;

  const sandbox = context.sandbox;
  if (!sandbox) {
    return json({ ok: false, error: 'sandbox unavailable' }, 503);
  }
  try {
    const egress = await fetchEgress(sandbox);
    return json({ ok: Boolean(egress.ip), egress });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return json({ ok: false, error: tail(message) }, 500);
  }
}
