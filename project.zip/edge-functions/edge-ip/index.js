/**
 * GET /edge-ip — report the Edge Function's outbound IP.
 * Edge Functions run on CDN edge nodes; this is not the sandbox IP.
 */

export async function onRequest() {
  try {
    const response = await fetch('https://cloudflare.com/cdn-cgi/trace', {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const text = await response.text();
    const wanted = text
      .split(/\r?\n/)
      .filter((line) => /^(ip|loc|colo|warp|h)=/.test(line))
      .join('\n');
    return new Response(wanted || text.slice(0, 500), {
      headers: {
        'Content-Type': 'text/plain; charset=UTF-8',
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    return new Response(`error: ${error && error.message ? error.message : error}`, {
      status: 500,
      headers: { 'Content-Type': 'text/plain; charset=UTF-8' },
    });
  }
}
