/**
 * POST /relay — forward one Twitch registration request through the Edge
 * Function's egress (CDN edge node) instead of the sandbox IP.
 *
 * Body:     { url, method, headers, body }
 * Response: { status, headers, body }
 *
 * Allowlist is deliberately narrow: this is not a general-purpose proxy.
 */

const ALLOWED_HOSTS = new Set([
  'passport.twitch.tv',
  'www.twitch.tv',
  'gql.twitch.tv',
]);

const DROP_HEADERS = new Set([
  'host',
  'content-length',
  'connection',
  'accept-encoding',
  'transfer-encoding',
]);

export async function onRequest(context) {
  const request = context.request;
  if (request.method !== 'POST') {
    return json({ error: 'POST only' }, 405);
  }

  let envelope;
  try {
    envelope = await request.json();
  } catch {
    return json({ error: 'invalid json' }, 400);
  }

  let target;
  try {
    target = new URL(String((envelope && envelope.url) || ''));
  } catch {
    return json({ error: 'invalid url' }, 400);
  }
  if (!ALLOWED_HOSTS.has(target.hostname)) {
    return json({ error: `host not allowed: ${target.hostname}` }, 400);
  }

  const headers = new Headers();
  for (const [key, value] of Object.entries((envelope && envelope.headers) || {})) {
    if (DROP_HEADERS.has(key.toLowerCase())) continue;
    if (value === undefined || value === null) continue;
    try {
      headers.set(key, String(value));
    } catch {
      /* forbidden header in this runtime */
    }
  }

  const method = String((envelope && envelope.method) || 'POST').toUpperCase();
  const body = envelope && envelope.body !== undefined && envelope.body !== null
    ? String(envelope.body)
    : undefined;

  try {
    const upstream = await fetch(target.toString(), {
      method,
      headers,
      body: method === 'GET' || method === 'HEAD' ? undefined : body,
      redirect: 'manual',
    });
    const text = await upstream.text();
    const responseHeaders = {};
    for (const [key, value] of upstream.headers.entries()) {
      if (DROP_HEADERS.has(key.toLowerCase())) continue;
      if (key.toLowerCase() === 'set-cookie') continue;
      responseHeaders[key] = value;
    }
    let setCookies = [];
    if (typeof upstream.headers.getSetCookie === 'function') {
      setCookies = upstream.headers.getSetCookie();
    } else {
      const single = upstream.headers.get('set-cookie');
      if (single) setCookies = [single];
    }
    return json({
      status: upstream.status,
      headers: responseHeaders,
      setCookies,
      body: text,
    }, 200);
  } catch (error) {
    return json({ error: error && error.message ? error.message : String(error) }, 502);
  }
}

function json(data, status) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'Cache-Control': 'no-store',
    },
  });
}
