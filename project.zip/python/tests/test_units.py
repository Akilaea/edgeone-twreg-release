"""Pure unit tests for the EdgeOne Makers port — no network, no browser."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import requests
from loguru import logger

from twreg.config import Settings, resolve_proxy
from twreg.cookies import build_cookies, cookies_for_export, random_password
from twreg.mail import resolve_domain
from twreg.profile import (random_birthday, random_email_prefix,
                           random_password_length, random_username)
from twreg.registration_chromium import register_one_chromium
from twreg.runner import AccountStore
from twreg.upload import AccountUploader

logger.remove()


class ProxyTest(unittest.TestCase):
    def test_empty_is_direct(self):
        self.assertIsNone(resolve_proxy(""))
        self.assertIsNone(resolve_proxy(None))

    def test_direct_variants(self):
        for value in ("direct", "none", "-", "off", " OFF "):
            self.assertIsNone(resolve_proxy(value))

    def test_explicit_proxy_preserved_for_local_dev(self):
        self.assertEqual(resolve_proxy("http://127.0.0.1:7897"),
                         "http://127.0.0.1:7897")


class SettingsTest(unittest.TestCase):
    def test_defaults(self):
        s = Settings.from_env({})
        self.assertEqual(s.workers, 5)
        self.assertEqual(s.accounts_per_worker, 15)
        self.assertIsNone(s.proxy)
        self.assertEqual(s.mail_domain, "*.jsip.us")
        self.assertEqual(s.max_concurrent_ctx, 3)
        self.assertTrue(s.profile_random)
        self.assertTrue(s.enable_upload)
        self.assertEqual(s.cdp_url, "")
        self.assertEqual(s.browser_mode, "auto")
        self.assertEqual(s.total_accounts, 75)

    def test_env_and_overrides(self):
        s = Settings.from_env(
            {"WORKERS": "2", "ACCOUNTS": "7", "PROXY_SERVER": "direct",
             "ENABLE_UPLOAD": "1", "PASSWORD_LEN": "20",
             "TWREG_CDP_URL": "ws://127.0.0.1:9222", "BROWSER_MODE": "cdp"},
            overrides={"workers": 1, "proxy": "http://10.0.0.1:7890"},
        )
        self.assertEqual(s.workers, 1)
        self.assertEqual(s.accounts_per_worker, 7)
        self.assertEqual(s.proxy, "http://10.0.0.1:7890")
        self.assertEqual(s.cdp_url, "ws://127.0.0.1:9222")
        self.assertEqual(s.browser_mode, "cdp")
        self.assertTrue(s.enable_upload)
        self.assertEqual(s.password_len, 20)

    def test_invalid_numbers_fall_back(self):
        s = Settings.from_env({"WORKERS": "abc", "ACCOUNTS": "0"})
        self.assertEqual(s.workers, 5)
        self.assertEqual(s.accounts_per_worker, 1)


class PasswordTest(unittest.TestCase):
    def test_complexity_and_length(self):
        for _ in range(50):
            pwd = random_password(16)
            self.assertEqual(len(pwd), 16)
            self.assertTrue(any(c.islower() for c in pwd))
            self.assertTrue(any(c.isupper() for c in pwd))
            self.assertTrue(any(c.isdigit() for c in pwd))
            self.assertTrue(any(c in "!@#$%^&*" for c in pwd))

    def test_minimum_length(self):
        self.assertEqual(len(random_password(8)), 8)


class CookieTest(unittest.TestCase):
    def test_full_cookie_set(self):
        cookies = build_cookies("token123", "42", "tester")
        self.assertEqual(len(cookies), 8)
        names = {c["name"] for c in cookies}
        self.assertEqual(names, {"auth-token", "twilight-user", "api_token", "unique_id",
                                 "unique_id_durable", "server_session_id",
                                 "twitch.lohp.countryCode", "experiment_overrides"})
        self.assertTrue(all(c["domain"] == ".twitch.tv" for c in cookies))
        auth = next(c for c in cookies if c["name"] == "auth-token")
        self.assertTrue(auth["httpOnly"])
        twilight = json.loads(next(c for c in cookies if c["name"] == "twilight-user")["value"])
        self.assertEqual(twilight["authToken"], "token123")
        self.assertEqual(twilight["id"], 42)
        self.assertEqual(twilight["login"], "tester")

    def test_export_is_compact_json(self):
        raw = cookies_for_export(build_cookies("t", 1, "u"))
        self.assertNotIn(" ", raw)
        self.assertEqual(len(json.loads(raw)), 8)


class ProfileTest(unittest.TestCase):
    def test_username_rules(self):
        for _ in range(200):
            name = random_username()
            self.assertRegex(name, r"^[a-z][a-z0-9_]{3,24}$")
            self.assertFalse(name.endswith("_"))

    def test_email_prefix(self):
        for _ in range(100):
            self.assertRegex(random_email_prefix(), r"^[a-z][a-z0-9]{5,9}$")

    def test_birthday_range(self):
        for _ in range(100):
            b = random_birthday()
            self.assertTrue(1 <= b["day"] <= 28)
            self.assertTrue(1 <= b["month"] <= 12)
            self.assertTrue(1988 <= b["year"] <= 2007)
            self.assertTrue(b["isOver18"])

    def test_password_length(self):
        for _ in range(100):
            self.assertTrue(13 <= random_password_length() <= 18)


class MailDomainTest(unittest.TestCase):
    def test_wildcard_subdomain(self):
        domain = resolve_domain("*.jsip.us")
        self.assertRegex(domain, r"^[0-9a-f]{10}\.jsip\.us$")

    def test_fixed_domain(self):
        self.assertEqual(resolve_domain("mail.example.com"), "mail.example.com")


class FakeSession:
    def __init__(self):
        self.payloads = []

    def new_page(self):
        return None

    def open_signup(self, timeout=45.0):
        return True

    def register(self, payload, timeout=60):
        self.payloads.append(json.loads(json.dumps(payload)))
        if len(self.payloads) == 1:
            return {"status": 202, "body": json.dumps({"error_code": 2026})}
        return {"status": 200, "body": json.dumps({"access_token": "tok",
                                                   "userID": 12345})}


class FakeMail:
    def create_address(self, prefix, domain):
        return f"{prefix}@x.jsip.us", "mail-token"

    def wait_code(self, token, timeout):
        return "123456"


class RegistrationTest(unittest.TestCase):
    def test_two_step_flow(self):
        session = FakeSession()
        result = register_one_chromium(session, FakeMail(), 1,
                                       prefix="tw", password="Passw0rd!123456")
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["access_token"], "tok")
        self.assertEqual(result["user_id"], "12345")
        self.assertEqual(session.payloads[0]["username"], result["username"])
        self.assertEqual(session.payloads[1]["email_verification_code"], "123456")
        self.assertEqual(len(result["cookies"]), 8)

    def test_kasada_reject(self):
        class RejectSession(FakeSession):
            def register(self, payload, timeout=60):
                return {"status": 403, "body": json.dumps({"error_code": 5025})}
        result = register_one_chromium(RejectSession(), FakeMail(), 1)
        self.assertEqual(result["status"], "kpsdk_reject")

    def test_mail_failure(self):
        class BadMail:
            def create_address(self, prefix, domain):
                raise RuntimeError("mail down")
        result = register_one_chromium(FakeSession(), BadMail(), 1)
        self.assertEqual(result["status"], "failed")
        self.assertIn("create_email_failed", result["error"])


class UploadTest(unittest.TestCase):
    URL = "http://47.98.228.129:5000"

    def _uploader(self):
        return AccountUploader(self.URL, "token123", "w1")

    @patch.object(requests.Session, "post")
    def test_upload_payload_and_headers(self, post):
        response = Mock(status_code=200)
        response.json.return_value = {"code": 0, "message": "success"}
        post.return_value = response
        ok = self._uploader().upload("u", "p", "e@x.com", "tok", "[{}]")
        self.assertTrue(ok)
        args, kwargs = post.call_args
        self.assertTrue(args[0].endswith("/api/accounts/upload"))
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer token123")
        self.assertEqual(kwargs["headers"]["X-Worker-Id"], "w1")
        self.assertEqual(kwargs["json"]["username"], "u")
        self.assertEqual(kwargs["json"]["auth_token"], "tok")
        self.assertEqual(kwargs["json"]["cookies"], "[{}]")

    @patch.object(requests.Session, "post")
    def test_upload_401_does_not_retry(self, post):
        response = Mock(status_code=401)
        response.json.return_value = {"detail": "invalid token"}
        post.return_value = response
        self.assertFalse(self._uploader().upload("u", "p", "e", "t", "[]"))
        self.assertEqual(post.call_count, 1)

    @patch.object(requests.Session, "post")
    def test_upload_retries_5xx(self, post):
        bad = Mock(status_code=500)
        bad.json.return_value = {"code": 500}
        good = Mock(status_code=200)
        good.json.return_value = {"code": 0}
        post.side_effect = [bad, good]
        with patch("twreg.upload.time.sleep"):
            self.assertTrue(self._uploader().upload("u", "p", "e", "t", "[]"))
        self.assertEqual(post.call_count, 2)

    @patch.object(requests.Session, "post")
    def test_heartbeat_public(self, post):
        response = Mock(status_code=200)
        response.content = b"{}"
        response.json.return_value = {"code": 0, "data": {"worker_name": "w1"}}
        post.return_value = response
        self.assertTrue(self._uploader().heartbeat())
        self.assertTrue(post.call_args[0][0].endswith("/api/workers/heartbeat"))


class AccountStoreTest(unittest.TestCase):
    def test_save_and_read_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = AccountStore(Path(tmp), stamp="test")
            store.save({"username": "u1", "password": "p1", "access_token": "t1"})
            store.save({"username": "u2", "password": "p2", "access_token": "t2"})
            lines = store.path.read_text(encoding="utf-8").splitlines()
            self.assertEqual(lines, ["u1:p1 t1", "u2:p2 t2"])
            entries = store.read_entries()
            self.assertEqual(entries[0], {"username": "u1", "password": "p1",
                                          "access_token": "t1"})
            self.assertEqual(len(entries), 2)


if __name__ == "__main__":
    unittest.main()
