"""Sandbox connectivity check used by /diag."""

from __future__ import annotations

import ssl
import time
import urllib.request

URLS = [
    "https://mail.minecraft.fashion/",
    "https://mail.minecraft.fashion/api/v1/addresses",
    "https://passport.twitch.tv/",
    "https://www.twitch.tv/signup",
    "http://47.98.228.129:5000/",
]


def main() -> None:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    for url in URLS:
        started = time.time()
        try:
            request = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=30, context=ctx) as response:
                print(f"{url} status={response.status} "
                      f"time={time.time() - started:.1f}s")
        except Exception as exc:  # noqa: BLE001 - diagnostics only
            print(f"{url} error={type(exc).__name__}:{str(exc)[:120]} "
                  f"time={time.time() - started:.1f}s")


if __name__ == "__main__":
    main()
