"""CLI entry point for the EdgeOne Makers port.

Runs the Chromium registration flow against the sandbox browser:

    python run.py --workers 1 --accounts 1 --no-upload \
        --browser-mode cdp --cdp-url "$TWREG_CDP_URL"

The final line on stdout is ``TWREG_RESULT <json>`` so the EdgeOne agent
handler can parse a machine-readable summary without scraping logs.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import replace
from pathlib import Path

from loguru import logger

from twreg import __version__
from twreg.config import Settings, load_dotenv
from twreg.logging_setup import setup_logging
from twreg.runner import AccountStore, Runner

ROOT = Path(__file__).resolve().parent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run.py",
        description="Twitch registration runner (EdgeOne Makers / Chromium)",
    )
    parser.add_argument("--workers", type=int, default=None, help="并行线程数")
    parser.add_argument("--accounts", type=int, default=None, help="每个线程注册账号数")
    parser.add_argument("--cdp-url", default=None,
                        help="沙箱浏览器 CDP 地址；提供后直接 attach，不再拉起本地浏览器")
    parser.add_argument("--browser-mode", default=None, choices=["auto", "cdp", "cloak"],
                        help="auto=有 cdp-url 就用 cdp；cloak=拉起 CloakBrowser")
    parser.add_argument("--engine", default=None, choices=["chromium", "ruyi"],
                        help="chromium=CloakBrowser；ruyi=Linux ruyijs Firefox 引擎")
    parser.add_argument("--ruyi-timezone", default=None)
    parser.add_argument("--ruyi-locale", default=None)
    parser.add_argument("--ruyi-country", default=None)
    parser.add_argument("--ruyi-firefox", default=None,
                        help="ruyijs TLS/UA Firefox 版本；默认 159（Kasada 通过组合）")
    parser.add_argument("--ruyi-screen", default=None)
    parser.add_argument("--ruyi-viewport", default=None)
    parser.add_argument("--proxy", default=None,
                        help="仅本地调试用；direct/none 表示直连（沙箱默认）")
    parser.add_argument("--relay-url", default=None,
                        help="Edge Function relay 的 signed URL；注册 POST 走边缘出口")
    parser.add_argument("--warp", action="store_true",
                        help="在进程内启动 usque WARP 出口，浏览器走本地 CONNECT 代理")
    parser.add_argument("--warp-http2", action="store_true",
                        help="WARP 使用 MASQUE over HTTP/2（UDP 被封时）")
    parser.add_argument("--warp-work-dir", default=".warp", help="WARP 工作目录")
    parser.add_argument("--warp-endpoints", default="", help="WARP 端点池，逗号分隔")
    parser.add_argument("--mail-domain", default=None, help="收信域名，*.xxx 表示随机子域")
    parser.add_argument("--mail-api-url", default=None, help="临时邮箱 API 根地址")
    parser.add_argument("--prefix", default=None, help="邮箱/用户名前缀")
    parser.add_argument("--password-len", type=int, default=None, help="密码长度（>=8）")
    parser.add_argument("--accounts-dir", default=None, help="账号落盘目录")
    parser.add_argument("--log-dir", default=None, help="日志目录")
    parser.add_argument("--max-fails", type=int, default=None, help="单线程失败上限")
    parser.add_argument("--cooldown-sec", type=int, default=None,
                        help="连续 2 个 0 账号会话后的冷却秒数，0=关闭")
    parser.add_argument("--start-stagger", type=float, default=None,
                        help="线程启动错峰秒数（R0 立即，R1 等 N 秒...）")
    parser.add_argument("--log-level", default=None, help="控制台日志级别")
    parser.add_argument("--upload", dest="upload", action="store_true", default=None,
                        help="上传账号到收集服务器")
    parser.add_argument("--no-upload", dest="upload", action="store_false",
                        help="只落盘，不上传")
    parser.add_argument("--probe", action="store_true",
                        help="只验证浏览器/KPSDK 就绪，不注册任何账号")
    parser.add_argument("--version", action="version", version=f"twreg-makers {__version__}")
    return parser


def _settings_from_args(args: argparse.Namespace) -> Settings:
    return Settings.from_env(overrides={
        "workers": args.workers,
        "accounts_per_worker": args.accounts,
        "cdp_url": args.cdp_url,
        "browser_mode": args.browser_mode,
        "browser_engine": args.engine,
        "ruyi_timezone": args.ruyi_timezone,
        "ruyi_locale": args.ruyi_locale,
        "ruyi_country": args.ruyi_country,
        "ruyi_firefox": args.ruyi_firefox,
        "ruyi_screen": args.ruyi_screen,
        "ruyi_viewport": args.ruyi_viewport,
        "proxy": args.proxy,
        "relay_url": args.relay_url,
        "mail_domain": args.mail_domain,
        "mail_api_url": args.mail_api_url,
        "prefix": args.prefix,
        "password_len": args.password_len,
        "accounts_dir": Path(args.accounts_dir) if args.accounts_dir else None,
        "log_dir": Path(args.log_dir) if args.log_dir else None,
        "max_fails": args.max_fails,
        "cooldown_sec": args.cooldown_sec,
        "start_stagger_sec": args.start_stagger,
        "log_level": args.log_level.upper() if args.log_level else None,
        "enable_upload": args.upload,
    })


def setup_fonts() -> Path:
    """Generate a fontconfig that includes system + uploaded Windows fonts.

    ruyijs' canvas measureText fails on a font-less container; the reference
    branch ships DejaVu fonts for this. The sandbox already has DejaVu under
    /usr/share/fonts, so point fontconfig there and at ~/.local/share/fonts
    (where /fonts uploads land).
    """
    fonts_dir = ROOT / "fonts"
    fonts_dir.mkdir(parents=True, exist_ok=True)
    conf = fonts_dir / "fontconfig.conf"
    home = Path.home()
    conf.write_text(
        '<?xml version="1.0"?>\n'
        '<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n'
        '<fontconfig>\n'
        '  <dir>/usr/share/fonts</dir>\n'
        '  <dir>/usr/local/share/fonts</dir>\n'
        f'  <dir>{home}/.local/share/fonts</dir>\n'
        '  <cachedir>/tmp/fc-cache</cachedir>\n'
        '  <alias binding="same"><family>sans-serif</family>'
        '<prefer><family>DejaVu Sans</family></prefer></alias>\n'
        '  <alias binding="same"><family>serif</family>'
        '<prefer><family>DejaVu Sans</family></prefer></alias>\n'
        '  <alias binding="same"><family>monospace</family>'
        '<prefer><family>DejaVu Sans Mono</family></prefer></alias>\n'
        '  <match target="pattern">\n'
        '    <test qual="any" name="family"><string>sans-serif</string></test>\n'
        '    <edit name="family" mode="assign" binding="same">'
        '<string>DejaVu Sans</string></edit>\n'
        '  </match>\n'
        '</fontconfig>\n',
        encoding="utf-8",
    )
    os.environ.setdefault("FONTCONFIG_FILE", str(conf))
    os.environ.setdefault("FONTCONFIG_PATH", str(fonts_dir))
    os.environ.setdefault("XDG_CACHE_HOME", "/tmp")
    return conf


def probe(settings: Settings) -> int:
    if settings.browser_engine == "ruyi":
        from twreg.ruyi import RuyiSession
        logger.info(f"probe: engine=ruyi proxy={settings.proxy or '直连'} "
                    f"fonts={os.getenv('FONTCONFIG_FILE')}")
        session = RuyiSession(
            proxy=settings.proxy, timezone=settings.ruyi_timezone,
            locale=settings.ruyi_locale, country=settings.ruyi_country,
            cache_dir=settings.cache_dir,
            firefox_version=settings.ruyi_firefox,
        )
        ready = session.open()
        info = {"ready": bool(ready), "engine": "ruyi",
                "stats": session.stats(),
                "fontconfig": os.getenv("FONTCONFIG_FILE")}
        session.close()
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0 if ready else 2

    from twreg.chromium import ChromiumSession
    logger.info(f"probe: mode={settings.browser_mode} "
                f"cdp={'yes' if settings.cdp_url else 'no'} "
                f"proxy={settings.proxy or '直连'}")
    session = ChromiumSession(
        proxy=settings.proxy, cdp_url=settings.cdp_url,
        browser_mode=settings.browser_mode, headless=settings.headless,
    )
    if not session.open():
        logger.error("probe 失败：浏览器未就绪")
        return 1
    ready = session.open_signup()
    info = {
        "ready": bool(ready),
        "user_agent": session.page.evaluate("navigator.userAgent") if session.page else None,
        "sessions": session.sessions,
    }
    session.close()
    print(json.dumps(info, ensure_ascii=False, indent=2))
    return 0 if ready else 2


def _start_warp(args: argparse.Namespace):
    from twreg.warp import WarpEgress, parse_endpoints
    pool = parse_endpoints(args.warp_endpoints or "")
    transport = "http2" if args.warp_http2 else "quic"
    egress = WarpEgress(work_dir=Path(args.warp_work_dir),
                        endpoints=pool or None, transport=transport)
    url = egress.up()
    logger.info(f"WARP 出口就绪: {url} transport={transport}")
    return egress, url


def main() -> int:
    load_dotenv(ROOT / ".env")
    args = build_parser().parse_args()
    settings = _settings_from_args(args)
    setup_logging(settings.log_dir, settings.log_level)
    setup_fonts()

    warp_egress = None
    try:
        if args.warp:
            try:
                warp_egress, url = _start_warp(args)
            except Exception as exc:
                logger.error(f"WARP 启动失败: {type(exc).__name__}: {exc}")
                return 1
            settings = replace(settings, proxy=url)

        if args.probe:
            return probe(settings)

        store = AccountStore(settings.accounts_dir)
        result = Runner(settings, store=store).run()
        result["version"] = __version__
        result["engine"] = settings.browser_engine
        result["cdp"] = bool(settings.cdp_url)
        result["proxy"] = settings.proxy or "direct"

        out = Path(settings.log_dir) / "last_run.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print("TWREG_RESULT " + json.dumps(result, ensure_ascii=False))
        return 0 if result.get("success", 0) > 0 else 2
    finally:
        if warp_egress is not None:
            try:
                warp_egress.down()
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
