"""Chromium engine for EdgeOne Makers.

Two attachment modes:

- ``cdp``: Playwright connects to the Chromium that the EdgeOne Sandbox
  already runs.  No browser binary ships with this port; the sandbox owns
  the process and its egress IP.
- ``cloak``: launch CloakBrowser's stealth Chromium as a child process.
  Kept as a local-development fallback and as an escape hatch when the
  sandbox browser is detected.

There is no proxy rotation layer.  ``proxy`` is only honoured for local
development; in the sandbox it stays ``None`` so the sandbox egress IP is
the exit.
"""

from __future__ import annotations

import os
import random
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

import requests
from loguru import logger
from urllib3 import disable_warnings

disable_warnings()

SIGNUP_URL = "https://www.twitch.tv/signup"
TRACE_URL = "https://cloudflare.com/cdn-cgi/trace"

REGION = {
    "JP": ("Asia/Tokyo", "ja-JP", "ja-JP,ja,en-US,en"),
    "KR": ("Asia/Seoul", "ko-KR", "ko-KR,ko,en-US,en"),
    "TW": ("Asia/Taipei", "zh-TW", "zh-TW,zh,en-US,en"),
    "HK": ("Asia/Hong_Kong", "zh-HK", "zh-HK,zh,en-US,en"),
    "SG": ("Asia/Singapore", "en-SG", "en-SG,en,en-US"),
    "TH": ("Asia/Bangkok", "th-TH", "th-TH,th,en-US,en"),
    "US": ("America/New_York", "en-US", "en-US,en"),
    "CA": ("America/Toronto", "en-CA", "en-CA,en,en-US"),
    "GB": ("Europe/London", "en-GB", "en-GB,en"),
    "DE": ("Europe/Berlin", "de-DE", "de-DE,de,en-US,en"),
    "FR": ("Europe/Paris", "fr-FR", "fr-FR,fr,en-US,en"),
    "NL": ("Europe/Amsterdam", "nl-NL", "nl-NL,nl,en-US,en"),
    "RU": ("Europe/Moscow", "ru-RU", "ru-RU,ru,en-US,en"),
}
DEFAULT_REGION = ("America/New_York", "en-US", "en-US,en")

FETCH_JS = """
async (payload) => {
    const r = await fetch('https://passport.twitch.tv/protected_register', {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        credentials: 'include',
        body: JSON.stringify(payload),
    });
    const text = await r.text();
    let body = null;
    try { body = JSON.parse(text); } catch (e) {}
    return { status: r.status, body, text };
}
"""


def resolve_chrome_executable() -> Optional[str]:
    explicit = (os.getenv("CHROME_EXECUTABLE") or "").strip()
    if explicit and Path(explicit).is_file():
        return explicit
    try:
        from cloakbrowser.download import get_binary_path
        path = get_binary_path()
        if path and Path(path).is_file():
            return str(path)
    except Exception as exc:
        logger.debug(f"cloakbrowser 路径解析失败: {exc}")
    home = Path.home() / ".cloakbrowser"
    if home.is_dir():
        for directory in sorted((d for d in home.iterdir()
                                 if d.name.startswith("chromium-")), reverse=True):
            for candidate in (directory / "chrome.exe", directory / "chrome",
                              directory / "chromium" / "chrome",
                              directory / "Chromium.app" / "Contents" / "MacOS" / "Chromium"):
                if candidate.is_file():
                    return str(candidate)
    return shutil.which("chrome") or shutil.which("chromium")


def probe_region(proxy: Optional[str], timeout: int = 12) -> tuple[str, str, str]:
    proxies = {"http": proxy, "https": proxy} if proxy else {"http": None, "https": None}
    try:
        session = requests.Session()
        session.trust_env = False
        response = session.get(TRACE_URL, proxies=proxies, timeout=timeout,
                               verify=False, headers={"User-Agent": "Mozilla/5.0"})
        data = dict(line.split("=", 1) for line in response.text.splitlines() if "=" in line)
        return REGION.get((data.get("loc") or "").upper(), DEFAULT_REGION)
    except Exception:
        return DEFAULT_REGION


class ChromiumSession:
    """One browser attachment per worker; a fresh page per account."""

    def __init__(self, proxy: Optional[str] = None, headless: Optional[bool] = None,
                 country: str = "", proxy_label: str = "",
                 cdp_url: str = "", browser_mode: str = "auto",
                 relay_url: str = ""):
        self.proxy = proxy
        self.proxy_label = proxy_label
        self.country = country
        self.cdp_url = (cdp_url or "").strip()
        self.browser_mode = (browser_mode or "auto").lower()
        self.relay_url = (relay_url or "").strip()
        self._relay_session: Optional[requests.Session] = None
        self._relay_base = ""
        self.headless = (os.getenv("CHROME_HEADLESS", "1").lower()
                         not in ("0", "false", "no")) if headless is None else headless
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        self.proc = None
        self.user_data_dir: Optional[str] = None
        self.owns_browser = False
        self.alive = False
        self.sessions = 0
        self.accounts = 0

    # ---------------------------------------------------------------- open
    def open(self) -> bool:
        self.close()
        use_cdp = self.browser_mode == "cdp" or (self.browser_mode == "auto" and self.cdp_url)
        if self.browser_mode == "cdp" and not self.cdp_url:
            logger.error("browser_mode=cdp 但未提供 cdp_url")
            return False
        try:
            if use_cdp:
                return self._open_cdp()
            return self._open_local()
        except Exception as exc:
            logger.warning(f"Chromium 启动失败: {type(exc).__name__}: {exc}")
            self.close()
            return False

    def _open_cdp(self) -> bool:
        from playwright.sync_api import sync_playwright
        self.playwright = sync_playwright().start()
        deadline = time.time() + 30
        last_exc = None
        while time.time() < deadline:
            try:
                self.browser = self.playwright.chromium.connect_over_cdp(self.cdp_url)
                break
            except Exception as exc:
                last_exc = exc
                time.sleep(0.5)
        if self.browser is None:
            raise RuntimeError(f"CDP 连接失败: {last_exc}")
        self.owns_browser = False
        self.context = (self.browser.contexts[0] if self.browser.contexts
                        else self.browser.new_context())
        self.page = (self.context.pages[0] if self.context.pages
                     else self.context.new_page())
        timezone, lang, _ = self._region()
        self._set_timezone(timezone)
        self.alive = True
        self.sessions += 1
        self.accounts = 0
        logger.info(f"CDP 已连接沙箱浏览器 (cdp={self.cdp_url}, "
                    f"lang={lang}, tz={timezone})")
        return True

    def _open_local(self) -> bool:
        chrome = resolve_chrome_executable()
        if not chrome:
            logger.error("未找到 Chromium（pip install cloakbrowser 后执行 "
                         "python -m cloakbrowser install）")
            return False
        timezone, lang, accept_lang = self._region()
        port = _free_port()
        self.user_data_dir = tempfile.mkdtemp(prefix="twreg-chrome-")
        args = [
            chrome,
            f"--remote-debugging-port={port}",
            f"--user-data-dir={self.user_data_dir}",
            "--window-size=1536,864",
            f"--lang={lang}",
            f"--accept-lang={accept_lang}",
            "--disable-quic",
            "--disable-blink-features=AutomationControlled",
            "--disable-background-networking",
            "--disable-background-timer-throttling",
            "--disable-backgrounding-occluded-windows",
            "--disable-breakpad",
            "--disable-component-update",
            "--disable-default-apps",
            "--disable-dev-shm-usage",
            "--disable-features=Translate,OptimizationHints,MediaRouter,GlobalMediaControls",
            "--disable-hang-monitor",
            "--disable-ipc-flooding-protection",
            "--disable-popup-blocking",
            "--disable-prompt-on-repost",
            "--disable-renderer-backgrounding",
            "--disable-sync",
            "--force-color-profile=srgb",
            "--metrics-recording-only",
            "--no-default-browser-check",
            "--no-first-run",
            "--no-sandbox",
            "--password-store=basic",
            "--use-mock-keychain",
        ]
        # CloakBrowser's stealth args are mandatory on Linux: the binary is
        # native ELF but the fingerprint patches must be told to emulate a
        # Windows profile. The original Windows-only launcher omitted these
        # because the host already was Windows; without them Linux leaks
        # navigator.platform/fonts and Kasada rejects step1 with 5025.
        try:
            from cloakbrowser import get_default_stealth_args
            args.extend(get_default_stealth_args())
        except Exception:
            args.append(f"--fingerprint={random.randint(10000, 99999)}")
            args.append("--fingerprint-platform=windows")
        if self.proxy:
            args.append(f"--proxy-server={self.proxy}")
        if self.headless:
            args.append("--headless=new")
        args.append("about:blank")
        self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
        from playwright.sync_api import sync_playwright
        self.playwright = sync_playwright().start()
        deadline = time.time() + 30
        last_exc = None
        while time.time() < deadline:
            try:
                self.browser = self.playwright.chromium.connect_over_cdp(
                    f"http://127.0.0.1:{port}")
                break
            except Exception as exc:
                last_exc = exc
                time.sleep(0.5)
        if self.browser is None:
            raise RuntimeError(f"CDP 连接失败: {last_exc}")
        self.owns_browser = True
        self.context = (self.browser.contexts[0] if self.browser.contexts
                        else self.browser.new_context())
        self.page = (self.context.pages[0] if self.context.pages
                     else self.context.new_page())
        self._set_timezone(timezone)
        self.alive = True
        self.sessions += 1
        self.accounts = 0
        proxy_desc = self.proxy_label or self.proxy or "直连（沙箱出口 IP）"
        logger.info(f"Chromium 已启动 (proxy={proxy_desc}, "
                    f"lang={lang}, tz={timezone}, headless={self.headless})")
        return True

    def _region(self) -> tuple[str, str, str]:
        if self.country:
            return REGION.get(self.country.upper(), DEFAULT_REGION)
        return probe_region(self.proxy)

    def _set_timezone(self, timezone: str) -> None:
        try:
            cdp = self.context.new_cdp_session(self.page)
            cdp.send("Emulation.setTimezoneOverride", {"timezoneId": timezone})
        except Exception as exc:
            logger.debug(f"时区覆盖失败(忽略): {exc}")

    # --------------------------------------------------------------- pages
    def new_page(self):
        try:
            if self.page is not None and not self.page.is_closed():
                self.page.close()
        except Exception:
            pass
        self.page = self.context.new_page()
        self._install_relay()
        return self.page

    def _prepare_relay(self) -> None:
        if not self.relay_url:
            return
        if self._relay_session is not None:
            return
        parsed = urlsplit(self.relay_url)
        self._relay_base = f"{parsed.scheme}://{parsed.netloc}/relay"
        session = requests.Session()
        session.trust_env = False
        session.verify = False
        try:
            # The Makers preset domain sets eo_token/eo_time cookies and then
            # redirects; keep the session so /relay requests are authorized.
            session.get(self.relay_url, timeout=30, verify=False,
                        allow_redirects=True)
        except Exception as exc:
            logger.warning(f"relay 授权 cookie 获取失败: {type(exc).__name__}: {exc}")
        self._relay_session = session

    def _install_relay(self) -> None:
        if not self.relay_url or self.page is None:
            return
        self._prepare_relay()

        def handle(route):
            request = route.request
            # Images/fonts/media are not worth relaying: text corruption and
            # size limits. The HTML, scripts, XHR and the register POST are.
            if request.resource_type in ("image", "font", "media"):
                route.continue_()
                return
            try:
                headers = dict(request.all_headers())
            except Exception:
                headers = dict(request.headers)
            try:
                cookies = self.context.cookies(request.url)
                if cookies:
                    headers["cookie"] = "; ".join(
                        f"{c['name']}={c['value']}" for c in cookies)
            except Exception:
                pass
            kpsdk = {k: len(v) for k, v in headers.items()
                     if k.lower().startswith("x-kpsdk")}
            envelope = {
                "url": request.url,
                "method": request.method,
                "headers": headers,
                "body": request.post_data,
            }
            try:
                resp = self._relay_session.post(
                    self._relay_base, json=envelope, timeout=90, verify=False)
                data = resp.json()
                status = int(data.get("status") or 502)
                body = str(data.get("body") or "")
                upstream_headers = {str(k).lower(): str(v)
                                    for k, v in (data.get("headers") or {}).items()}
                keep = {}
                for key in ("content-type", "location",
                            "access-control-allow-origin",
                            "access-control-allow-credentials",
                            "access-control-expose-headers",
                            "cache-control"):
                    if key in upstream_headers:
                        keep[key] = upstream_headers[key]
                for raw_cookie in data.get("setCookies") or []:
                    self._apply_set_cookie(raw_cookie, request.url)
                if request.resource_type in ("document", "xhr", "fetch", "script"):
                    logger.info(f"relay {request.resource_type} {request.method} "
                                f"{request.url[:80]} -> {status} ({len(body)}B) "
                                f"kpsdk={kpsdk}")
                route.fulfill(
                    status=status,
                    headers=keep,
                    body=None if status in (204, 304) else body,
                )
            except Exception as exc:
                logger.warning(f"relay 转发失败: {type(exc).__name__}: {exc}")
                try:
                    route.abort()
                except Exception:
                    pass

        for pattern in ("https://www.twitch.tv/**",
                        "https://passport.twitch.tv/**",
                        "https://gql.twitch.tv/**"):
            self.page.route(pattern, handle)

    def _apply_set_cookie(self, raw: str, request_url: str) -> None:
        try:
            parts = [p.strip() for p in str(raw).split(";")]
            if not parts or "=" not in parts[0]:
                return
            name, value = parts[0].split("=", 1)
            attrs: dict = {}
            for part in parts[1:]:
                if "=" in part:
                    key, val = part.split("=", 1)
                    attrs[key.strip().lower()] = val.strip()
                else:
                    attrs[part.strip().lower()] = ""
            host = urlsplit(request_url).hostname or ""
            domain = attrs.get("domain") or host
            if domain and not domain.startswith("."):
                domain = "." + domain
            cookie = {"name": name, "value": value,
                      "path": attrs.get("path", "/")}
            if domain:
                cookie["domain"] = domain
            if "max-age" in attrs:
                try:
                    cookie["expires"] = time.time() + int(attrs["max-age"])
                except ValueError:
                    pass
            if "secure" in attrs:
                cookie["secure"] = True
            if "httponly" in attrs:
                cookie["httpOnly"] = True
            same = attrs.get("samesite", "")
            if same in ("Strict", "Lax", "None"):
                cookie["sameSite"] = same
            self.context.add_cookies([cookie])
        except Exception as exc:
            logger.debug(f"relay set-cookie 忽略: {exc}")

    def open_signup(self, timeout: float = 45.0) -> bool:
        try:
            self.page.goto(SIGNUP_URL, wait_until="domcontentloaded", timeout=60000)
        except Exception as exc:
            logger.warning(f"打开 signup 失败: {exc}")
            return False
        deadline = time.time() + timeout
        moves = 0
        while time.time() < deadline:
            try:
                self.page.mouse.move(300 + (moves * 37) % 500,
                                     220 + (moves * 53) % 300,
                                     steps=3)
                if moves % 3 == 0:
                    self.page.mouse.wheel(0, 120 if moves % 2 == 0 else -120)
                if moves % 7 == 3:
                    self.page.mouse.click(300 + (moves * 29) % 400,
                                          260 + (moves * 31) % 240, delay=40)
            except Exception:
                pass
            moves += 1
            try:
                if self.page.evaluate(
                        "() => !!(window.KPSDK && window.KPSDK.isReady && "
                        "window.KPSDK.isReady())") is True:
                    time.sleep(1.0)
                    return True
            except Exception:
                pass
            time.sleep(0.5)
        logger.warning("Chromium KPSDK 未就绪")
        return False

    def register(self, payload: dict, timeout: float = 60.0) -> dict:
        if not self.alive or self.page is None:
            return {"status": 0, "body": {"error": "session_dead"}, "text": ""}
        try:
            return self.page.evaluate(FETCH_JS, payload)
        except Exception as exc:
            return {"status": 0, "body": {"error": str(exc)}, "text": ""}

    # --------------------------------------------------------------- close
    def close(self) -> None:
        self.alive = False
        if self.owns_browser:
            for closer in (
                lambda: self.browser.close() if self.browser else None,
                lambda: self.playwright.stop() if self.playwright else None,
            ):
                try:
                    closer()
                except Exception:
                    pass
        else:
            # CDP mode: the sandbox owns the browser process. Drop the
            # connection only; leave the browser alive for the next session.
            try:
                if self.playwright:
                    self.playwright.stop()
            except Exception:
                pass
        self.browser = None
        self.playwright = None
        self.context = None
        self.page = None
        if self.proc is not None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=5)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.proc = None
        if self.user_data_dir:
            shutil.rmtree(self.user_data_dir, ignore_errors=True)
            self.user_data_dir = None
        self.owns_browser = False


def _free_port() -> int:
    import socket
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port
