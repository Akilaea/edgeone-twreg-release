"""WARP egress pool for Linux runners (usque / Cloudflare MASQUE).

Ported from the Windows `warp_control.py` / `manager.py` design:
  * each job registers its own WARP identity -> its own egress IP
  * endpoints are drawn from a pool, randomly by default
  * a stuck egress can be rotated: new identity -> new endpoint -> same local port

No TUN and no root: usque runs the MASQUE tunnel in userspace and exposes an
HTTP CONNECT proxy on localhost. `--http2` switches to MASQUE over HTTP/2
(TCP/443), which is the fallback when the runner blocks UDP/QUIC.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
import signal
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional

import requests
from loguru import logger
from urllib3 import disable_warnings

disable_warnings()

# QUIC / WireGuard-style UDP endpoints (default transport).
DEFAULT_ENDPOINTS = [
    "162.159.192.1:2408", "162.159.193.1:2408", "162.159.195.1:2408", "162.159.204.1:2408",
    "188.114.96.1:2408", "188.114.97.1:2408", "188.114.98.1:2408", "188.114.99.1:2408",
    "162.159.192.1:500", "162.159.193.1:500", "188.114.96.1:500", "188.114.99.1:500",
]
# MASQUE over HTTP/2 (TCP/443). usque's documented default is the only stable one.
DEFAULT_H2_ENDPOINTS = ["162.159.198.2"]

USQUE_VERSION = "4.2.1"
USQUE_URL = ("https://github.com/Diniboy1123/usque/releases/download/"
             f"v{USQUE_VERSION}/usque_{USQUE_VERSION}_linux_amd64.zip")
TRACE_URL = "https://cloudflare.com/cdn-cgi/trace"
MIN_GLIBC = (2, 39)


# ---------------------------------------------------------------- endpoint pool
def parse_endpoints(raw: str) -> list[str]:
    """`US=1.2.3.4:2408,JP=1.2.3.5:2408` -> list, labels kept for logging."""
    return [item.strip() for item in (raw or "").replace(";", ",").split(",") if item.strip()]


def endpoint_host(entry: str) -> str:
    return entry.split("=", 1)[1] if "=" in entry else entry


def endpoint_ip(entry: str) -> str:
    """Strip country label, port and IPv6 brackets: `US=1.2.3.4:2408` -> `1.2.3.4`."""
    host = endpoint_host(entry).strip()
    if host.startswith("[") and "]" in host:
        return host[1:host.index("]")]
    if host.count(":") == 1:
        return host.split(":", 1)[0]
    return host


def pick_endpoints(pool: list[str], n: int = 1, rng: Optional[random.Random] = None) -> list[str]:
    pool = [item for item in pool if item]
    if not pool:
        return []
    n = min(n, len(pool))
    chooser = rng or random
    if n == len(pool):
        result = list(pool)
        chooser.shuffle(result)
        return result
    return chooser.sample(pool, n)


def proxy_url(host: str = "127.0.0.1", port: int = 25345) -> str:
    return f"http://{host}:{port}"


# ------------------------------------------------------------- usque config
def build_usque_config(config: dict, endpoint: str, transport: str = "quic") -> dict:
    """Return a copy of the usque config with the tunnel endpoint overridden."""
    ip = endpoint_ip(endpoint)
    try:
        import ipaddress
        ipaddress.ip_address(ip)
    except ValueError as exc:
        raise ValueError(f"无效 WARP 端点: {endpoint!r}") from exc
    updated = dict(config)
    if transport == "http2":
        updated["endpoint_h2_v4"] = ip
    else:
        updated["endpoint_v4"] = ip
    return updated


# ------------------------------------------------------------------- egress
def _download(url: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"下载 {url.rsplit('/', 1)[-1]} → {target}")
    request = urllib.request.Request(url, headers={"User-Agent": "twreg-warp-pool"})
    with urllib.request.urlopen(request, timeout=120) as response:
        target.write_bytes(response.read())


def _download_usque_zip(url: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        archive = Path(tmp) / "usque.zip"
        _download(url, archive)
        with zipfile.ZipFile(archive) as zf:
            member = next((m for m in zf.namelist()
                           if m.rsplit("/", 1)[-1] == "usque"), None)
            if not member:
                raise RuntimeError("usque 压缩包内未找到可执行文件")
            target.write_bytes(zf.read(member))


def check_glibc() -> None:
    if sys.platform != "linux":
        return
    try:
        version = os.confstr("CS_GNU_LIBC_VERSION")  # e.g. "glibc 2.39"
        numbers = tuple(int(x) for x in re.findall(r"\d+", version or "")[:2])
    except Exception:
        return
    if numbers and numbers < MIN_GLIBC:
        raise RuntimeError(
            f"glibc {version} 过旧；ruyijs Linux wheel 需要 >= {MIN_GLIBC[0]}.{MIN_GLIBC[1]}"
            f"（使用 ubuntu-24.04 或更新）")


class WarpEgress:
    """Usque MASQUE egress with an endpoint pool and identity rotation."""

    def __init__(self, work_dir: Path = Path(".warp"), bin_dir: Optional[Path] = None,
                 endpoints: Optional[list[str]] = None, transport: str = "quic",
                 http_port: int = 25345, attempts: int = 4, ready_timeout: float = 45.0):
        self.work_dir = Path(work_dir).expanduser().resolve()
        self.bin_dir = (Path(bin_dir).expanduser().resolve()
                        if bin_dir else self.work_dir / "bin")
        if transport not in ("quic", "http2"):
            transport = "quic"
        self.transport = transport
        if endpoints:
            self.endpoints = list(endpoints)
        else:
            self.endpoints = list(DEFAULT_H2_ENDPOINTS if transport == "http2"
                                  else DEFAULT_ENDPOINTS)
        self.http_port = http_port
        self.attempts = attempts
        self.ready_timeout = ready_timeout
        self.process: Optional[subprocess.Popen] = None
        self.endpoint: Optional[str] = None
        self.trace_info: dict = {}
        self.last_probe_error: str = ""
        self._rotate_lock = threading.Lock()
        self._last_rotate = 0.0

    # -- binary / identity
    @property
    def usque(self) -> Path:
        return Path(os.getenv("USQUE_BIN") or (self.bin_dir / "usque"))

    def ensure_binary(self) -> None:
        if not self.usque.is_file():
            _download_usque_zip(USQUE_URL, self.usque)
            self.usque.chmod(0o755)

    @property
    def _config_path(self) -> Path:
        return self.work_dir / "config.json"

    def _run_usque(self, *args: str) -> None:
        cmd = [str(self.usque), "-c", str(self._config_path), *args]
        result = subprocess.run(cmd, cwd=self.work_dir, capture_output=True,
                                text=True, timeout=180)
        if result.returncode != 0:
            raise RuntimeError(f"usque {' '.join(args)} 失败: "
                               f"{(result.stderr or result.stdout)[-500:]}")

    def register_identity(self) -> None:
        self.work_dir.mkdir(parents=True, exist_ok=True)
        old = Path(str(self._config_path) + ".old")
        for path in (self._config_path, old):
            if path.exists():
                try:
                    path.unlink()
                except Exception:
                    pass
        self._run_usque("register", "--accept-tos", "-n", "twreg")
        if not self._config_path.is_file():
            raise RuntimeError("usque register 未生成 config.json")
        logger.success("WARP 身份已注册")

    def _save_trace(self, data: dict) -> None:
        path = self.work_dir / "egress.json"
        try:
            path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    # -- process control
    def _pid_path(self) -> Path:
        return self.work_dir / "usque.pid"

    def _kill_pid(self, pid: int) -> None:
        for sig, wait in ((signal.SIGTERM, 2.0), (signal.SIGKILL, 1.0)):
            try:
                os.kill(pid, sig)
            except ProcessLookupError:
                return
            except Exception:
                return
            time.sleep(wait)

    def down(self) -> None:
        if self.process is not None:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None
        pid_path = self._pid_path()
        if pid_path.is_file():
            try:
                self._kill_pid(int(pid_path.read_text(encoding="utf-8").strip()))
            except Exception:
                pass
            try:
                pid_path.unlink()
            except Exception:
                pass

    def _write_config(self, endpoint: str) -> None:
        config = json.loads(self._config_path.read_text(encoding="utf-8"))
        updated = build_usque_config(config, endpoint, self.transport)
        self._config_path.write_text(json.dumps(updated, indent=2), encoding="utf-8")

    def _start_process(self, endpoint: str) -> None:
        self._write_config(endpoint)
        log_file = open(self.work_dir / "usque.log", "a", encoding="utf-8")
        cmd = [str(self.usque), "-c", str(self._config_path), "http-proxy",
               "-b", "127.0.0.1", "-p", str(self.http_port), "-l", "--system-dns"]
        if self.transport == "http2":
            cmd.append("--http2")
        self.process = subprocess.Popen(cmd, stdout=log_file, stderr=subprocess.STDOUT,
                                        start_new_session=True)
        self._pid_path().write_text(str(self.process.pid), encoding="utf-8")
        self.endpoint = endpoint
        logger.info(f"usque 启动 pid={self.process.pid} "
                    f"transport={self.transport} endpoint={endpoint}")

    def _probe_get(self, url: str, timeout: float):
        session = requests.Session()
        session.trust_env = False
        session.verify = False
        proxies = {"http": proxy_url("127.0.0.1", self.http_port),
                   "https": proxy_url("127.0.0.1", self.http_port)}
        try:
            return session.get(url, proxies=proxies, timeout=timeout,
                               headers={"User-Agent": "Mozilla/5.0"})
        finally:
            session.close()

    def _trace(self) -> Optional[dict]:
        try:
            response = self._probe_get(TRACE_URL, 12)
            if response.status_code != 200:
                self.last_probe_error = f"HTTP {response.status_code}"
                return None
            self.last_probe_error = ""
            return dict(line.split("=", 1) for line in response.text.strip().splitlines()
                        if "=" in line)
        except Exception as exc:
            self.last_probe_error = f"{type(exc).__name__}: {exc}"[:200]
            return None

    def wait_ready(self) -> Optional[dict]:
        deadline = time.time() + self.ready_timeout
        next_report = time.time() + 8
        while time.time() < deadline:
            if self.process is not None and self.process.poll() is not None:
                logger.warning(f"usque 已退出 code={self.process.returncode}")
                self._dump_log(15)
                return None
            info = self._trace()
            if info and info.get("ip"):
                return info
            if time.time() >= next_report:
                logger.warning(f"  代理探针未通: {self.last_probe_error or 'no response'}")
                next_report = time.time() + 8
            time.sleep(1.0)
        return None

    def _dump_log(self, lines: int = 20) -> None:
        path = self.work_dir / "usque.log"
        try:
            tail = path.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:]
            for line in tail:
                logger.warning(f"  usque: {line}")
        except Exception:
            pass

    def _twitch_ok(self) -> Optional[int]:
        try:
            response = self._probe_get("https://www.twitch.tv/", 12)
            return response.status_code
        except Exception as exc:
            logger.warning(f"Twitch 探测失败: {type(exc).__name__}")
            return None

    # -- public
    @property
    def proxy(self) -> str:
        return proxy_url("127.0.0.1", self.http_port)

    def up(self) -> str:
        # usque is a static Go binary; the ruyijs glibc gate does not apply.
        self.ensure_binary()
        if not self._config_path.is_file():
            self.register_identity()

        ordered = pick_endpoints(self.endpoints, len(self.endpoints))
        candidates = ordered[:max(1, self.attempts)]
        for endpoint in candidates:
            self.down()
            logger.info(f"尝试 WARP 端点: {endpoint} ({self.transport})")
            try:
                self._start_process(endpoint)
            except Exception as exc:
                logger.warning(f"启动失败: {exc}")
                continue
            info = self.wait_ready()
            if not info:
                logger.warning(f"端点 {endpoint} 未就绪，换下一个")
                self.down()
                continue
            twitch = self._twitch_ok()
            self.trace_info = {**info, "endpoint": endpoint,
                               "transport": self.transport, "twitch": twitch}
            self._save_trace(self.trace_info)
            logger.success(
                f"WARP 就绪: endpoint={endpoint} exit={info.get('ip')} "
                f"colo={info.get('colo')} warp={info.get('warp')} twitch={twitch}")
            return self.proxy
        raise RuntimeError(f"WARP 端点池全部失败（尝试 {len(candidates)} 个）")

    def rotate(self, min_interval: float = 30.0) -> str:
        """New identity + new endpoint, same local port.

        Serialized: with several workers sharing one egress, only the first
        caller rotates; others reuse the fresh tunnel instead of churning it.
        """
        with self._rotate_lock:
            if time.time() - self._last_rotate < min_interval:
                logger.info("WARP 刚重置过，复用当前出口")
                return self.proxy
            logger.warning("WARP 重置：关闭当前出口，换身份与端点 ...")
            self.down()
            self.register_identity()
            url = self.up()
            self._last_rotate = time.time()
            return url


# --------------------------------------------------------------------- CLI
def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m twreg.warp")
    parser.add_argument("--up", action="store_true", help="启动 WARP 出口")
    parser.add_argument("--down", action="store_true", help="停止 WARP 出口")
    parser.add_argument("--probe", action="store_true", help="只打印当前出口 trace")
    parser.add_argument("--rotate", action="store_true",
                        help="换 WARP 身份与端点，保持本地端口")
    parser.add_argument("--http2", action="store_true",
                        help="MASQUE over HTTP/2 (TCP/443)；UDP 被封时使用")
    parser.add_argument("--work-dir", default=os.getenv("WARP_WORK_DIR", ".warp"))
    parser.add_argument("--endpoints", default=os.getenv("WARP_ENDPOINTS", ""))
    parser.add_argument("--env-out", default="", help="把 export 行写入文件")
    args = parser.parse_args(argv)

    transport = "http2" if (args.http2 or os.getenv("WARP_HTTP2", "") not in ("", "0")) else "quic"
    pool = parse_endpoints(args.endpoints)
    egress = WarpEgress(work_dir=Path(args.work_dir), endpoints=pool or None,
                        transport=transport)

    if args.down:
        egress.down()
        print("warp down")
        return 0
    if args.probe:
        info = egress._trace()
        print(info or "unreachable")
        return 0 if info else 1
    if args.rotate:
        try:
            url = egress.rotate()
        except Exception as exc:
            logger.error(f"WARP 重置失败: {exc}")
            return 1
        print(url)
        return 0

    try:
        url = egress.up()
    except Exception as exc:
        logger.error(f"WARP 启动失败: {exc}")
        return 1
    lines = [f"export PROXY_SERVER={url}", f"export WARP_HTTP_PROXY={url}",
             f"export WARP_TRANSPORT={transport}"]
    if args.env_out:
        Path(args.env_out).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
