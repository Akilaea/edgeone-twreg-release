"""Password generation and Twitch cookie set construction."""

from __future__ import annotations

import json
import secrets
import string


def random_password(length: int = 16) -> str:
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    symbols = "!@#$%^&*"
    must = [
        secrets.choice(lower),
        secrets.choice(upper),
        secrets.choice(digits),
        secrets.choice(symbols),
    ]
    pool = lower + upper + digits + symbols
    rest = [secrets.choice(pool) for _ in range(max(length - len(must), 4))]
    pwd = must + rest
    for i in range(len(pwd) - 1, 0, -1):
        j = secrets.randbelow(i + 1)
        pwd[i], pwd[j] = pwd[j], pwd[i]
    return "".join(pwd)


def random_hex(n_bytes: int = 16) -> str:
    return secrets.token_hex(n_bytes)


def build_twilight_user(access_token: str, user_id, username: str) -> str:
    return json.dumps({
        "authToken": access_token,
        "id": int(user_id),
        "login": username,
        "displayName": username,
        "roles": {"isStaff": False},
        "version": 2,
    }, separators=(",", ":"))


def build_cookies(access_token: str, user_id, username: str, country_code: str = "HK") -> list[dict]:
    """Full 8-cookie set for .twitch.tv, ready for Playwright add_cookies / Cookie-Editor."""
    device_id = random_hex(16)
    values = [
        ("auth-token", access_token),
        ("twilight-user", build_twilight_user(access_token, user_id, username)),
        ("api_token", f"twilight.{random_hex(16)}"),
        ("unique_id", device_id),
        ("unique_id_durable", device_id),
        ("server_session_id", random_hex(16)),
        ("twitch.lohp.countryCode", country_code),
        ("experiment_overrides", json.dumps({"experiments": {}, "disabled": []}, separators=(",", ":"))),
    ]
    return [
        {
            "name": name,
            "value": value,
            "domain": ".twitch.tv",
            "path": "/",
            "secure": True,
            "httpOnly": name == "auth-token",
        }
        for name, value in values
    ]


def cookies_for_export(cookies: list[dict]) -> str:
    return json.dumps(cookies, ensure_ascii=False, separators=(",", ":"))
