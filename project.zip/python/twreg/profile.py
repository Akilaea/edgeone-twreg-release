# profile_gen.py — 随机注册资料（用户名 / 邮箱前缀 / 生日 / 密码）
import random
import string

_WORDS = [
    "alex", "max", "sam", "luna", "nova", "kite", "ray", "milo", "zoe", "kai",
    "iris", "leo", "nina", "owen", "ruby", "theo", "wren", "axel", "luca", "maya",
    "noah", "ella", "finn", "jade", "cloud", "stone", "river", "pixel", "otter",
    "falcon", "ember", "maple", "tiger", "comet", "willow", "raven", "cedar",
    "lynx", "harbor", "meadow", "delta", "orbit", "nimbus", "quartz", "violet",
]


def random_username() -> str:
    """Twitch 用户名规则：4-25 位，字母/数字/下划线，字母开头，不以 _ 结尾。"""
    style = random.randrange(5)
    if style == 0:
        name = f"{random.choice(_WORDS)}{random.choice(_WORDS)}{random.randint(10000, 999999)}"
    elif style == 1:
        name = f"{random.choice(_WORDS)}_{random.choice(_WORDS)}{random.randint(1000, 99999)}"
    elif style == 2:
        name = "".join(random.choices(string.ascii_lowercase, k=random.randint(6, 9))) + str(
            random.randint(100, 9999)
        )
    elif style == 3:
        name = f"{random.choice(_WORDS)}{random.randint(100000, 9999999)}"
    else:
        name = f"{random.choice(_WORDS)}_{random.randint(10000, 999999)}"
    return name[:25]


def random_email_prefix() -> str:
    """邮箱本地部分：6-10 位小写字母+数字，字母开头。"""
    head = random.choice(string.ascii_lowercase)
    tail = "".join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(5, 9)))
    return head + tail


def random_birthday() -> dict:
    """生日：18-38 岁之间，日取 1-28（所有月份都合法）。"""
    year = random.randint(1988, 2007)
    return {
        "day": random.randint(1, 28),
        "month": random.randint(1, 12),
        "year": year,
        "isOver18": True,
    }


def random_password_length() -> int:
    return random.randint(13, 18)
