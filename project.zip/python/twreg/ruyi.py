"""ruyijs (real Firefox engine) session for the EdgeOne Makers port.

Ported from xbox-cn/twreg_ruyijs `cloady-direct` (ruyi_engine.py).  This is the
Linux engine that the reference branch runs with usque WARP; it needs a
fontconfig with DejaVu fonts, otherwise ruyijs raises
`canvas text measurement failed`.

One Context = one Firefox device session.  ruyijs has no window/rendering, so
it is much lighter than Chromium and does not leak a Linux Chrome headless
surface.
"""

from __future__ import annotations

import json
import os
import secrets
import time
import urllib.request
from pathlib import Path
from typing import Optional

from loguru import logger

try:
    from ruyijs import Context, JSError
except Exception:  # pragma: no cover - only imported when engine=ruyi
    Context = None  # type: ignore
    JSError = Exception  # type: ignore

PJS_URL = ("https://k.twitchcdn.net/149e9513-01fa-4fb0-aad4-566afd725d1b/"
           "2d206a39-8ed7-437e-a3be-862e0f06eea3/p.js")
BASE = PJS_URL.rsplit("/", 1)[0]
MFC_URL = BASE + "/mfc"
SIGNUP_URL = "https://www.twitch.tv/signup"
REGISTER_URL = "https://passport.twitch.tv/protected_register"

_CORS = [("access-control-allow-origin", "*"),
         ("access-control-allow-methods", "GET, POST, OPTIONS"),
         ("access-control-allow-headers",
          "x-kpsdk-h, x-kpsdk-v, content-type, x-kpsdk-ct, x-kpsdk-cd"),
         ("access-control-max-age", "600"),
         ("content-type", "text/plain")]

_REG_JS = ("globalThis.__reg=null;fetch('%s',{method:'POST',"
           "headers:{'Content-Type':'text/plain;charset=UTF-8'},credentials:'include',"
           "body:JSON.stringify(%%s)})"
           ".then(r=>r.text().then(t=>__reg=JSON.stringify({status:r.status,body:t})))"
           ".catch(e=>__reg=JSON.stringify({status:0,body:'FETCHERR '+String(e)}));"
           % REGISTER_URL)

_DEFAULT_ENDPOINTS = [
    {"protocol": "https", "method": "POST", "domain": "gql.twitch.tv", "path": "/integrity"},
    {"protocol": "https", "method": "POST", "domain": "passport.twitch.tv", "path": "/integrity"},
    {"protocol": "https", "method": "POST", "domain": "passport.twitch.tv",
     "path": "/protected_register"},
    {"protocol": "https", "method": "POST", "domain": "passport.twitch.tv",
     "path": "/protected_login"},
]


def load_endpoints() -> list:
    try:
        return json.loads((Path.cwd() / "configure.json").read_text(encoding="utf-8"))
    except Exception:
        return _DEFAULT_ENDPOINTS


def shell_html(pjs_url: str, endpoints: list) -> str:
    ep = json.dumps(endpoints, separators=(",", ":"))
    return ('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Twitch</title></head><body>'
            '<script>(function(){'
            "window.__kperr=[];window.addEventListener('error',e=>__kperr.push(String(e.message||'').slice(0,200)));"
            "document.addEventListener('kpsdk-load',function(){try{window.KPSDK.configure(" + ep +
            ");}catch(e){window.__kperr.push('cfg:'+String(e));}});"
            "var s=document.createElement('script');s.src='" + pjs_url + "';document.body.appendChild(s);"
            '})();</script></body></html>')


class RuyiSession:
    """One ruyijs Context = one Twitch device session."""

    def __init__(self, proxy: Optional[str] = None,
                 timezone: str = "Asia/Shanghai", locale: str = "zh-CN",
                 country: str = "HK", screen=(1920, 1080), viewport=(1536, 864),
                 cache_dir: Optional[Path] = None,
                 firefox_version: Optional[str] = None):
        self.proxy = proxy
        self.timezone = timezone
        self.locale = locale
        self.country = country
        self.screen = screen
        self.viewport = viewport
        self.cache_dir = Path(cache_dir or (Path.cwd() / "cache"))
        raw_version = (firefox_version if firefox_version is not None
                       else os.getenv("RUYIJS_FIREFOX", "159")).strip()
        self.firefox_version = (None if raw_version.lower() in
                                ("", "0", "auto", "none") else raw_version)
        self.ctx = None
        self.alive = False
        self.sessions = 0
        self.accounts = 0
        self.created_at = 0.0
        self.pjs_bytes = self._load_pjs()

    # ---------- p.js cache ----------
    def _load_pjs(self):
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        for path in sorted(self.cache_dir.glob("pjs_*.js"),
                           key=lambda p: -p.stat().st_mtime):
            try:
                if time.time() - path.stat().st_mtime < 12 * 3600:
                    return path.read_bytes()
            except Exception:
                pass
        try:
            request = urllib.request.Request(PJS_URL, headers={"User-Agent": "Mozilla/5.0"})
            if self.proxy:
                opener = urllib.request.build_opener(
                    urllib.request.ProxyHandler({"http": self.proxy, "https": self.proxy}))
            else:
                opener = urllib.request.build_opener()
            body = opener.open(request, timeout=30).read()
            out = self.cache_dir / f"pjs_{int(time.time())}.js"
            out.write_bytes(body)
            logger.info(f"p.js 已下载并缓存: {len(body)}B → {out.name}")
            return body
        except Exception as exc:
            logger.error(f"p.js 下载失败: {exc}")
            return None

    # ---------- egress country ----------
    def _egress_country(self) -> str:
        """Match twitch.lohp.countryCode to the actual egress location.

        A HK cookie on a SG datacenter IP is a cross-field inconsistency that
        newer Kasada builds can reject with 5025.  ``auto`` reads Cloudflare's
        trace through the same proxy as the browser.
        """
        configured = (self.country or "").strip().upper()
        if configured and configured not in ("AUTO", "-"):
            return configured
        try:
            request = urllib.request.Request(
                "https://cloudflare.com/cdn-cgi/trace",
                headers={"User-Agent": "Mozilla/5.0"})
            if self.proxy:
                opener = urllib.request.build_opener(
                    urllib.request.ProxyHandler({"http": self.proxy, "https": self.proxy}))
            else:
                opener = urllib.request.build_opener()
            text = opener.open(request, timeout=15).read().decode("utf-8", "replace")
            for line in text.splitlines():
                if line.startswith("loc="):
                    loc = line.split("=", 1)[1].strip().upper()
                    if loc:
                        logger.info(f"ruyi 出口国家: {loc}")
                        return loc
        except Exception as exc:
            logger.warning(f"出口国家探测失败: {type(exc).__name__}: {exc}")
        return "HK"

    # ---------- fingerprint ----------
    def _fingerprint(self) -> dict:
        """Keep the Linux engine's observable profile consistent with Windows.

        ruyijs 0.4.3 reports a Windows user agent on Linux, but navigator
        platform/oscpu and WebGL still risk exposing the host. Kasada binds
        its token to the browser surface, so set one coherent profile before
        the page loads.
        """
        version = self.firefox_version or "160"
        ua = (f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{version}.0) "
              f"Gecko/20100101 Firefox/{version}.0")
        return {
            "navigator": {
                "userAgent": ua,
                "platform": "Win32",
                "appCodeName": "Mozilla",
                "appName": "Netscape",
                "appVersion": "5.0 (Windows)",
                "product": "Gecko",
                "productSub": "20100101",
                "vendor": "",
                "vendorSub": "",
                "language": "en-US",
                "languages": ["en-US", "en"],
                "hardwareConcurrency": 8,
                "maxTouchPoints": 0,
                "cookieEnabled": True,
                "webdriver": False,
                "oscpu": "Windows NT 10.0; Win64; x64",
                "buildID": "20181001000000",
                "doNotTrack": "unspecified",
                "pdfViewerEnabled": True,
                "onLine": True,
                "globalPrivacyControl": False,
            },
            "screen": {"width": self.screen[0], "height": self.screen[1],
                       "availWidth": self.screen[0],
                       "availHeight": self.screen[1] - 40,
                       "availLeft": 0, "availTop": 0,
                       "colorDepth": 24, "pixelDepth": 24},
            "viewport": {"width": self.viewport[0], "height": self.viewport[1],
                         "devicePixelRatio": 1.0},
            "locale": {"timezone": self.timezone},
        }

    # ---------- lifecycle ----------
    def open(self, ready_timeout: float = 45.0) -> bool:
        self.close()
        if Context is None:
            logger.error("ruyijs 未安装（requirements 需要 ruyijs>=0.4.3）")
            return False
        if not self.pjs_bytes:
            return False
        env = {"screen": {"width": self.screen[0], "height": self.screen[1],
                          "availWidth": self.screen[0], "availHeight": self.screen[1] - 40},
               "viewport": {"width": self.viewport[0], "height": self.viewport[1]},
               "locale": {"timezone": self.timezone}}
        try:
            context_kwargs = {"timeout": 90, "proxy": self.proxy,
                              "environment": env}
            if self.firefox_version:
                context_kwargs["tls"] = self.firefox_version
            try:
                self.ctx = Context(**context_kwargs)
            except TypeError:
                # Older ruyijs without the tls parameter.
                self.ctx = Context(timeout=90, proxy=self.proxy,
                                   environment=env)
            profile = self._fingerprint()
            try:
                self.ctx.configure_fingerprint(profile)
            except BaseException as exc:
                logger.warning(f"fingerprint 完整配置失败: {type(exc).__name__}: {exc}")
                profile.pop("webgl", None)
                self.ctx.configure_fingerprint(profile)
            self.ctx.put_resource(PJS_URL, self.pjs_bytes,
                                  headers=[("content-type", "application/javascript; charset=utf-8")])
            # /mfc CORS preflight never returns in ruyijs; stub it locally.
            self.ctx.put_resource(MFC_URL, b"", headers=_CORS)
            self.ctx.put_resource(MFC_URL + "?_=1", b"", headers=_CORS)
            self.ctx.load_page(SIGNUP_URL, shell_html(PJS_URL, load_endpoints()))
            uid = secrets.token_hex(16)
            country = self._egress_country()
            for name, value in (("server_session_id", secrets.token_hex(16)),
                                ("unique_id", uid), ("unique_id_durable", uid),
                                ("twitch.lohp.countryCode", country)):
                self.ctx.eval("document.cookie=%s" % json.dumps(
                    f"{name}={value}; path=/; domain=.twitch.tv"))
        except BaseException as exc:
            logger.warning(f"ruyijs Context 创建失败: {type(exc).__name__}: {exc}")
            self.close()
            return False
        self.sessions += 1
        self.accounts = 0
        self.created_at = time.time()
        self.alive = True
        ok = self._wait_ready(ready_timeout)
        if not ok:
            logger.warning("KPSDK 未就绪（p.js 挑战失败）")
            self.close()
        return ok

    def _wait_ready(self, timeout: float) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                self.ctx.advance(250)
            except JSError:
                pass
            except BaseException as exc:
                logger.warning(f"ruyijs 运行时异常: {type(exc).__name__}")
                self.alive = False
                return False
            try:
                if self.ctx.eval(
                        "!!(window.KPSDK&&KPSDK.isReady&&KPSDK.isReady())") is True:
                    return True
            except JSError:
                pass
        return False

    def new_page(self):
        # API compatibility with the Chromium session; ruyijs has no pages.
        return None

    def close(self):
        self.alive = False
        ctx, self.ctx = self.ctx, None
        if ctx is not None:
            try:
                ctx.close()
            except BaseException:
                pass

    # ---------- in-page registration fetch ----------
    def register(self, payload: dict, timeout: float = 60.0) -> dict:
        if not self.alive or self.ctx is None:
            return {"status": 0, "body": "session_dead"}
        try:
            self.ctx.eval(_REG_JS % json.dumps(payload))
        except JSError as exc:
            return {"status": 0, "body": f"eval_error: {exc}"[:200]}
        except BaseException as exc:
            self.alive = False
            return {"status": 0, "body": f"runtime_error: {type(exc).__name__}"}
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                self.ctx.advance(250)
            except JSError:
                pass
            except BaseException as exc:
                self.alive = False
                return {"status": 0, "body": f"runtime_error: {type(exc).__name__}"}
            try:
                raw = self.ctx.eval("globalThis.__reg")
            except JSError:
                raw = None
            if raw:
                try:
                    return json.loads(raw)
                except Exception:
                    return {"status": 0, "body": str(raw)[:300]}
        return {"status": 0, "body": "timeout"}

    def stats(self) -> dict:
        out = {"sessions": self.sessions, "accounts": self.accounts,
               "age_s": round(time.time() - self.created_at, 1) if self.created_at else 0}
        try:
            net = self.ctx.net_log() if self.ctx else []
            out["requests"] = len(net)
            out["passport"] = [(r.get("status"), r.get("method")) for r in net
                               if "passport" in str(r.get("url"))][-4:]
            out["net"] = [{"url": str(r.get("url"))[:180],
                           "status": r.get("status"),
                           "method": r.get("method")}
                          for r in net[-12:]]
        except BaseException:
            pass
        try:
            out["ua"] = self.ctx.eval("navigator.userAgent")
            out["firefox"] = self.firefox_version
            out["platform"] = self.ctx.eval("navigator.platform")
            out["oscpu"] = self.ctx.eval("navigator.oscpu")
            out["languages"] = self.ctx.eval("JSON.stringify(navigator.languages)")
            out["hardwareConcurrency"] = self.ctx.eval("navigator.hardwareConcurrency")
            out["webdriver"] = self.ctx.eval("navigator.webdriver")
            out["kpsdk"] = self.ctx.eval("Object.keys(window.KPSDK||{})")
            out["kperr"] = self.ctx.eval("window.__kperr")
            out["cookies"] = self.ctx.eval("document.cookie")
        except BaseException as exc:
            out["eval_error"] = f"{type(exc).__name__}: {exc}"[:160]
        return out
