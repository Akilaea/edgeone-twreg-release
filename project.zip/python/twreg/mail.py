"""Temporary mailbox client (mail.minecraft.fashion compatible API)."""

from __future__ import annotations

import re
import secrets
import time
from typing import Optional

import requests
from loguru import logger
from urllib3 import disable_warnings

disable_warnings()

_CODE_RE = re.compile(r"\b(\d{6})\b")


def resolve_domain(domain: str) -> str:
    """`*.jsip.us` -> random `<10 hex>.jsip.us`; anything else is used verbatim."""
    d = (domain or "").strip()
    if d.startswith("*."):
        return f"{secrets.token_hex(5)}.{d[2:]}"
    return d


class MailClient:
    def __init__(self, api_url: str, default_domain: str = "*.jsip.us",
                 poll_interval: float = 1.0, timeout: int = 15):
        self.api_url = api_url.rstrip("/")
        self.default_domain = default_domain
        self.poll_interval = poll_interval
        self.timeout = timeout
        self._session = requests.Session()
        self._session.verify = False
        # Sandbox egress is direct; never let an inherited env proxy reroute it.
        self._session.trust_env = False

    def _post(self, url: str, payload: dict) -> Optional[dict]:
        try:
            resp = self._session.post(url, json=payload, timeout=self.timeout)
            if resp.status_code not in (200, 201):
                logger.warning(f"Mail POST {url} => HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            return resp.json()
        except Exception as exc:
            logger.warning(f"Mail POST error: {exc}")
            return None

    def _get(self, url: str, timeout: int = 15) -> Optional[dict]:
        try:
            resp = self._session.get(url, timeout=timeout)
            if resp.status_code != 200:
                logger.warning(f"Mail GET {url} => HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            return resp.json()
        except Exception as exc:
            logger.warning(f"Mail GET error: {exc}")
            return None

    def create_address(self, prefix: str = "tw", domain: Optional[str] = None) -> tuple[str, str]:
        username = f"{prefix}{secrets.token_hex(5)}"
        use_domain = resolve_domain(domain or self.default_domain)
        data = self._post(
            f"{self.api_url}/api/v1/addresses",
            {"username": username, "domain": use_domain},
        )
        if not data or "email" not in data or "token" not in data:
            raise RuntimeError(f"创建临时邮箱失败: {data}")
        logger.debug(f"临时邮箱: {data['email']}")
        return data["email"], data["token"]

    def wait_code(self, token: str, timeout: int = 120) -> Optional[str]:
        start = time.time()
        while time.time() - start < timeout:
            data = self._get(f"{self.api_url}/api/v1/{token}/emails", timeout=10)
            if data:
                for mail in data.get("emails", []):
                    subject = mail.get("subject", "")
                    body = mail.get("body", "")
                    for text in (subject, body):
                        match = _CODE_RE.search(text or "")
                        if match:
                            logger.debug(f"验证码: {match.group(1)} (subject={subject[:60]})")
                            return match.group(1)
            time.sleep(self.poll_interval)
        return None
