"""Account upload client for the TwitchCDK console API.

Docs: POST /api/accounts/upload, Worker auth:
  Authorization: Bearer <API_TOKEN>
  X-Worker-Id: <worker_name>
Body: username, password, email, auth_token, cookies (JSON string).

Worker heartbeat (POST /api/workers/heartbeat) is public and registers the
worker in the console; it is sent at batch start and end.
"""

from __future__ import annotations

import time

import requests
from loguru import logger


class AccountUploader:
    def __init__(self, base_url: str, token: str, worker_name: str,
                 retries: int = 3, timeout: int = 20):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.worker_name = worker_name
        self.retries = retries
        self.timeout = timeout
        self._session = requests.Session()
        self._session.trust_env = False

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.token)

    def _headers(self, with_json: bool = True) -> dict:
        headers = {
            "Authorization": f"Bearer {self.token}",
            "X-Worker-Id": self.worker_name,
        }
        if with_json:
            headers["Content-Type"] = "application/json"
        return headers

    def _post_json(self, url: str, payload: dict):
        return self._session.post(url, json=payload, headers=self._headers(),
                                  timeout=self.timeout)

    def upload(self, username: str, password: str, email: str,
               auth_token: str, cookies: str) -> bool:
        url = f"{self.base_url}/api/accounts/upload"
        payload = {
            "username": username,
            "password": password,
            "email": email,
            "auth_token": auth_token,
            "cookies": cookies,
        }
        for attempt in range(1, self.retries + 1):
            try:
                resp = self._post_json(url, payload)
            except requests.RequestException as exc:
                logger.warning(f"[upload] {username} 重试 {attempt}/{self.retries}: {exc}")
                if attempt < self.retries:
                    time.sleep(2)
                continue

            try:
                data = resp.json()
            except ValueError:
                body = (resp.text or "")[:160].replace("\n", " ")
                logger.warning(f"[upload] {username} HTTP {resp.status_code} 非 JSON: {body}")
                if resp.status_code >= 500 and attempt < self.retries:
                    time.sleep(2)
                    continue
                return False

            if resp.status_code == 200 and data.get("code") == 0:
                logger.info(f"[upload] {username} 上传成功")
                return True
            if resp.status_code == 401:
                logger.error("[upload] API Token 无效（401），停止上传")
                return False
            message = str(data.get("message") or data.get("detail") or "")[:120]
            logger.warning(f"[upload] {username} HTTP {resp.status_code} code="
                           f"{data.get('code')} {message}")
            if resp.status_code >= 500 and attempt < self.retries:
                time.sleep(2)
                continue
            return False
        return False

    def upload_result(self, result: dict, cookies_json: str) -> bool:
        return self.upload(
            result["username"], result["password"], result["email"],
            result["access_token"], cookies_json,
        )

    def heartbeat(self) -> bool:
        try:
            resp = self._session.post(
                f"{self.base_url}/api/workers/heartbeat",
                json={"worker_name": self.worker_name, "worker_type": "reg"},
                headers=self._headers(),
                timeout=10,
            )
            data = resp.json() if resp.content else {}
            if resp.status_code == 200 and data.get("code") == 0:
                worker = (data.get("data") or {}).get("worker_name", self.worker_name)
                logger.info(f"[upload] worker 心跳已登记: {worker}")
                return True
            logger.warning(f"[upload] worker 心跳失败 HTTP {resp.status_code}")
            return False
        except Exception as exc:
            logger.warning(f"[upload] worker 心跳异常: {type(exc).__name__}: {exc}")
            return False
