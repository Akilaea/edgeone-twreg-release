"""Multi-threaded runner for the EdgeOne Makers port.

No egress rotation: the sandbox instance owns one IP for the whole batch.
Rotating the exit means killing the sandbox and letting Makers create a new
one (see the /rotate route), which is the platform-native replacement for
the old WARP/VPNGate machinery.
"""

from __future__ import annotations

import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

from loguru import logger

from .chromium import ChromiumSession
from .config import Settings
from .cookies import cookies_for_export
from .mail import MailClient
from .registration_chromium import register_one_chromium
from .upload import AccountUploader

MAX_CONSECUTIVE_5025 = 5
MAX_BROWSER_REBUILDS = 3


class AccountStore:
    def __init__(self, directory: Path, stamp: Optional[str] = None):
        self.directory = Path(directory)
        self.path = self.directory / f"accounts_{stamp or time.strftime('%Y%m%d_%H%M%S')}.txt"
        self._lock = threading.Lock()

    def save(self, result: dict) -> None:
        line = f"{result['username']}:{result['password']} {result['access_token']}\n"
        self.directory.mkdir(parents=True, exist_ok=True)
        with self._lock:
            with open(self.path, "a", encoding="utf-8") as handle:
                handle.write(line)

    def read_entries(self) -> list[dict]:
        if not self.path.is_file():
            return []
        entries = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or " " not in line:
                continue
            left, token = line.split(" ", 1)
            if ":" not in left:
                continue
            username, password = left.split(":", 1)
            entries.append({"username": username, "password": password,
                            "access_token": token})
        return entries


def _parse_size(value: str, default: tuple[int, int]) -> tuple[int, int]:
    try:
        left, right = str(value).lower().split("x", 1)
        return (int(left), int(right))
    except Exception:
        return default


def _new_session(settings: Settings):
    if settings.browser_engine == "ruyi":
        from .ruyi import RuyiSession
        return RuyiSession(
            proxy=settings.proxy,
            timezone=settings.ruyi_timezone,
            locale=settings.ruyi_locale,
            country=settings.ruyi_country,
            screen=_parse_size(settings.ruyi_screen, (1920, 1080)),
            viewport=_parse_size(settings.ruyi_viewport, (1536, 864)),
            cache_dir=settings.cache_dir,
            firefox_version=settings.ruyi_firefox,
        )
    return ChromiumSession(
        proxy=settings.proxy,
        cdp_url=settings.cdp_url,
        browser_mode=settings.browser_mode,
        headless=settings.headless,
        relay_url=settings.relay_url,
    )


def _open_session(session: ChromiumSession, wid: int,
                  semaphore: threading.Semaphore) -> bool:
    for attempt in range(3):
        with semaphore:
            opened = session.open()
            time.sleep(0.4)
        if opened:
            return True
        logger.warning(f"[R{wid}] 会话启动失败 ({attempt + 1}/3)，退避重试")
        time.sleep(3 + attempt * 3)
    return False


def worker(settings: Settings, wid: int, store: AccountStore,
           semaphore: threading.Semaphore,
           uploader: Optional[AccountUploader]) -> dict:
    session = _new_session(settings)
    if settings.start_stagger_sec > 0 and wid > 0:
        delay = wid * settings.start_stagger_sec
        logger.info(f"[R{wid}] 启动错峰，等待 {delay:.1f}s")
        time.sleep(delay)
    mail = MailClient(settings.mail_api_url, settings.mail_domain,
                      settings.mail_poll_interval)
    target = settings.accounts_per_worker
    success = failed = rotations = 0
    uploaded_ok = uploaded_bad = 0
    kpsdk_rejects = device_limiteds = 0
    consecutive_5025 = 0
    browser_rebuilds = 0
    zero_account_sessions = 0
    started_at = time.time()
    try:
        while success < target:
            if not session.alive:
                if not _open_session(session, wid, semaphore):
                    failed += 1
                    logger.error(f"[R{wid}] 会话连续 3 次启动失败，等 5s 再试")
                    time.sleep(5)
                    if failed >= settings.max_fails:
                        break
                    continue

            index = wid * 100 + success + failed + 1
            t0 = time.time()
            try:
                if settings.browser_engine == "ruyi":
                    from .registration_ruyi import register_one_ruyi
                    result = register_one_ruyi(
                        session, mail, index,
                        prefix=settings.prefix, domain=settings.mail_domain,
                        password_len=settings.password_len,
                        client_id=settings.client_id, timeout=180,
                    )
                else:
                    result = register_one_chromium(
                        session, mail, index,
                        prefix=settings.prefix, domain=settings.mail_domain,
                        password_len=settings.password_len,
                        client_id=settings.client_id, timeout=180,
                    )
            except Exception as exc:
                logger.error(f"[R{wid}] 注册异常: {type(exc).__name__}: {exc}")
                result = {"status": "failed", "error": f"exception: {exc}"}
            elapsed = time.time() - t0

            if result.get("status") == "success":
                store.save(result)
                if uploader is not None:
                    if uploader.upload_result(
                            result, cookies_for_export(result["cookies"])):
                        uploaded_ok += 1
                        tag = "已上传"
                    else:
                        uploaded_bad += 1
                        tag = "上传失败(已落盘)"
                else:
                    tag = "已落盘"
                success += 1
                session.accounts += 1
                consecutive_5025 = 0
                browser_rebuilds = 0
                zero_account_sessions = 0
                logger.info(f"[R{wid}] OK #{success}/{target} {result['username']} {tag} "
                            f"({elapsed:.1f}s, 会话累计={session.accounts})")
                continue

            status = result.get("status")
            if status == "kpsdk_reject":
                kpsdk_rejects += 1
            elif status == "device_limited":
                device_limiteds += 1
            if status in ("kpsdk_reject", "kpsdk_not_ready") \
                    and browser_rebuilds < MAX_BROWSER_REBUILDS:
                browser_rebuilds += 1
                logger.warning(f"[R{wid}] {status} → 重建浏览器 "
                               f"{browser_rebuilds}/{MAX_BROWSER_REBUILDS}")
                session.close()
                time.sleep(1)
                continue
            browser_rebuilds = 0

            failed += 1
            if failed >= settings.max_fails:
                logger.error(f"[R{wid}] 失败 {failed} 次达上限 MAX_FAILS={settings.max_fails}，"
                             f"本线程收工")
                break

            error = str(result.get("error", ""))[:90]
            if status in ("kpsdk_reject", "device_limited"):
                if status == "kpsdk_reject":
                    consecutive_5025 += 1
                if session.accounts == 0:
                    zero_account_sessions += 1
                else:
                    zero_account_sessions = 0
                logger.warning(f"[R{wid}] {status} → 换会话 ({elapsed:.1f}s) {error}")
                session.close()
                rotations += 1
                if zero_account_sessions >= 2 and settings.cooldown_sec > 0:
                    logger.error(f"[R{wid}] 连续 2 个 0 账号会话 → 冷却 "
                                 f"{settings.cooldown_sec}s")
                    time.sleep(settings.cooldown_sec)
                    zero_account_sessions = 0
                if consecutive_5025 >= MAX_CONSECUTIVE_5025:
                    logger.error(f"[R{wid}] 连续 {MAX_CONSECUTIVE_5025} 次 5025 → 终止本线程")
                    break
                time.sleep(random.uniform(0.5, 1.5))
            else:
                logger.warning(f"[R{wid}] 失败: {error} ({elapsed:.1f}s)")
                if status == "failed" and session.accounts == 0 and failed >= 3:
                    session.close()
                    rotations += 1
                time.sleep(random.uniform(0.5, 1.5))
    finally:
        try:
            session.close()
        except Exception:
            pass

    return {"success": success, "failed": failed, "rotations": rotations,
            "sessions": session.sessions, "seconds": round(time.time() - started_at, 1),
            "uploaded": uploaded_ok, "upload_failed": uploaded_bad,
            "kpsdk_rejects": kpsdk_rejects, "device_limiteds": device_limiteds}


class Runner:
    def __init__(self, settings: Settings, store: Optional[AccountStore] = None):
        self.settings = settings
        self.store = store or AccountStore(settings.accounts_dir)
        self.semaphore = threading.Semaphore(settings.max_concurrent_ctx)

    def _uploader(self) -> Optional[AccountUploader]:
        s = self.settings
        if not s.enable_upload:
            return None
        uploader = AccountUploader(s.api_base_url, s.api_token, s.worker_name)
        if not uploader.configured:
            logger.warning("已请求上传，但 API_BASE_URL / API_TOKEN 未配置 → 仅落盘")
            return None
        return uploader

    def run(self) -> dict:
        s = self.settings
        uploader = self._uploader()
        logger.info(f"{s.browser_engine} 版开始: 线程={s.workers} "
                    f"每线程={s.accounts_per_worker} 合计={s.total_accounts} "
                    f"上传={'开' if uploader else '关'}")
        logger.info(f"出口: {'沙箱 IP（直连）' if not s.proxy else s.proxy} "
                    f"模式={s.browser_mode} cdp={'yes' if s.cdp_url else 'no'}")
        logger.info(f"邮箱: {s.mail_api_url} 域名={s.mail_domain}")
        if uploader:
            logger.info(f"上传: {uploader.base_url} worker={uploader.worker_name}")
            uploader.heartbeat()

        started_at = time.time()
        results: dict = {}
        with ThreadPoolExecutor(max_workers=s.workers) as pool:
            futures = [pool.submit(worker, s, i, self.store, self.semaphore, uploader)
                       for i in range(s.workers)]
            for future in futures:
                future.result()
            for wid, future in enumerate(futures):
                results[wid] = future.result()

        elapsed = time.time() - started_at
        ok = sum(v["success"] for v in results.values())
        bad = sum(v["failed"] for v in results.values())
        sessions = sum(v["sessions"] for v in results.values())
        logger.info("=" * 58)
        for wid, stats in sorted(results.items()):
            logger.info(f"[R{wid}] 成功={stats['success']}/{s.accounts_per_worker} "
                        f"失败={stats['failed']} 会话={stats['sessions']} "
                        f"换会话={stats['rotations']} 用时={stats['seconds']}s")
        per = elapsed / ok if ok else 0
        uploaded_ok = sum(v.get("uploaded", 0) for v in results.values())
        uploaded_bad = sum(v.get("upload_failed", 0) for v in results.values())
        kpsdk_rejects = sum(v.get("kpsdk_rejects", 0) for v in results.values())
        device_limiteds = sum(v.get("device_limiteds", 0) for v in results.values())
        logger.info(f"合计: 成功={ok}/{s.total_accounts} 失败={bad} 会话总数={sessions} "
                    f"总耗时={elapsed:.1f}s 每账号={per:.2f}s")
        if uploader:
            logger.info(f"上传: 成功={uploaded_ok} 失败={uploaded_bad}")
        logger.info(f"拒绝: 5025={kpsdk_rejects} 2014={device_limiteds}")
        logger.info(f"账号文件: {self.store.path}")
        logger.info("=" * 58)
        if uploader:
            uploader.heartbeat()
        return {"success": ok, "failed": bad, "sessions": sessions,
                "elapsed": round(elapsed, 1), "file": str(self.store.path),
                "uploaded": uploaded_ok, "upload_failed": uploaded_bad,
                "kpsdk_rejects": kpsdk_rejects, "device_limiteds": device_limiteds,
                "accounts": self.store.read_entries()}
