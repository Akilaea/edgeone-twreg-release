"""Configuration for the EdgeOne Makers port.

Proxy is gone by design: the sandbox egress IP is the exit. `PROXY_SERVER`
still exists as a local-development escape hatch, but it defaults to direct.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Mapping, Optional

CLIENT_ID = "kimne78kx3ncx6brgo4mv6wki5h1ko"
DEFAULT_API_BASE = "http://47.98.228.129:5000"
DEFAULT_API_TOKEN = "8a7ad0008e53b02fbfe04c87751234c8"
_DISABLED = ("direct", "none", "-", "off", "")


def resolve_proxy(raw: Optional[str]) -> Optional[str]:
    """Empty/direct/none/-/off -> no proxy. Anything else is used verbatim."""
    value = (raw or "").strip()
    if value.lower() in _DISABLED:
        return None
    return value


def _raw(env: Mapping[str, str], name: str, default: str = "") -> str:
    value = env.get(name)
    if value is None:
        return default
    return value.strip().strip('"').strip("'")


def _int(env: Mapping[str, str], name: str, default: int) -> int:
    try:
        return int(_raw(env, name, str(default)) or default)
    except (TypeError, ValueError):
        return default


def _float(env: Mapping[str, str], name: str, default: float) -> float:
    try:
        return float(_raw(env, name, str(default)) or default)
    except (TypeError, ValueError):
        return default


def _bool(env: Mapping[str, str], name: str, default: bool) -> bool:
    value = _raw(env, name, "1" if default else "0").lower()
    return value not in ("0", "false", "no", "off", "")


def load_dotenv(path: Path) -> None:
    """Minimal .env loader. Existing process env always wins."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


@dataclass(frozen=True)
class Settings:
    workers: int = 5
    accounts_per_worker: int = 15
    proxy: Optional[str] = None
    max_concurrent_ctx: int = 3
    max_fails: int = 30
    cooldown_sec: int = 120
    start_stagger_sec: float = 3.0

    mail_api_url: str = "https://mail.minecraft.fashion"
    mail_domain: str = "*.jsip.us"
    mail_poll_interval: float = 1.0

    prefix: str = "tw"
    password_len: int = 16
    profile_random: bool = True
    client_id: str = CLIENT_ID

    # chromium (CloakBrowser) or ruyi (Linux ruyijs / Firefox engine).
    browser_engine: str = "ruyi"
    ruyi_timezone: str = "Asia/Shanghai"
    ruyi_locale: str = "zh-CN"
    ruyi_country: str = "auto"
    ruyi_firefox: str = "159"
    ruyi_screen: str = "1920x1080"
    ruyi_viewport: str = "1536x864"
    cache_dir: Path = Path("cache")

    # EdgeOne Sandbox: attach to the built-in Chromium over CDP.
    cdp_url: str = ""
    browser_mode: str = "auto"          # auto | cdp | cloak
    chrome_executable: str = ""
    headless: bool = True
    relay_url: str = ""                 # Edge Function relay (optional)

    accounts_dir: Path = Path("accounts")
    log_dir: Path = Path("logs")
    log_level: str = "INFO"

    enable_upload: bool = True
    api_base_url: str = DEFAULT_API_BASE
    api_token: str = DEFAULT_API_TOKEN
    worker_name: str = "reg_worker_edgeone"

    @property
    def total_accounts(self) -> int:
        return self.workers * self.accounts_per_worker

    @classmethod
    def from_env(
        cls,
        env: Optional[Mapping[str, str]] = None,
        overrides: Optional[Mapping[str, object]] = None,
    ) -> "Settings":
        e = os.environ if env is None else env
        base = cls(
            workers=max(1, _int(e, "WORKERS", 5)),
            accounts_per_worker=max(1, _int(e, "ACCOUNTS", 15)),
            proxy=resolve_proxy(_raw(e, "PROXY_SERVER", "")),
            max_concurrent_ctx=max(1, _int(e, "MAX_CONCURRENT_CTX", 3)),
            max_fails=max(1, _int(e, "MAX_FAILS", 30)),
            cooldown_sec=max(0, _int(e, "COOLDOWN_SEC", 120)),
            start_stagger_sec=max(0.0, _float(e, "START_STAGGER_SEC", 3.0)),
            mail_api_url=_raw(e, "MAIL_API_URL", "https://mail.minecraft.fashion"),
            mail_domain=_raw(e, "MAIL_DOMAINS", "*.jsip.us"),
            mail_poll_interval=max(0.2, _float(e, "MAIL_POLL_INTERVAL", 1.0)),
            prefix=_raw(e, "PREFIX", "tw"),
            password_len=max(8, _int(e, "PASSWORD_LEN", 16)),
            profile_random=_bool(e, "PROFILE_RANDOM", True),
            browser_engine=_raw(e, "BROWSER_ENGINE", "ruyi").lower(),
            ruyi_timezone=_raw(e, "RUYI_TIMEZONE", "Asia/Shanghai"),
            ruyi_locale=_raw(e, "RUYI_LOCALE", "zh-CN"),
            ruyi_country=_raw(e, "RUYI_COUNTRY", "auto"),
            ruyi_firefox=_raw(e, "RUYIJS_FIREFOX", "159"),
            ruyi_screen=_raw(e, "RUYI_SCREEN", "1920x1080"),
            ruyi_viewport=_raw(e, "RUYI_VIEWPORT", "1536x864"),
            cache_dir=Path(_raw(e, "CACHE_DIR", "cache")),
            cdp_url=_raw(e, "TWREG_CDP_URL", ""),
            browser_mode=_raw(e, "BROWSER_MODE", "auto").lower(),
            chrome_executable=_raw(e, "CHROME_EXECUTABLE", ""),
            headless=_bool(e, "CHROME_HEADLESS", True),
            relay_url=_raw(e, "TWREG_RELAY_URL", ""),
            accounts_dir=Path(_raw(e, "ACCOUNTS_DIR", "accounts")),
            log_dir=Path(_raw(e, "LOG_DIR", "logs")),
            log_level=_raw(e, "LOG_LEVEL", "INFO").upper(),
            enable_upload=_bool(e, "ENABLE_UPLOAD", True),
            api_base_url=_raw(e, "API_BASE_URL", DEFAULT_API_BASE).rstrip("/"),
            api_token=_raw(e, "API_TOKEN", DEFAULT_API_TOKEN),
            worker_name=_raw(e, "WORKER_NAME", "reg_worker_edgeone"),
        )
        if overrides:
            clean = {k: v for k, v in overrides.items() if v is not None}
            if "proxy" in clean:
                clean["proxy"] = resolve_proxy(str(clean["proxy"]))
            base = replace(base, **clean)
        return base
