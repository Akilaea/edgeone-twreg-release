"""Single-account registration through the Chromium engine."""

from __future__ import annotations

import json
import random
import time
from typing import Optional

from loguru import logger

from .config import CLIENT_ID
from .cookies import build_cookies, random_password
from .mail import MailClient
from .profile import random_password_length

EC_SUCCESS_VERIFY_SENT = 2026
EC_KASADA_REJECT = 5025
EC_DEVICE_LIMITED = 2014
EC_USERNAME_TAKEN = 5021
EC_EMAIL_DOMAIN_BLOCKED = 2002


def _body(response: dict) -> dict:
    body = response.get("body")
    if isinstance(body, dict):
        return body
    try:
        return json.loads(body or "")
    except Exception:
        return {}


def _birthday() -> dict:
    return {"day": 15, "month": 6, "year": 1995, "isOver18": True}


def register_one_chromium(session, mail: MailClient, index: int, *,
                          prefix: str = "tw", domain: str = "*.jsip.us",
                          password_len: int = 16, client_id: str = CLIENT_ID,
                          timeout: int = 180,
                          password: Optional[str] = None) -> dict:
    if password is None:
        password = random_password(random_password_length())
    deadline = time.time() + timeout

    try:
        email, mail_token = mail.create_address(prefix, domain)
    except Exception as exc:
        return {"status": "failed", "error": f"create_email_failed: {exc}",
                "password": password}
    username = email.split("@")[0]
    base = {"username": username, "password": password, "email": email,
            "birthday": _birthday(), "email_verification_enabled": False,
            "client_id": client_id, "is_password_guide": "nist"}

    session.new_page()
    if not session.open_signup():
        return {"status": "kpsdk_not_ready", "error": "kpsdk_not_ready",
                "username": username, "email": email, "password": password}

    r1 = session.register(base)
    body1 = _body(r1)
    ec = body1.get("error_code")

    if ec == EC_KASADA_REJECT:
        logger.warning(f"[{index}] {username} step1 5025 Kasada 拒绝 "
                       f"body={str(r1.get('text'))[:300]}")
        return {"status": "kpsdk_reject", "error": "kasada_reject",
                "username": username, "email": email, "password": password}
    if ec == EC_DEVICE_LIMITED:
        logger.warning(f"[{index}] {username} step1 2014 设备限流")
        return {"status": "device_limited", "error": "device_limited",
                "username": username, "email": email, "password": password}
    if ec == EC_USERNAME_TAKEN:
        return {"status": "failed", "error": "username_taken",
                "username": username, "email": email, "password": password}
    if ec == EC_EMAIL_DOMAIN_BLOCKED:
        return {"status": "failed", "error": "email_domain_blocked",
                "username": username, "email": email, "password": password}
    if ec != EC_SUCCESS_VERIFY_SENT:
        logger.warning(f"[{index}] {username} step1 异常 HTTP={r1.get('status')} "
                       f"ec={ec} text={str(r1.get('text'))[:160]}")
        return {"status": "failed", "error": f"step1_ec={ec}",
                "username": username, "email": email, "password": password}
    logger.info(f"[{index}] {username} 验证码已发送")

    remaining = deadline - time.time()
    if remaining <= 5:
        return {"status": "failed", "error": "no_time_for_verification",
                "username": username, "email": email, "password": password}
    code = mail.wait_code(mail_token, int(remaining))
    if not code:
        logger.warning(f"[{index}] {username} 验证码超时")
        return {"status": "failed", "error": "verification_timeout",
                "username": username, "email": email, "password": password}
    logger.info(f"[{index}] {username} 收到验证码")

    step2 = dict(base)
    step2["email_verification_code"] = code
    r2 = {}
    status2 = 0
    body2 = {}
    for attempt in range(1, 4):
        r2 = session.register(step2)
        status2 = r2.get("status")
        body2 = _body(r2)
        if status2 == 200:
            break
        ec2 = body2.get("error_code")
        if ec2 == EC_KASADA_REJECT:
            logger.warning(f"[{index}] {username} step2 5025 Kasada 拒绝")
            return {"status": "kpsdk_reject", "error": "kasada_reject_step2",
                    "username": username, "email": email, "password": password}
        if ec2 == EC_DEVICE_LIMITED:
            logger.warning(f"[{index}] {username} step2 2014 设备限流")
            return {"status": "device_limited", "error": "device_limited_step2",
                    "username": username, "email": email, "password": password}
        logger.warning(f"[{index}] {username} step2 HTTP={status2} ec={ec2} "
                       f"(try {attempt}/3) {str(r2.get('text'))[:160]}")
        if attempt < 3:
            time.sleep(random.uniform(2.0, 4.0))

    if status2 != 200:
        return {"status": "failed", "error": f"step2_http_{status2}",
                "username": username, "email": email, "password": password}

    access_token = body2.get("access_token")
    user_id = body2.get("userID") or body2.get("user_id") or body2.get("userid")
    if not access_token or not user_id:
        return {"status": "failed", "error": "step2_no_token",
                "username": username, "email": email, "password": password}

    cookies = build_cookies(access_token, user_id, username)
    logger.info(f"[{index}] {username} 注册成功 (uid={user_id} "
                f"token={access_token[:4]}***)")
    return {"status": "success", "username": username, "email": email,
            "password": password, "access_token": access_token,
            "user_id": str(user_id), "cookies": cookies}
