"""Logging: UTF-8 console + rotating file."""

from __future__ import annotations

import sys
from pathlib import Path

from loguru import logger


def setup_logging(log_dir: Path, level: str = "INFO") -> Path:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass

    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "twreg_{time:YYYY-MM-DD}.log"

    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <7}</level> | <level>{message}</level>",
        level=level,
    )
    logger.add(
        log_file,
        rotation="20 MB",
        retention="7 days",
        level="DEBUG",
        encoding="utf-8",
    )
    return log_dir
